#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
if [[ -z "${AIRPODS_TEAM_ID:-}" ]]; then
  printf 'Proiectul curent: %s\nConfigurează echipa Apple Developer și citește PUBLICARE-1.5.1.md.\nArhivarea pentru App Store folosește pregateste-publicare.command --ios după configurarea echipei și a politicii editorului.\n' "$project_dir/AirPodsMonitor.xcodeproj"
  /usr/bin/open -a Xcode "$project_dir/AirPodsMonitor.xcodeproj"
  exit 0
fi
exec /bin/bash "$project_dir/pregateste-publicare.command" --ios
