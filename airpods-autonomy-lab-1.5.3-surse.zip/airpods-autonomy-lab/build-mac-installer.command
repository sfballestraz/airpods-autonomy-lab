#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
workspace_dir="$(cd "$project_dir/../.." && pwd)"
/usr/bin/env python3 "$project_dir/generate-changelog.py"
build_dir="$workspace_dir/work/installer-build"
package_dir="$workspace_dir/outputs/Instalare-Mac"
mkdir -p "$build_dir" "$package_dir"
export CLANG_MODULE_CACHE_PATH="$build_dir/modules"
xcodebuild -project "$project_dir/AirPodsMonitor.xcodeproj" \
  -scheme AirPodsMonitor-LocalMac -configuration 'Local Debug' \
  -destination 'generic/platform=macOS' -derivedDataPath "$build_dir" \
  ARCHS='arm64 x86_64' ONLY_ACTIVE_ARCH=NO CODE_SIGNING_ALLOWED=NO \
  ENABLE_DEBUG_DYLIB=NO OTHER_SWIFT_FLAGS=-disable-sandbox build
staging_dir="$(/usr/bin/mktemp -d /private/tmp/AirPodsInstaller.XXXXXX)"
trap 'rm -rf "$staging_dir"' EXIT
app_path="$staging_dir/AirPodsMonitor.app"
/usr/bin/ditto --norsrc --noextattr "$build_dir/Build/Products/Local Debug/AirPodsMonitor.app" "$app_path"
# Clear Finder decoration only on generated staging files; never alter quarantine.
/usr/bin/xattr -dr com.apple.FinderInfo "$app_path" 2>/dev/null || true
/usr/bin/xattr -dr com.apple.ResourceFork "$app_path" 2>/dev/null || true
/usr/bin/codesign --force --sign - --entitlements "$project_dir/LocalWidgetMac.entitlements" --timestamp=none "$app_path/Contents/PlugIns/MonitorWidgets.appex"
/usr/bin/codesign --force --sign - --entitlements "$project_dir/LocalMac.entitlements" --timestamp=none "$app_path"
/usr/bin/codesign --verify --deep --strict "$app_path"
# Local ad-hoc build; no Developer ID, no notarization, no cloud capabilities.
# The installer copies the app only. It has no scripts and never deletes journals.
/usr/bin/pkgbuild --component "$app_path" --install-location /Applications \
  --identifier ch.local.AirPodsMonitor.local-installer --version 1.5.3 \
  "$staging_dir/Component.pkg"
cat > "$staging_dir/Distribution.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
  <title>AirPods Autonomy Lab — Local 1.5.3</title>
  <options customize="never" require-scripts="false" hostArchitectures="arm64,x86_64"/>
  <allowed-os-versions><os-version min="14.0"/></allowed-os-versions>
  <domains enable_anywhere="false" enable_currentUserHome="false" enable_localSystem="true"/>
  <choices-outline><line choice="app"/></choices-outline>
  <choice id="app" visible="false"><pkg-ref id="ch.local.AirPodsMonitor.local-installer"/></choice>
  <pkg-ref id="ch.local.AirPodsMonitor.local-installer" version="1.5.3" onConclusion="none">Component.pkg</pkg-ref>
</installer-gui-script>
XML
/usr/bin/productbuild --distribution "$staging_dir/Distribution.xml" --package-path "$staging_dir" "$package_dir/AirPods-Autonomy-Lab-Local-1.5.3.pkg"
/usr/bin/ditto -c -k --keepParent "$app_path" "$package_dir/AirPodsMonitor-Local-1.5.3.zip"
(cd "$package_dir" && /usr/bin/shasum -a 256 AirPods-Autonomy-Lab-Local-1.5.3.pkg AirPodsMonitor-Local-1.5.3.zip > SHA256.txt)
/usr/sbin/pkgutil --check-signature "$package_dir/AirPods-Autonomy-Lab-Local-1.5.3.pkg" || true
printf '\nInstalator local creat în %s\nFără notarizare Apple; CloudKit dezactivat în această variantă.\n' "$package_dir"
