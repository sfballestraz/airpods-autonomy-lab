#!/usr/bin/env python3
"""Generate release notes from reviewed release metadata; never invent changes."""
import json
from pathlib import Path
root = Path(__file__).resolve().parent
releases = [json.loads(p.read_text()) for p in (root / 'releases').glob('*.json')]
releases.sort(key=lambda r: r['build'], reverse=True)
assert len({r['build'] for r in releases}) == len(releases)
text = '# Changelog / Noutăți\n\n'
for release in releases:
    text += f"## {release['version']} — build {release['build']}\n\n{release['notesRO']}\n\n{release['notesFR']}\n\n"
(root / 'CHANGELOG.md').write_text(text)
