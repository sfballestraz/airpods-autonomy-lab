// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "AirPodsMonitor", defaultLocalization: "en", platforms: [.macOS(.v14), .iOS(.v17)], products: [.executable(name: "AirPodsMonitor", targets: ["AirPodsMonitor"])], targets: [.target(name: "MonitorCore"), .executableTarget(name: "AirPodsMonitor", dependencies: ["MonitorCore"], resources: [.process("Resources")]), .testTarget(name: "MonitorCoreTests", dependencies: ["MonitorCore"]), .testTarget(name: "AppIntegrationTests", dependencies: ["AirPodsMonitor", "MonitorCore"])])
