import SwiftUI
import Charts
import CoreLocation
import UserNotifications
#if os(macOS)
import AppKit
import CoreBluetooth
import IOBluetooth
#else
import AVFAudio
import UIKit
#endif
#if canImport(MonitorCore)
import MonitorCore
#endif

@MainActor
final class ConnectionMonitor: NSObject, ObservableObject {
    @Published private(set) var watched: AirPodsPair?
    @Published private(set) var state: ObservedLinkState = .unknown
    @Published private(set) var checkedAt: Date?
    @Published private(set) var samples: [ReceptionSample] = []
    @Published var message = ""
    @Published var disconnectNotice = ""
    @Published var notificationsEnabled = false
    @Published private(set) var notificationsAllowed = false
    private var policy = DisconnectGuard()
    private var loop: Task<Void, Never>?
    #if os(macOS)
    private var central: CBCentralManager?
    #else
    private var routeToken: NSObjectProtocol?
    #endif
    override init() {
        super.init()
        #if os(iOS)
        routeToken = NotificationCenter.default.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let removed = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt) == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue
            Task { @MainActor in self?.refresh(removedRoute: removed) }
        }
        #endif
    }
    var watching: Bool { watched != nil }
    func start(_ pair: AirPodsPair) {
        stop(); watched = pair; policy = DisconnectGuard(); samples = []; disconnectNotice = ""
        guard let id = pair.bluetoothID, id.hasPrefix(Self.platformPrefix) else {
            message = L("Associate this pair with its Bluetooth entry on this device before monitoring."); return
        }
        #if os(macOS)
        if central == nil { central = CBCentralManager(delegate: self, queue: .main, options: [CBCentralManagerOptionShowPowerAlertKey: false]) }
        #endif
        refresh()
        loop = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .seconds(5)) } catch { break }
                guard let self else { break }
                self.refresh()
            }
        }
    }
    static var platformPrefix: String {
        #if os(macOS)
        "mac:"
        #else
        "ios-route:"
        #endif
    }
    func stop() { loop?.cancel(); loop = nil; watched = nil; state = .unknown; checkedAt = nil; samples = []; message = ""; disconnectNotice = "" }
    func suspend() {
        #if os(iOS)
        // A suspended iOS app cannot promise route monitoring. Disarm across inactive periods.
        policy = DisconnectGuard(); state = .unknown; checkedAt = nil
        #endif
    }
    func refresh(removedRoute: Bool = false) {
        #if os(iOS)
        guard UIApplication.shared.applicationState == .active else { suspend(); return }
        #endif
        guard let watched, let id = watched.bluetoothID, id.hasPrefix(Self.platformPrefix) else { return }
        var next: ObservedLinkState = .unknown
        var raw: Int?
        var eligible = false
        #if os(macOS)
        guard CBManager.authorization != .denied && CBManager.authorization != .restricted else { update(.unknown, raw: nil, eligible: false); message = L("Bluetooth permission is unavailable. Connection cannot be confirmed."); return }
        guard central?.state == .poweredOn else { update(.unknown, raw: nil, eligible: false); message = L("Bluetooth is off or initializing. This is not a separation alert."); return }
        let devices = IOBluetoothDevice.pairedDevices() as? [IOBluetoothDevice] ?? []
        guard let device = devices.first(where: { "mac:" + ($0.addressString ?? "") == id }) else {
            update(.unknown, raw: nil, eligible: false); message = L("The associated Bluetooth entry is unavailable. Reassociate it on this device."); return
        }
        next = device.isConnected() ? .connected : .disconnected
        if next == .connected { raw = Int(device.rawRSSI()) }
        eligible = true
        #else
        let outputs = AVAudioSession.sharedInstance().currentRoute.outputs
        let match = outputs.contains { [.bluetoothA2DP, .bluetoothHFP, .bluetoothLE].contains($0.portType) && "ios-route:" + $0.uid == id }
        next = match ? .connected : (removedRoute ? .disconnected : .otherRoute)
        eligible = removedRoute
        #endif
        update(next, raw: raw, eligible: eligible)
        message = L("This observes one associated Bluetooth identity; it cannot identify which earbud or case disconnected.")
    }
    private func update(_ next: ObservedLinkState, raw: Int?, eligible: Bool) {
        let now = Date(); state = next; checkedAt = now
        if let raw, let sample = ReceptionSample(rawRSSI: raw, at: now) { samples.append(sample); samples = Array(samples.suffix(60)) }
        if policy.observe(next, eligibleLoss: eligible, at: now), let watched {
            disconnectNotice = L("Connection lost for {0}. This does not prove the AirPods were left behind.", watched.name)
            AccessibilityNotification.Announcement(disconnectNotice).post()
            if notificationsEnabled && notificationsAllowed {
                let content = UNMutableNotificationContent()
                content.title = L("Observed AirPods disconnection")
                content.body = disconnectNotice
                // Silent local notification; never a critical alert or a case sound.
                let request = UNNotificationRequest(identifier: "connection." + watched.id.uuidString, content: content, trigger: nil)
                Task { try? await UNUserNotificationCenter.current().add(request) }
            }
        }
    }
    func allowNotifications() async {
        do {
            notificationsAllowed = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert])
            notificationsEnabled = notificationsAllowed
            message = notificationsAllowed ? L("Silent disconnection notifications enabled. System notification settings still apply.") : L("Notifications were not allowed. The in-app connection status remains available.")
        } catch { message = L("Notification permission failed: {0}", error.localizedDescription) }
    }
}
#if os(macOS)
extension ConnectionMonitor: @preconcurrency CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) { refresh() }
}
#endif

@MainActor
final class HostLocationReader: NSObject, ObservableObject, @preconcurrency CLLocationManagerDelegate {
    @Published var result: HostLocationMemo?
    @Published var message = ""
    @Published var pending = false
    private let manager = CLLocationManager()
    override init() { super.init(); manager.delegate = self; manager.desiredAccuracy = kCLLocationAccuracyHundredMeters }
    func request() {
        result = nil; pending = true; message = L("Requesting this Mac or iPhone location, not AirPods location…")
        switch manager.authorizationStatus {
        case .notDetermined: manager.requestWhenInUseAuthorization()
        case .authorizedAlways: manager.requestLocation()
        #if os(iOS)
        case .authorizedWhenInUse: manager.requestLocation()
        #endif
        default: pending = false; message = L("Location permission is unavailable. Use Apple Find My or keep a manual place note.")
        }
    }
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard pending else { return }
        var authorized = manager.authorizationStatus == .authorizedAlways
        #if os(iOS)
        authorized = authorized || manager.authorizationStatus == .authorizedWhenInUse
        #endif
        if authorized { manager.requestLocation() }
        else if manager.authorizationStatus != .notDetermined { pending = false; message = L("Location permission is unavailable. Use Apple Find My or keep a manual place note.") }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        pending = false
        guard let value = locations.last, abs(value.timestamp.timeIntervalSinceNow) <= 60, value.horizontalAccuracy > 0 else {
            message = L("No recent host location is available. No AirPods position was inferred."); return
        }
        #if os(macOS)
        let platform = "macOS"
        #else
        let platform = "iOS"
        #endif
        let memo = HostLocationMemo(latitude: value.coordinate.latitude, longitude: value.coordinate.longitude, accuracy: value.horizontalAccuracy, recordedAt: value.timestamp, hostPlatform: platform)
        guard memo.valid(at: Date()) else { message = L("No recent host location is available. No AirPods position was inferred."); return }
        result = memo; message = L("Host position obtained. Save it explicitly as a reference, not an AirPods location.")
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        pending = false; message = L("Host location failed: {0}", error.localizedDescription)
    }
}

struct DeviceFindingPage: View {
    let pair: AirPodsPair
    @EnvironmentObject var store: Store
    @EnvironmentObject var connection: ConnectionMonitor
    @Environment(\.dismiss) private var dismiss
    @StateObject private var location = HostLocationReader()
    @StateObject private var bluetooth = BluetoothList()
    private var currentPair: AirPodsPair { store.archive.pairs.first(where: { $0.id == pair.id }) ?? pair }
    @State private var details = PairDetails()
    @State private var hasExpiry = false
    @State private var expiry = Date()
    @State private var message = ""
    private var thisWatch: Bool { connection.watched?.id == pair.id }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("Connection, finding and device details")).font(.title2.bold()).accessibilityAddTraits(.isHeader)
                Text(pair.name).font(.headline)
                Text(L(pair.device.displayName) + " · " + L(pair.device.models))
                GroupBox(L("Bluetooth connection and reception")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L(thisWatch ? connection.state.rawValue : ObservedLinkState.unknown.rawValue)).font(.headline)
                        Button(L("Read Bluetooth entries for association")) { bluetooth.refresh() }
                        Text(bluetooth.status)
                        ForEach(bluetooth.entries) { entry in
                            Button(L("Associate {0} with this profile", entry.name)) {
                                if let other = store.archive.pairs.first(where: { $0.id != pair.id && $0.bluetoothID == entry.id }) { message = L("This Bluetooth identity already belongs to {0}. Select that profile instead.", other.name); return }
                                guard let index = store.archive.pairs.firstIndex(where: { $0.id == pair.id }) else { return }
                                store.archive.pairs[index].bluetoothID = entry.id; store.save()
                                if store.error == nil { connection.start(store.archive.pairs[index]) }
                            }.disabled(store.error != nil)
                        }
                        if thisWatch, let date = connection.checkedAt { Text(L("Checked at {0}", date.formatted(.dateTime.hour().minute().second().locale(Localization.locale())))) }
                        Button(L("Start observing this pair")) { connection.start(currentPair) }
                        Button(L("Refresh connection")) { connection.refresh() }.disabled(!thisWatch)
                        Button(L("Stop connection monitoring")) { connection.stop() }.disabled(!thisWatch)
                        if thisWatch, let latest = connection.samples.last, connection.state == .connected, Date().timeIntervalSince(latest.date) < 15 {
                            Text(L("Raw RSSI: {0} · indicative signal only", String(latest.value))).font(.title3.monospacedDigit())
                            Chart(connection.samples) { sample in
                                LineMark(x: .value(L("Time"), sample.date), y: .value("RSSI", sample.value))
                            }.frame(height: 150).accessibilityLabel(L("Recent raw RSSI observations"))
                            if let best = connection.samples.map(\.value).max() { Text(L("Highest RSSI observed in this session: {0}", String(best))) }
                        } else { Text(L("RSSI unavailable. On iPhone, public APIs do not expose AirPods reception strength; on Mac it also depends on the Bluetooth module.")) }
                        if thisWatch { Text(connection.message) }
                        if !connection.disconnectNotice.isEmpty { Text(connection.disconnectNotice).foregroundStyle(.orange) }
                        Text(L("RSSI is not distance, audio quality or a health score. Walls, interference and orientation affect reception; no metre estimate is shown."))
                        Button(L("Allow silent disconnection notifications")) { Task { await connection.allowNotifications() } }
                        Toggle(L("Silent notifications for observed disconnections"), isOn: $connection.notificationsEnabled).disabled(!connection.notificationsAllowed)
                        Text(L("Only an observed connected-to-disconnected transition may alert. Manual audio-route changes and unknown Bluetooth states do not prove separation. iPhone monitoring cannot be guaranteed while suspended or closed; use Apple Find My separation alerts."))
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(L("Apple Find My · supported actions")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("This app cannot read the Find My network, activate Lost Mode, trigger an AirPods or case sound, or locate individual components through a public Apple API."))
                        if pair.device.findMySeparateComponents { Text(L("Apple documents separate earbud and case locations for this model in Find My. Use Apple Find My for those positions and per-component lost actions.")) }
                        else { Text(L("Separate case and earbud finding is not confirmed for this profile. Check Apple's model-specific guide; never infer it from the device name.")) }
                        if pair.device.findMySeparationDocumented { Text(L("In Apple Find My: Devices → your AirPods → Notify When Left Behind. For supported lost actions, enable the Find My network before loss, then follow Lost Mode or Show Contact Info in Find My.")) }
                        else { Text(L("Find My separation alerts are not documented for this profile. Check the exact model in Apple's current guide.")) }
                        #if os(macOS)
                        Button(L("Open Apple Find My on Mac")) {
                            if let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.apple.findmy") { NSWorkspace.shared.openApplication(at: url, configuration: .init()) { _, _ in } }
                            else { message = L("Open Apple's Find My app manually or use the official web link.") }
                        }
                        #else
                        Text(L("On iPhone, open Apple's Find My app from the Home Screen. No undocumented deep link is used."))
                        #endif
                        Link(L("Apple Find My on the web"), destination: URL(string: "https://www.icloud.com/find/")!)
                        Link(L("Apple AirPods finding guide"), destination: URL(string: "https://support.apple.com/guide/airpods/find-your-airpods-dev8e8b93d71/web")!)
                        Text(L("Available actions depend on model, account, region, battery and prior Find My setup. The web interface has fewer features, including no charging-case sound."))
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(L("Optional host location reference")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("Save this Mac or iPhone position only while the selected pair is observed connected. This is a host-position reference, never a live or last-known AirPods or case location. Location is requested only when you press the button."))
                        Button(L("Request host position while connected")) { location.request() }.disabled(!thisWatch || connection.state != .connected || location.pending)
                        Text(location.message)
                        if let candidate = location.result {
                            Text(coordinates(candidate))
                            Button(L("Save host position reference")) {
                                guard thisWatch, connection.state == .connected, candidate.valid(at: Date()), Date().timeIntervalSince(candidate.recordedAt) < 90 else { message = L("Connection or location is no longer recent. Check again before saving."); return }
                                details.location = candidate; save()
                            }
                        }
                        if let saved = details.location {
                            Text(L("Saved host reference · {0} · accuracy about {1} m", saved.recordedAt.formatted(.dateTime.day().month().year().hour().minute().locale(Localization.locale())), saved.accuracy.formatted(.number.precision(.fractionLength(0)).locale(Localization.locale()))))
                            Text(coordinates(saved)).textSelection(.enabled)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(L("Serial numbers and AppleCare+ · manual record")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("Read serials in Apple Bluetooth settings or on the device. We cannot read or authenticate them automatically. Coverage must be checked with Apple; a stored manual record is not live confirmation."))
                        TextField(L("Primary serial number"), text: $details.primarySerial).textFieldStyle(.roundedBorder)
                        if !pair.device.isMax {
                            TextField(L("Left earbud serial · optional"), text: $details.leftSerial).textFieldStyle(.roundedBorder)
                            TextField(L("Right earbud serial · optional"), text: $details.rightSerial).textFieldStyle(.roundedBorder)
                            TextField(L("Case serial · optional"), text: $details.caseSerial).textFieldStyle(.roundedBorder)
                        }
                        Link(L("Find the serial number · Apple"), destination: URL(string: "https://support.apple.com/108041")!)
                        Link(L("Check AppleCare+ with Apple"), destination: URL(string: "https://checkcoverage.apple.com/")!)
                        Picker(L("Coverage record"), selection: $details.coverage) { ForEach(CoverageRecord.allCases, id: \.self) { Text(L($0.rawValue)).tag($0) } }
                        Toggle(L("Record a coverage expiry date"), isOn: $hasExpiry)
                        if hasExpiry { DatePicker(L("Coverage expiry · manual"), selection: $expiry, displayedComponents: .date) }
                        Button(L("I checked coverage with Apple now")) { details.coverageCheckedAt = Date() }
                        if let checked = details.coverageCheckedAt { Text(L("Manual coverage check recorded at {0}", checked.formatted(.dateTime.day().month().year().hour().minute().locale(Localization.locale())))) }
                        if let date = details.coverageExpiresAt, date < Date(), details.coverage == .active { Text(L("The recorded expiry has passed. Verify coverage with Apple again.")).foregroundStyle(.orange) }
                        Button(L("Save device details")) { save() }.disabled(store.error != nil)
                        Text(L("Serials and saved host coordinates stay in the local journal and are included in JSON exports. They are not submitted automatically to Apple or any third party."))
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                Text(message)
            }.padding(20)
        }.frame(minWidth: platformSheetWidth(350), minHeight: minimumHeight)
            .buttonStyle(LargeButtonStyle()).controlSize(.large)
            .onAppear {
                details = store.archive.pairs.first(where: { $0.id == pair.id })?.details ?? PairDetails()
                hasExpiry = details.coverageExpiresAt != nil; expiry = details.coverageExpiresAt ?? Date()
            }
    }
    private var minimumHeight: CGFloat {
        #if os(macOS)
        520
        #else
        0
        #endif
    }
    private func coordinates(_ memo: HostLocationMemo) -> String {
        memo.latitude.formatted(.number.grouping(.never).precision(.fractionLength(5)).locale(Localization.locale())) + ", " + memo.longitude.formatted(.number.grouping(.never).precision(.fractionLength(5)).locale(Localization.locale())) + " · " + memo.hostPlatform
    }
    private func save() {
        details.normalizeSerials(); details.coverageExpiresAt = hasExpiry ? expiry : nil
        guard details.validSerials else { message = L("Serials may contain only letters and digits, up to 40 characters; empty optional fields are allowed."); return }
        guard details.coverage == .unknown || details.coverageCheckedAt != nil else { message = L("Confirm a manual Apple coverage check before saving an active or inactive coverage record."); return }
        guard let index = store.archive.pairs.firstIndex(where: { $0.id == pair.id }) else { return }
        store.archive.pairs[index].details = details; store.save()
        message = store.error == nil ? L("Device details saved locally.") : L("Saving failed. Check the journal error before continuing.")
    }
}
