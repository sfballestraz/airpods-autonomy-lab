import SwiftUI
import WidgetKit
#if os(iOS)
import ActivityKit
#endif
#if canImport(MonitorCore)
import MonitorCore
#endif

@MainActor
final class LiveMonitor: ObservableObject {
    @Published var message = ""
    var supported: Bool {
        #if os(iOS)
        ActivityAuthorizationInfo().areActivitiesEnabled
        #else
        false
        #endif
    }
    func publish(_ snapshot: WidgetSnapshot) async {
        do { try SharedSnapshotStore.write(snapshot); WidgetCenter.shared.reloadAllTimelines(); message = L("Widget snapshot saved. The system controls refresh timing.") }
        catch { message = L("Widget storage is unavailable. Configure the same registered App Group for the app and extension in Xcode. Local battery history is still saved.") }
        #if os(iOS)
        for activity in Activity<MonitorActivityAttributes>.activities where activity.attributes.pairID == snapshot.readings.first?.pairID.uuidString {
            await activity.update(ActivityContent(state: .init(snapshot: snapshot), staleDate: snapshot.staleDate))
        }
        #endif
    }
    func start(pairID: UUID, snapshot: WidgetSnapshot) async {
        #if os(iOS)
        guard supported else { message = L("Live Activities are unavailable or disabled. Use the in-app indicator or widget."); return }
        guard !snapshot.readings.isEmpty else { message = L("Add a battery observation first."); return }
        await end()
        do {
            _ = try Activity<MonitorActivityAttributes>.request(attributes: .init(pairID: pairID.uuidString), content: ActivityContent(state: .init(snapshot: snapshot), staleDate: snapshot.staleDate), pushType: nil)
            message = L("Live Activity started. Values are observations, not automatic telemetry.")
        } catch { message = L("Live Activity failed: {0}", error.localizedDescription) }
        #else
        message = L("Dynamic Island is an iPhone feature. Use the widget on Mac.")
        #endif
    }
    func end() async {
        #if os(iOS)
        for activity in Activity<MonitorActivityAttributes>.activities { await activity.end(nil, dismissalPolicy: .immediate) }
        #endif
        message = L("Live Activity stopped.")
    }
    func trackChanged(_ title: String?) async {
        if var snapshot = SharedSnapshotStore.read() {
            snapshot.trackTitle = title; snapshot.publishedAt = Date()
            try? SharedSnapshotStore.write(snapshot); WidgetCenter.shared.reloadAllTimelines()
        }
        #if os(iOS)
        for activity in Activity<MonitorActivityAttributes>.activities {
            var snapshot = activity.content.state.snapshot
            snapshot.trackTitle = title; snapshot.publishedAt = Date()
            await activity.update(ActivityContent(state: .init(snapshot: snapshot), staleDate: snapshot.staleDate))
        }
        #endif
    }
}
