import SwiftUI
import Charts
import SwiftData
import Vision
import AppIntents
import UserNotifications
import CoreAudio
import AudioToolbox
#if os(iOS)
import HealthKit
#endif
import ImageIO
import UniformTypeIdentifiers
#if os(macOS)
import IOBluetooth
import CoreBluetooth
#else
import AVFAudio
#endif
#if canImport(MonitorCore)
import MonitorCore
#endif

@MainActor
final class Store: ObservableObject {
    var onSaved: (@MainActor (Archive) -> Void)?
    @Published var archive = Archive()
    @Published var error: String?
    @Published var serviceWarning = ""
    @Published var cleanupMessage = ""
    @Published var lastBackup: Date?
    var sync: JournalSync?
    let url: URL
    init(journalURL: URL? = nil) {
        url = journalURL ?? URL.applicationSupportDirectory.appending(path: "AirPodsMonitor/journal.json")
        if FileManager.default.fileExists(atPath: url.path) {
            do { archive = try JSONDecoder().decode(Archive.self, from: Data(contentsOf: url)) }
            catch { self.error = L("Jurnalul nu a putut fi citit. Fișierul existent este păstrat. Păstrează o copie a originalului din Application Support înainte de recuperare. {0}", String(describing: error.localizedDescription)) }
        }
    }
    func save() {
        guard error == nil else { return }
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            archive = try ExactDuplicates.archive(archive)
            try sync?.publish(archive)
            #if os(iOS)
            try JSONEncoder().encode(archive).write(to: url, options: [.atomic, .completeFileProtectionUnlessOpen])
            #else
            try JSONEncoder().encode(archive).write(to: url, options: .atomic)
            #endif
            onSaved?(archive)
            do { try sync?.automaticBackup() } catch { serviceWarning = error.localizedDescription }
        } catch { self.error = L("Salvarea a eșuat: {0}. Datele rămân în memorie; exportă jurnalul.", String(describing: error.localizedDescription)) }
    }
}
struct JSONDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json, .commaSeparatedText, .zip, UTType(filenameExtension:"xlsx") ?? .data, .data] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper { FileWrapper(regularFileWithContents: data) }
}
@main
struct MonitorApp: App {
    @StateObject private var store = Store()
    @StateObject private var audio = AudioLab()
    @StateObject private var live = LiveMonitor()
    @StateObject private var alerts = BatteryAlerts()
    @StateObject private var connection = ConnectionMonitor()
    @StateObject private var navigation = MonitorNavigation()
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("appLanguage") private var language = "system"
    var body: some Scene {
        WindowGroup {
            Home().environmentObject(store).environmentObject(audio).environmentObject(live).environmentObject(alerts).environmentObject(connection).environmentObject(navigation)
                .onAppear { if store.sync == nil && store.error == nil { do { store.sync = try JournalSync(store: store) } catch { store.error = error.localizedDescription } }; alerts.prime(store.archive); store.onSaved = { archive in alerts.process(archive) }; audio.onPlaybackChange = { title in Task { await live.trackChanged(title) } }; Task { await alerts.refreshNotificationStatus(); await live.trackChanged(audio.playing ? audio.title : nil) } }
                .environment(\.locale, Localization.locale())
                .id(language)
                .onChange(of: language) { _, _ in live.message = ""; audio.message = ""; alerts.message = ""; connection.message = ""; connection.disconnectNotice = "" }
                .onChange(of: scenePhase) { _, phase in if phase == .active { connection.refresh() } else { connection.suspend() } }
        }
    }
}
struct LargeButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.padding(.horizontal, 14).frame(minHeight: 44)
            .background(Color.accentColor.opacity(configuration.isPressed ? 0.25 : 0.12), in: RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.accentColor.opacity(0.4)))
            .opacity(enabled ? 1 : 0.5)
    }
}
struct Home: View {
    @EnvironmentObject var store: Store
    @EnvironmentObject var navigation: MonitorNavigation
    @State private var selectedPairID = AirPodsPair.initial[0].id
    @State private var showingLab = false
    @State private var showingTransfer = false
    @State private var showingPivot = false
    @State private var editingPairs = false
    @State private var showingDeviceDetails = false
    @State private var showingQuickGuide = false
    @State private var showingPrivacy = false
    @State private var showingUpdates = false
    @StateObject private var updates = AppUpdates()
    @EnvironmentObject var connection: ConnectionMonitor
    @AppStorage("appLanguage") private var language = "system"
    var pair: AirPodsPair { store.archive.pairs.first { $0.id == selectedPairID } ?? store.archive.pairs[0] }
    var device: Device { pair.device }
    @State private var export = false
    @State private var exportData = Data()
    @State private var status = ""
    private var minimumWidth: CGFloat {
        #if os(macOS)
        760
        #else
        0
        #endif
    }
    private var minimumHeight: CGFloat {
        #if os(macOS)
        600
        #else
        0
        #endif
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            AppNavBar(canGoBack:navigation.history.canGoBack,back:{ navigation.back() },home:{ navigation.home() })
            HStack(spacing:12) { BrandIcon().frame(width:40,height:40).accessibilityHidden(true); Text("AirPods Autonomy Lab").font(.title2.bold()).accessibilityAddTraits(.isHeader) }
            #if LOCAL_MAC_DEBUG
            Text(L("Local Mac debug · shared widget storage requires the signed standard scheme")).font(.caption)
            #endif
            Picker(L("Pereche AirPods"), selection: $selectedPairID) {
                ForEach(store.archive.pairs) { Text(L("{0} · {1}", String(describing: $0.name), String(describing: L($0.device.displayName)))).tag($0.id) }
            }
            HStack {
                Button(L("Perechile mele")) { editingPairs = true }.disabled(store.error != nil).accessibilityLabel(L("Perechile mele · adaugă sau redenumește"))
                Button(L("Connection and finding")) { showingDeviceDetails = true }
            }
            if !connection.disconnectNotice.isEmpty { Text(connection.disconnectNotice).foregroundStyle(.orange) }
            Picker(L("Limba interfeței"), selection: $language) {
                Text(L("Limba sistemului")).tag("system")
                Text("Română").tag("ro")
                Text("Français").tag("fr")
                Text("English").tag("en")
            }
            Text(L("Păstrează ciorna înainte de a schimba limba; formularul nesalvat se resetează.")).font(.caption)
            Text(L(device.models)).foregroundStyle(.secondary)
            if let error = store.error { Text(error).foregroundStyle(.red).textSelection(.enabled) }
            LowBatteryBanner(pair: pair)
            #if os(iOS)
            nativeTabs.toolbar(.hidden, for: .tabBar)
            HStack(spacing: 4) {
                ForEach(0..<5) { index in
                    Button { navigation.select(index) } label: {
                        VStack(spacing: 5) {
                            Image(systemName: sectionIcons[index])
                            Text(L(sectionTitles[index])).font(.caption).lineLimit(1)
                        }.frame(maxWidth: .infinity, minHeight: 56)
                            .background(navigation.history.current == index ? Color.accentColor.opacity(0.15) : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                    }.buttonStyle(.plain)
                        .accessibilityLabel(L(sectionLabels[index]))
                        .accessibilityAddTraits(navigation.history.current == index ? .isSelected : [])
                        .accessibilityRemoveTraits(navigation.history.current == index ? [] : .isSelected)
                        .accessibilityIdentifier("section.\(index)")
                }
            }
            #else
            nativeTabs
            #endif
            Menu { footerActions } label: { Label(N("Instrumente și date", "Outils et données"),systemImage:"ellipsis.circle") }
                .accessibilityHint(N("Tabel pivot, backup, laborator și ghid", "Tableau croisé, sauvegarde, laboratoire et guide"))
            if store.archive.pairs.contains(where: { $0.details != nil }) { Text(L("JSON export includes saved serial numbers and host location references. Review before sharing.")).font(.caption) }
        }
        .padding(20).frame(minWidth: minimumWidth, minHeight: minimumHeight)
        .buttonStyle(LargeButtonStyle()).controlSize(.large)
        .onAppear {
            if UserDefaults.standard.bool(forKey:"pendingLabIncident") { showingLab = true }
            if let saved = UserDefaults.standard.string(forKey: "selectedPairID"), let id = UUID(uuidString: saved), store.archive.pairs.contains(where: { $0.id == id }) { selectedPairID = id }
            else { selectedPairID = pair.id }
        }
        .onChange(of: selectedPairID) { _, id in UserDefaults.standard.set(id.uuidString, forKey: "selectedPairID") }
        .onReceive(NotificationCenter.default.publisher(for: UserDefaults.didChangeNotification)) { _ in
            if UserDefaults.standard.bool(forKey: "pendingLabIncident") { showingLab = true }
        }
        .onChange(of:navigation.homeToken) { _,_ in showingTransfer = false; showingLab = false; showingQuickGuide = false; showingPrivacy = false; showingUpdates = false; editingPairs = false; showingDeviceDetails = false; showingPivot = false }
        .sheet(isPresented:$showingPivot) { DestinationShell(title:N("Analiză pivot", "Analyse croisée")) { PivotPage().environmentObject(store) } }
        .sheet(isPresented: $showingTransfer) { DestinationShell(title:N("Backup și date", "Sauvegarde et données")) { TransferPanel().environmentObject(store) } }
        .sheet(isPresented: $showingLab) { DestinationShell(title:"Autonomy Lab") { LabRoot(pair: pair).environmentObject(store) } }
        .task { if UserDefaults.standard.bool(forKey: "automaticAppUpdates") { await updates.check(automatic: true) } }
        .sheet(isPresented:$showingUpdates) { DestinationShell(title:N("Actualizări și noutăți", "Mises à jour et nouveautés")) { AppUpdatesView(updates: updates) } }
        .sheet(isPresented:$showingPrivacy) { DestinationShell(title:N("Confidențialitate", "Confidentialité")) { PrivacyOverview() } }
        .sheet(isPresented: $showingQuickGuide) { DestinationShell(title:N("Ghid", "Guide")) { QuickEntryGuide() } }
        .sheet(isPresented: $editingPairs) { DestinationShell(title:N("Perechile mele", "Mes appareils")) { PairManager(selectedPairID: $selectedPairID).environmentObject(store) } }
        .sheet(isPresented: $showingDeviceDetails) { DestinationShell(title:N("Conexiune", "Connexion")) { DeviceFindingPage(pair: pair).environmentObject(store).environmentObject(connection) } }
        .fileExporter(isPresented: $export, document: JSONDocument(data: exportData), contentType: .json, defaultFilename: L("AirPods-jurnal")) { result in
            switch result { case .success: status = L("Jurnal exportat."); case .failure(let error): status = L("Export nereușit: {0}", String(describing: error.localizedDescription)) }
        }
    }
    @ViewBuilder private var footerActions: some View {
                Button(L("Exportă jurnalul JSON")) {
                    do { exportData = try JSONEncoder().encode(store.archive); export = true }
                    catch { status = error.localizedDescription }
                }
                Button(L("Quick guide")) { showingQuickGuide = true }
                Button(N("Actualizări și noutăți", "Mises à jour et nouveautés")) { showingUpdates = true }
                Button(N("Confidențialitate", "Confidentialité")) { showingPrivacy = true }
                Button("Autonomy Lab") { showingLab = true }
                Button("Backup · iCloud") { showingTransfer = true }
                Button(N("Tabel și grafic pivot", "Tableau et graphique croisés")) { showingPivot = true }
                Text(status).font(.callout)
    }
    private let sectionTitles = ["Overview", "Test", "History", "Firmware", "EQ"]
    private let sectionLabels = ["Overview", "Test autonomie", "Jurnal și comparații", "Firmware", "Audio / EQ"]
    private let sectionIcons = ["battery.75percent", "timer", "chart.bar", "checkmark.shield", "slider.horizontal.3"]
    private var nativeTabs: some View {
            TabView(selection: navigation.selection) {
                DashboardPage(pair: pair).id(pair.id).monitorTabVisibility().tabItem { Label(L("Overview"), systemImage: "battery.75percent") }.tag(0)
                TestPage(pair: pair).id(pair.id).monitorTabVisibility().tabItem { Label(L("Test autonomie"), systemImage: "timer") }.tag(1)
                HistoryPage(pair: pair).id(pair.id).monitorTabVisibility().tabItem { Label(L("Jurnal și comparații"), systemImage: "chart.bar") }.tag(2)
                FirmwarePage(device: device).id(pair.id).monitorTabVisibility().tabItem { Label(L("Firmware"), systemImage: "checkmark.shield") }.tag(3)
                AudioLabPage().monitorTabVisibility().tabItem { Label(L("Audio / EQ"), systemImage: "slider.horizontal.3") }.tag(4)
            }
    }

}
struct TestPage: View {
    let pair: AirPodsPair
    var device: Device { pair.device }
    @EnvironmentObject var store: Store
    @EnvironmentObject var audio: AudioLab
    @State private var contentID = ""
    @State private var temperature = ""
    @State private var audioRoute = ""
    @State private var channel = "unknown"
    @State private var usage = "L+R"
    private var conditions: LabConditions? {
        guard let value = Double(temperature.replacingOccurrences(of:",",with:".")), !contentID.isEmpty, !audioRoute.isEmpty else { return nil }
        return LabConditions(contentID:contentID, temperatureC:value, route:audioRoute, firmwareChannel:channel, usage:usage)
    }
    @State private var usesPlayer = false
    @State private var capturedRevision: Int?
    @State private var capturedEQ: String?
    @State private var eqChanged = false
    @State private var start = Date()
    @State private var end = Date().addingTimeInterval(4500)
    @State private var volume = 25
    @State private var mode = "Oprit"
    @State private var environment = "Interior liniștit"
    @State private var place: TestLocation = .quietIndoor
    @State private var noise: DeclaredNoise = .unknown
    @State private var placeDetails = ""
    @State private var hasContext = true
    @State private var firmware = ""
    @State private var source = "iPhone 16 Pro Max"
    private var sourceOptions: [String] {
        var options = ["iPhone 16 Pro Max", "MacBook Pro 16 M5 Max", "iPad"]
        if !options.contains(source) { options.append(source) }; return options
    }
    @State private var activity = "Muzică"
    @State private var notes = ""
    @State private var interrupted = false
    @State private var measurementsConfirmed = false
    @State private var savedID: UUID?
    @State private var enabled = [true, true, false, false]
    @State private var initial = [100,100,100,100]
    @State private var final = [80,80,90,80]
    @State private var message = ""
    var processingChanged: Bool { eqChanged || (usesPlayer && ((capturedEQ != nil && capturedEQ != audio.protocolSignature) || (capturedRevision != nil && capturedRevision != audio.settingsRevision))) }
    var session: Session {
        Session(device: device, pairID: pair.id, eqSignature: usesPlayer ? (capturedEQ ?? audio.protocolSignature) : nil, start: start, end: end, volume: volume, mode: mode, environment: hasContext ? place.legacyValue : environment, firmware: firmware.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Necunoscut" : firmware.trimmingCharacters(in: .whitespacesAndNewlines), source: source, activity: activity, notes: notes, interrupted: interrupted || processingChanged, samples: device.components.enumerated().compactMap { i,c in enabled[i] ? BatterySample(component: c, initial: initial[i], final: final[i]) : nil }, conditions:conditions, testContext:hasContext ? TestContext(location:place,noise:noise,details:placeDetails.trimmingCharacters(in:.whitespacesAndNewlines)) : nil)
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("{0} · măsurare manuală, fără sunete", String(describing: pair.name))).font(.headline)
                Text(L("Citește procentele în interfața Apple. Nu avem citire automată garantată pentru căști, carcasă sau firmware. Valorile de mai jos sunt exemple până le înlocuiești."))
                GroupBox(L("Rutina ta · ora locală a dispozitivului")) {
                    VStack(alignment: .leading) {
                        Text(L("Luni–vineri: 07:45–09:30 și 13:45–15:00\nWeekend: 13:45–15:00"))
                        ForEach(Array(Routine.intervals(on: Date()).enumerated()), id: \.offset) { i,slot in
                            Button(L("Folosește intervalul {0} de azi", String(describing: i + 1))) { start = slot.0; end = slot.1 }
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                DatePicker(L("Început"), selection: $start)
                DatePicker(L("Sfârșit"), selection: $end)
                HStack {
                    Button(L("Începe acum și păstrează ciorna")) { savedID = nil; measurementsConfirmed = false; eqChanged = false; capturedEQ = usesPlayer ? audio.protocolSignature : nil; capturedRevision = usesPlayer ? audio.settingsRevision : nil; start = Date(); end = start.addingTimeInterval(4500); saveDraft() }
                    Button(L("Sfârșit acum")) { end = Date() }
                }
                Text(L("Cronometrarea folosește datele de mai sus; aplicația poate fi închisă după salvarea ciornei.")).font(.callout)
                ForEach(Array(device.components.enumerated()), id: \.offset) { i,c in
                    GroupBox {
                        VStack(alignment: .leading) {
                            Toggle(L("Măsoară: {0}", String(describing: L(c.rawValue))), isOn: $enabled[i])
                            if enabled[i] {
                                PercentageControl(title: L("Initial battery"), value: $initial[i])
                                PercentageControl(title: L("Final battery"), value: $final[i])
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                Toggle(L("This test uses the app’s audio player and EQ"), isOn: $usesPlayer)
                    .onChange(of: usesPlayer) { _, enabled in if enabled { if capturedEQ == nil { capturedEQ = audio.protocolSignature; capturedRevision = audio.settingsRevision } } else { capturedEQ = nil; capturedRevision = nil } }
                Text(L("EQ settings form part of the comparison protocol. A change during a test excludes it from automatic comparisons.")).font(.callout)
                if processingChanged { Text(L("Processing or player volume changed during this test. It will be excluded from comparisons.")) }
                Text(L("Modul este consemnat manual pentru test. Schimbă-l în Configurări sau prin comenzile AirPods; aplicația nu controlează ANC ori Adaptiv.")).font(.callout)
                if device == .other { Text(L("Pentru un model necunoscut, modurile sunt doar etichete declarate de tine, nu funcții confirmate. Testele sunt excluse din comparațiile automate.")) }
                PercentageControl(title: L("Declared listening volume"), value: $volume)
                Picker(L("Mod audio"), selection: $mode) {
                    ForEach(device.audioModes, id: \.self) { Text(L($0)).tag($0) }
                }
                GroupBox(N("Locul și mediul testului", "Lieu et environnement du test")) {
                    VStack(alignment:.leading,spacing:12) {
                        Picker(N("Tip de loc", "Type de lieu"),selection:Binding(get:{ place },set:{ place = $0; hasContext = true })) {
                            ForEach(TestLocation.allCases,id: \.self) { Text($0.title(language:Localization.language())).tag($0) }
                        }.accessibilityIdentifier("test.location")
                        Picker(N("Zgomot apreciat de tine", "Bruit estimé par vous"),selection:Binding(get:{ noise },set:{ noise = $0; hasContext = true })) {
                            ForEach(DeclaredNoise.allCases,id: \.self) { Text($0.title(language:Localization.language())).tag($0) }
                        }
                        TextField(N("Detalii opționale · pentru Mixt sau Alt loc sunt necesare", "Détails facultatifs · requis pour Mixte ou Autre lieu"),text:Binding(get:{ placeDetails },set:{ placeDetails = $0; hasContext = true }),axis:.vertical)
                        Text(N("Exemplu mixt: tren 30 min + autobuz 20 min. Pentru comparații precise, salvează teste separate pentru fiecare loc. Nivelul de zgomot este o apreciere, nu o măsurătoare în decibeli. Nu se activează microfonul sau GPS-ul.", "Exemple mixte : train 30 min + bus 20 min. Pour des comparaisons précises, enregistrez des tests séparés par lieu. Le bruit est une appréciation, pas une mesure en décibels. Aucun microphone ni GPS n’est activé."))
                        if place == .mixed { Text(N("Testul mixt se păstrează în jurnal și în numărători, dar este exclus din comparațiile automate de consum.", "Le test mixte reste dans le journal et les comptages, mais est exclu des comparaisons automatiques de décharge.")) }
                        if !hasContext { Text(N("Eticheta veche este păstrată: ", "Ancienne étiquette conservée : ") + environment) }
                    }
                }
                Picker(L("Sursă audio"), selection: $source) { ForEach(sourceOptions, id: \.self) { Text(L($0)) } }
                Picker(L("Activitate"), selection: $activity) { ForEach(["Muzică", "Apeluri", "Video", "Mixt"], id: \.self) { Text(L($0)) } }
                TextField(L("Firmware observat (sau Necunoscut)"), text: $firmware).textFieldStyle(.roundedBorder)
                TextField("Conținut / Contenu · ID playlist, fișier / fichier", text:$contentID)
                TextField("Temperatură / Température · °C", text:$temperature)
                TextField("Audio route · Bluetooth A2DP / HFP…", text:$audioRoute)
                Picker("Canal firmware / Canal du firmware", selection:$channel) {
                    Text("Stabil / Stable").tag("stable"); Text("Beta").tag("beta"); Text("Necunoscut / Inconnu").tag("unknown")
                }
                Picker("Utilizare / Utilisation", selection:$usage) { ForEach(["L+R", "L", "R"], id: \.self) { Text($0).tag($0) } }
                if conditions == nil { Text("Comparație parțială: completează conținutul, temperatura și ruta pentru predicții. / Comparaison partielle : compléter contenu, température et route pour les estimations.") }
                TextField(L("Note: conținut, temperatură, pauze, încărcare"), text: $notes, axis: .vertical).textFieldStyle(.roundedBorder)
                Toggle(L("Au existat pauze sau încărcări"), isOn: $interrupted)
                Text(L("La creșterea bateriei nu calculăm consumul. Carcasa care încarcă căștile nu măsoară autonomia de ascultare. Folosește aceeași sursă, volum, conținut și mediu la comparații.")).font(.callout)
                Toggle(L("Am introdus valorile măsurate, nu exemplele"), isOn: $measurementsConfirmed)
                VStack(alignment: .leading, spacing: 12) {
                    Button(L("Salvează testul")) {
                        if let reason = session.validation { message = L(reason); return }
                        guard measurementsConfirmed else { message = L("Confirmă că ai introdus valorile măsurate."); return }
                        guard savedID == nil else { message = L("Testul a fost deja salvat. Începe un test nou."); return }
                        let record = session; store.archive.sessions.append(record); savedID = record.id; if store.archive.draft?.pairID == pair.id { store.archive.draft = nil }; store.save()
                        message = store.error == nil ? L("Test salvat. Îl găsești în jurnal.") : L("Testul este în memorie; verifică eroarea de salvare.")
                    }.disabled(store.error != nil)
                    Button(L("Păstrează ciorna")) { saveDraft() }.disabled(store.error != nil)
                    Button(L("Test nou")) { savedID = nil; measurementsConfirmed = false; eqChanged = false; capturedEQ = usesPlayer ? audio.protocolSignature : nil; capturedRevision = usesPlayer ? audio.settingsRevision : nil; start = Date(); end = start.addingTimeInterval(4500); message = L("Introdu măsurătorile pentru noul test.") }
                }
                if let draft = store.archive.draft {
                    Button(L("Reia ciorna · {0}", String(describing: store.archive.pairs.first { $0.id == draft.pairID }?.name ?? L(draft.device.displayName)))) { restore(draft) }.disabled(draft.pairID != pair.id)
                    Text(L("Ciorna se păstrează doar la apăsarea butonului. O singură ciornă pentru toate perechile; salvarea alteia o înlocuiește.")).font(.caption)
                }
                Text(message).accessibilityLabel(L("Stare: {0}", String(describing: message)))
            }.padding()
        }.onChange(of: device) { _,_ in mode = device.audioModes[0] }
        .onChange(of: audio.settings) { _,_ in if usesPlayer && capturedEQ != nil { eqChanged = true } }
    }
    func saveDraft() { store.archive.draft = session; store.save(); message = store.error == nil ? L("Ciornă salvată.") : L("Ciorna nu a fost salvată pe disc.") }
    func restore(_ s: Session) {
        usesPlayer = s.eqSignature != nil; capturedEQ = s.eqSignature; capturedRevision = usesPlayer ? audio.settingsRevision : nil; eqChanged = s.eqSignature != nil && s.eqSignature != audio.protocolSignature
        contentID = s.conditions?.contentID ?? ""; temperature = s.conditions.map { String($0.temperatureC) } ?? ""; audioRoute = s.conditions?.route ?? ""; channel = s.conditions?.firmwareChannel ?? "unknown"; usage = s.conditions?.usage ?? "L+R"
        hasContext = s.testContext != nil; place = s.recordedLocation; noise = s.testContext?.noise ?? .unknown; placeDetails = s.testContext?.details ?? ""
        start = s.start; end = s.end; volume = s.volume; mode = s.mode; environment = s.environment; firmware = s.firmware.lowercased() == "necunoscut" ? "" : s.firmware; source = s.source; activity = s.activity; notes = s.notes; interrupted = s.interrupted
        for (i,c) in device.components.enumerated() { let b = s.samples.first { $0.component == c }; enabled[i] = b != nil; initial[i] = b?.initial ?? 100; final[i] = b?.final ?? 100 }
        message = L("Ciornă reluată.")
    }
}
struct HistoryPage: View {
    let pair: AirPodsPair
    var device: Device { pair.device }
    @EnvironmentObject var store: Store
    @State private var baseline: UUID?
    var sessions: [Session] { store.archive.sessions.filter { $0.pairID == pair.id }.sorted { $0.start > $1.start } }
    var reference: Session? { sessions.first { $0.id == baseline } }
    var compared: [Session] { guard let reference else { return [] }; return sessions.filter { $0.comparable && $0.sameProtocol(as: reference) } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(L("{0} · {1} teste", String(describing: pair.name), String(describing: sessions.count))).font(.headline)
                if sessions.isEmpty { Text(L("Nu ai teste salvate. Înregistrează primul test în fila Test autonomie.")) }
                else {
                    Picker(L("Protocol de comparat"), selection: $baseline) {
                        Text(L("Alege un test de referință")).tag(nil as UUID?)
                        ForEach(sessions.filter(\.comparable)) { s in Text(L("{0} · {1}% · {2} · {3}", String(describing: s.start.formatted(.dateTime.day().month(.abbreviated).year().hour().minute().locale(Localization.locale()))), String(describing: s.volume), String(describing: L(s.mode)), String(describing: L(s.environment)))).tag(Optional(s.id)) }
                    }
                    Text(L("Comparația include doar această pereche fizică, aceeași sursă, activitate, volum, mod și mediu, fără pauze/încărcare și cu firmware cunoscut. Duratele pot diferi; rata este normalizată pe oră. Nu este un diagnostic al sănătății bateriei.")).font(.callout)
                    if !compared.isEmpty {
                        Chart {
                            ForEach(compared) { s in
                                ForEach(s.samples, id: \.component) { sample in
                                    if let rate = sample.rate(hours: s.hours) {
                                        BarMark(x: .value(L("Test"), s.start.formatted(.dateTime.day().month().year().hour().minute().locale(Localization.locale()))), y: .value(L("Puncte procentuale pe oră"), rate))
                                            .foregroundStyle(by: .value(L("Componentă"), L(sample.component.rawValue)))
                                            .position(by: .value(L("Componentă"), L(sample.component.rawValue)))
                                    }
                                }
                            }
                        }.frame(height: 240).chartYAxisLabel(L("pp/oră"))
                        Text(L("Valorile accesibile ale graficului sunt și în lista de mai jos.")).font(.caption)
                        ForEach(device.components) { c in
                            let values = compared.compactMap { s in s.samples.first { $0.component == c }?.rate(hours: s.hours) }
                            if !values.isEmpty {
                                Text(L("{0}: medie {1} pp/oră · {2} măsurători", String(describing: L(c.rawValue)), String(describing: (values.reduce(0,+) / Double(values.count)).formatted(.number.precision(.fractionLength(1)).locale(Localization.locale()))), String(describing: values.count)))
                            }
                        }
                    }
                    ForEach(sessions) { s in
                        GroupBox {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(s.start.formatted(.dateTime.day().month(.abbreviated).year().hour().minute().locale(Localization.locale()))).font(.headline)
                                Text(L("{0} minute · firmware {1} · {2}% · {3}", String(describing: Int(s.hours * 60)), String(describing: s.firmware.lowercased() == "necunoscut" ? L("Necunoscut") : s.firmware), String(describing: s.volume), String(describing: L(s.mode))))
                                Text(L("{0} · {1} · {2}", String(describing: s.source), String(describing: L(s.activity)), String(describing: L(s.environment))))
                                ForEach(s.samples, id: \.component) { b in
                                    Text(L("{0}: {1}% → {2}% · {3}", String(describing: L(b.component.rawValue)), String(describing: b.initial), String(describing: b.final), String(describing: rateText(b,s))))
                                }
                                if !s.comparable { Text(L("Test exclus din comparații: model/mod neconfirmat, date incompatibile, pauze, încărcare, creșterea bateriei sau firmware necunoscut.")).foregroundStyle(.secondary) }
                                if let context = s.testContext { Text(context.location.title(language:Localization.language()) + " · " + context.noise.title(language:Localization.language()) + (context.details.isEmpty ? "" : " · " + context.details)) }
                                if s.eqSignature != nil { Text(L("Recorded with this app’s player EQ; compared only with matching EQ settings.")).font(.caption) }
                                if !s.notes.isEmpty { Text(s.notes) }
                            }.frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                        }
                    }
                }
            }.padding()
        }.onChange(of: device) { _,_ in baseline = nil }
    }
    func rateText(_ b: BatterySample, _ s: Session) -> String {
        guard let rate = b.rate(hours: s.hours) else { return L("consum necalculabil (încărcare sau date invalide)") }
        return L("{0} pp/oră", String(describing: rate.formatted(.number.precision(.fractionLength(1)).locale(Localization.locale()))))
    }
}
struct FirmwarePage: View {
    let device: Device
    @AppStorage("firmwareSilentNotifications") private var silentFirmwareNotifications = false
    @State private var observed = ""
    @State private var official = ""
    @State private var checked = false
    @State private var fetching = false
    @State private var fetchMessage = ""
    @State private var fetchedVersion: String?
    @State private var fetchedAt: Date?
    var comparison: FirmwareComparison { FirmwareComparison.compare(installed: observed, official: official, verified: checked) }
    @State private var waitingSince: Date?
    @State private var steps = Set<Int>()
    var guide: [String] {
        if device.isMax { return [L("Actualizează macOS/iOS, activează Bluetooth și conectează AirPods Max."), L("Conectează iPhone-ul sau Mac-ul la Wi-Fi și AirPods Max la alimentare prin cablu."), L("Ține AirPods Max în raza Bluetooth cel puțin 30 de minute."), L("Reconectează AirPods Max și citește din nou versiunea în Configurări.")] }
        if device == .other { return [L("Identifică modelul pe pagina Apple înainte de a urma instrucțiunile de actualizare."), L("Folosește procedura Apple pentru modelul identificat; nu presupune că acesta are o carcasă de încărcare.")] }
        return [L("Actualizează macOS/iOS și activează Bluetooth."), L("Conectează AirPods la iPhone sau Mac și conectează dispozitivul la Wi-Fi."), L("Conectează carcasa la alimentare, pune ambele căști înăuntru și închide capacul."), L("Ține carcasa în raza Bluetooth cel puțin 30 de minute."), L("Redeschide capacul, reconectează AirPods și citește din nou versiunea în Configurări.")]
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("Actualizarea este automată")).font(.headline)
                Text(L("Aplicația te ghidează; nu poate forța, instala sau confirma singură un firmware. Un cronometru terminat nu dovedește instalarea."))
                Link(L("Deschide versiunile oficiale Apple"), destination: URL(string: "https://support.apple.com/106340")!)
                if let version = device.referenceFirmware {
                    Text(L("Referință verificată la 20.10.2026: {0} — {1}. Poate fi învechită; verifică pagina Apple pentru versiunea actuală.", String(describing: L(device.displayName)), String(describing: version)))
                } else {
                    Text(L("Nu avem o versiune de referință inclusă pentru acest model. Verifică pagina Apple și copiază versiunea pentru generația și varianta corectă."))
                }
                Link(L("Verifică modelul la Apple"), destination: URL(string: "https://support.apple.com/109525")!)
                Text(L("Citește firmware-ul pe Mac: Configurări sistem → Bluetooth → informații lângă AirPods. Pe iPhone: Configurări → Bluetooth → informații → Despre."))
                TextField(L("Versiune observată pe AirPods"), text: $observed).textFieldStyle(.roundedBorder)
                TextField(L("Versiune actuală copiată de pe pagina Apple"), text: $official).textFieldStyle(.roundedBorder)
                Toggle(L("Am verificat acum pagina oficială pentru modelul selectat"), isOn: $checked)
                Button(L("Check Apple firmware now")) { Task { await fetchOfficial() } }
                    .disabled(fetching || device == .other).frame(minHeight: 44)
                Toggle("Notificări silențioase · numai versiuni stabile noi și relevante / Notifications silencieuses · versions stables nouvelles et pertinentes", isOn:$silentFirmwareNotifications)
                    .onChange(of:silentFirmwareNotifications) { _, enabled in
                        if enabled { Task { do { let allowed = try await UNUserNotificationCenter.current().requestAuthorization(options:[.alert]); if !allowed { silentFirmwareNotifications = false } } catch { silentFirmwareNotifications = false; fetchMessage = error.localizedDescription } } }
                    }
                if fetching { ProgressView(L("Checking Apple…")) }
                if !fetchMessage.isEmpty { Text(fetchMessage) }
                if let fetchedAt, official == fetchedVersion {
                    Text(L("Apple reference checked at {0}", fetchedAt.formatted(.dateTime.day().month().year().hour().minute().locale(Localization.locale())))).font(.caption)
                }
                Label(comparisonText, systemImage: comparison == .upToDate ? "checkmark.shield" : (comparison == .updateAvailable ? "arrow.down.circle" : "questionmark.circle"))
                    .font(.headline).foregroundStyle(comparison == .upToDate ? Color.green : (comparison == .updateAvailable ? Color.orange : Color.primary)).textSelection(.enabled)
                Button(L("Read comparison status")) { AccessibilityNotification.Announcement(comparisonText).post() }.frame(minHeight: 44)
                Text(L("Status compares your manually entered installed version with the verified Apple reference. It does not read or install firmware."))
                ForEach(Array(guide.enumerated()), id: \.offset) { i,text in
                    Toggle(L("{0}. {1}", String(describing: i + 1), String(describing: text)), isOn: Binding(get: { steps.contains(i) }, set: { if $0 { steps.insert(i) } else { steps.remove(i) } }))
                }
                Button(L("Începe așteptarea de 30 minute")) { waitingSince = Date() }
                if let waitingSince {
                    TimelineView(.periodic(from: .now, by: 30)) { context in
                        let remaining = max(0, 30 - Int(context.date.timeIntervalSince(waitingSince) / 60))
                        Text(remaining > 0 ? L("Mai așteaptă aproximativ {0} minute. Fără alertă sonoră.", String(describing: remaining)) : L("Au trecut 30 minute. Reconectează și verifică manual versiunea."))
                    }
                    Text(L("Cronometrul este orientativ și se resetează la închiderea aplicației.")).font(.caption)
                }
                Text(L("Dacă versiunea nu se schimbă, consultă pașii de depanare din pagina Apple. Nu folosim API-uri private, comenzi de sistem ascunse sau decodarea reclamelor Bluetooth."))
            }.padding()
        }.onChange(of: official) { _, newValue in
            if newValue != fetchedVersion { checked = false; fetchedAt = nil }
        }.onChange(of: device) { _,_ in observed = ""; official = ""; checked = false; steps = []; waitingSince = nil; fetchedVersion = nil; fetchedAt = nil; fetchMessage = "" }
    }
    var comparisonText: String {
        switch comparison {
        case .unknown: return L("Status unknown · enter installed firmware and verify Apple reference")
        case .upToDate: return L("Up to date according to the entered version and checked Apple reference")
        case .updateAvailable: return L("A newer Apple firmware is available · follow the automatic update guide")
        case .differentOrBeta: return L("Different or unrecognized firmware · check the model and possible beta version")
        }
    }
    @MainActor func fetchOfficial() async {
        fetching = true; fetchMessage = ""; checked = false; fetchedVersion = nil; fetchedAt = nil
        defer { fetching = false; AccessibilityNotification.Announcement(fetchMessage + " " + comparisonText).post() }
        do {
            var request = URLRequest(url: AppleFirmwarePage.url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
            request.setValue("text/html", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let response = response as? HTTPURLResponse, response.statusCode == 200,
                  response.url?.scheme == "https", response.url?.host == "support.apple.com",
                  let html = String(data: data, encoding: .utf8), let version = AppleFirmwarePage.version(in: html, for: device) else {
                fetchMessage = L("Apple reference could not be verified. Open the official page and copy the version for your exact model."); return
            }
            fetchedVersion = version; official = version; fetchedAt = Date(); checked = true
            let key = "lastAppleStable." + device.rawValue
            let previous = UserDefaults.standard.string(forKey:key)
            UserDefaults.standard.set(version,forKey:key)
            if silentFirmwareNotifications, let previous, previous != version, comparison == .updateAvailable {
                let content = UNMutableNotificationContent()
                content.title = "AirPods · firmware Apple"; content.body = "\(device.displayName): \(version) · \(comparisonText)"; content.sound = nil
                try await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier:key + version,content:content,trigger:nil))
            }
            fetchMessage = L("Apple reference loaded. Enter the installed version shown in Bluetooth settings.")
        } catch {
            fetchMessage = L("Apple check failed. No up-to-date status can be confirmed; use the official page manually.")
        }
    }
}

struct PairManager: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    @Binding var selectedPairID: UUID
    @StateObject private var bluetooth = BluetoothList()
    @State private var bluetoothID: String?
    @State private var editingID: UUID?
    @State private var name = ""
    @State private var model: Device = .four
    @State private var message = ""
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("Perechile mele")).font(.title2.bold()).accessibilityAddTraits(.isHeader)
                Text(L("Alege nume distincte, de exemplu «Мария», «AirPods de serviciu» și «AirPods de acasă». Numele sunt locale în această aplicație; nu redenumesc dispozitivul în Bluetooth."))
                GroupBox(L("Nume din Bluetooth")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(bluetooth.explanation)
                        Button(L("Citește / reîmprospătează Bluetooth")) { bluetooth.refresh() }
                        Text(bluetooth.status)
                        ForEach(bluetooth.entries) { entry in
                            Button(L("{0} · {1} · {2}", String(describing: entry.name), String(describing: entry.connected ? L("Conectat") : L("Asociat")), String(describing: entry.id.suffix(5)))) {
                                bluetoothID = entry.id; message = ""
                                if let existing = store.archive.pairs.first(where: { $0.bluetoothID == entry.id }) {
                                    selectedPairID = existing.id; dismiss()
                                } else {
                                    editingID = nil; model = .other
                                    var proposed = entry.name; var suffix = 2
                                    while store.archive.nameError(proposed) != nil { proposed = String(entry.name.prefix(45)) + " (\(suffix))"; suffix += 1 }
                                    name = proposed
                                    message = L("Numele a fost copiat. Confirmă modelul înainte de salvare.")
                                }
                            }
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                ForEach(store.archive.pairs) { item in
                    GroupBox {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(item.name).font(.headline)
                            Text(L(item.device.displayName))
                            PairResetGuide(device: item.device)
                            Button(L("Redenumește {0}", String(describing: item.name))) { editingID = item.id; bluetoothID = item.bluetoothID; name = item.name; model = item.device; message = "" }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                Divider()
                Text(editingID == nil ? L("Adaugă o pereche") : L("Redenumește perechea")).font(.headline)
                TextField(L("Numele perechii"), text: $name).textFieldStyle(.roundedBorder)
                if editingID == nil {
                    Picker(L("Modelul perechii"), selection: $model) {
                        ForEach(Device.allCases) { Text(L($0.displayName)).tag($0) }
                    }
                    Text(L(model.models)).font(.callout)
                } else {
                    Text(L("Model: {0}. Pentru un alt dispozitiv fizic, adaugă o pereche nouă.", String(describing: L(model.displayName))))
                }
                Button(editingID == nil ? L("Adaugă și selectează perechea") : L("Salvează numele și selectează")) {
                    if let error = store.archive.nameError(name, excluding: editingID) { message = L(error); return }
                    let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
                    if let editingID, let index = store.archive.pairs.firstIndex(where: { $0.id == editingID }) {
                        store.archive.pairs[index].name = cleaned; selectedPairID = editingID
                    } else {
                        let item = AirPodsPair(name: cleaned, device: model, bluetoothID: bluetoothID)
                        store.archive.pairs.append(item); selectedPairID = item.id
                    }
                    store.save()
                    if store.error == nil { dismiss() } else { message = L("Salvarea pe disc a eșuat. Verifică eroarea din fereastra principală.") }
                }.disabled(store.error != nil)
                if editingID != nil { Button(L("Adaugă în schimb o pereche nouă")) { editingID = nil; bluetoothID = nil; name = ""; message = "" } }
                Text(message).foregroundStyle(.red)
                Text(L("Testele sunt legate de identificatorul perechii, nu de nume. Redenumirea păstrează istoricul; perechile cu același model au jurnale și comparații separate. Schimbarea perechii închide formularul nesalvat: păstrează ciorna mai întâi.")).font(.callout)
            }.padding(20)
        }.frame(minWidth: platformSheetWidth(350), minHeight: platformSheetMinimumHeight)
        .buttonStyle(LargeButtonStyle()).controlSize(.large)
        .preference(key:UnsavedEdits.self,value:!name.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && (editingID == nil || store.archive.pairs.first { $0.id == editingID }?.name != name))
    }
}

struct BluetoothEntry: Identifiable {
    let id: String
    let name: String
    let connected: Bool
}
@MainActor
final class BluetoothList: NSObject, ObservableObject {
    #if os(macOS)
    private var central: CBCentralManager?
    #endif
    @Published var entries: [BluetoothEntry] = []
    @Published var status = L("Apasă butonul pentru a citi numele disponibile.")
    var explanation: String {
        #if os(macOS)
        L("Pe Mac citim dispozitivele Bluetooth deja asociate. Lista poate include alte accesorii; confirmă modelul AirPods. Nu efectuăm scanare și nu conectăm dispozitive.")
        #else
        L("Pe iPhone putem citi doar ieșirea audio Bluetooth activă, nu lista completă a dispozitivelor asociate. Conectează și selectează AirPods în Centrul de control, apoi reîmprospătează.")
        #endif
    }
    func refresh() {
        entries = []
        #if os(macOS)
        guard CBManager.authorization != .denied && CBManager.authorization != .restricted else {
            status = L("Acces Bluetooth refuzat sau restricționat. Verifică Configurări sistem → Confidențialitate și securitate → Bluetooth. Introducerea manuală rămâne disponibilă."); return
        }
        if central == nil {
            status = L("Se verifică accesul Bluetooth. Dacă apare o cerere a sistemului, alege dacă permiți accesul.")
            central = CBCentralManager(delegate: self, queue: .main, options: [CBCentralManagerOptionShowPowerAlertKey: false])
            return
        }
        guard central?.state == .poweredOn else {
            status = central?.state == .unknown || central?.state == .resetting
                ? L("Bluetooth se inițializează. Așteaptă câteva secunde sau reîmprospătează.")
                : L("Bluetooth este oprit sau indisponibil. Activează-l în Configurări sistem și reîmprospătează; poți introduce numele manual.")
            return
        }
        guard let devices = IOBluetoothDevice.pairedDevices() as? [IOBluetoothDevice] else {
            status = L("Lista Bluetooth nu este disponibilă. Verifică permisiunea și Bluetooth în Configurări sistem sau folosește introducerea manuală."); return
        }
        entries = devices.compactMap { device in
            guard let address = device.addressString, !address.isEmpty else { return nil }
            let name = device.name?.trimmingCharacters(in: .whitespacesAndNewlines)
            return BluetoothEntry(id: "mac:" + address, name: name?.isEmpty == false ? name! : L("Dispozitiv fără nume"), connected: device.isConnected())
        }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        #else
        entries = AVAudioSession.sharedInstance().currentRoute.outputs.filter {
            [.bluetoothA2DP, .bluetoothHFP, .bluetoothLE].contains($0.portType)
        }.map { BluetoothEntry(id: "ios-route:" + $0.uid, name: $0.portName, connected: true) }
        #endif
        status = entries.isEmpty ? L("Niciun dispozitiv disponibil prin acest API. Verifică Bluetooth și conexiunea sau adaugă numele manual.") : L("Alege numele dorit. Numele nu confirmă modelul, bateria sau firmware-ul.")
    }
}

#if os(macOS)
extension BluetoothList: @preconcurrency CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        // The manager was explicitly created with the main queue. No discovery is started.
        refresh()
    }
}
#endif

extension View {
    @ViewBuilder func monitorTabVisibility() -> some View {
        #if os(iOS)
        self.toolbar(.hidden, for: .tabBar)
        #else
        self
        #endif
    }
}


struct QuickEntryGuide: View {
    @Environment(\.dismiss) private var dismiss
    private let steps: [(String, String)] = [
        ("1. Select the right pair", "Use My pairs to add a distinct name for each physical pair. Check the Axxxx model number in Apple settings; a custom name such as Мария does not identify the model."),
        ("2. Read the actual percentages", "Open the AirPods battery information in Apple settings or the Batteries widget. Record only components with a clearly visible percentage. A single 88% beside both earbuds does not prove that left, right and case each have 88%. Leave unshown components unselected."),
        ("3. Enter and save an observation", "In Overview, find Record battery now. Select the visible components, enter a value such as 88.00, then Apply exact value. Percentages use whole numbers: 88.00 is valid, 88.25 is rejected. Set the time the reading was observed, confirm that these are real readings, then save the observation."),
        ("4. Use a screenshot as a reference", "Take a screenshot of the Apple battery screen. Open it beside this app on Mac, or switch between Photos and this app on iPhone/iPad. Copy only clearly labelled values and use the capture time, not the import time. This version does not import or automatically read screenshots. Never infer a missing percentage, exact volume or firmware from an icon or slider position."),
        ("5. Measure autonomy", "In Autonomy test, enter start time and initial percentages. Keep a draft while listening. At the end, enter end time and final percentages, volume, audio mode, environment, source and observed firmware. Select only components measured at both times, then save the test. Keep the same conditions for comparisons."),
        ("6. Keep your data", "Saved observations, tests and drafts remain after shutdown. Unsaved fields may be lost. Export the JSON journal for a separate backup. Review screenshots and exports before sharing because they can contain device names, serial numbers or location references.")
    ]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(L("Add battery data · manual or from a screenshot")).font(.title2.bold()).accessibilityAddTraits(.isHeader)
                ForEach(steps.indices, id: \.self) { index in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(L(steps[index].0)).font(.headline).accessibilityAddTraits(.isHeader)
                        Text(L(steps[index].1)).fixedSize(horizontal: false, vertical: true).textSelection(.enabled)
                    }
                }
                Text(L("Example only: 100% to 80% in 2 hours means 10 percentage points per hour. This is not a measurement of your AirPods.")).font(.callout)
            }.padding(24)
        }
        .frame(minWidth: platformSheetWidth(320), idealWidth: 600, minHeight: platformSheetMinimumHeight)
        .buttonStyle(LargeButtonStyle()).controlSize(.large)
    }
}


func platformSheetWidth(_ width: CGFloat) -> CGFloat {
    #if os(macOS)
    return width
    #else
    return 0
    #endif
}
private var platformSheetMinimumHeight: CGFloat {
    #if os(macOS)
    500
    #else
    0
    #endif
}

struct MarkLabIncident: AppIntent {
    static let title: LocalizedStringResource = "Deschide jurnalul de incidente"
    static let description = IntentDescription("Deschide aplicația pentru confirmarea incidentului, fără a genera sunete.")
    static let openAppWhenRun = true
    @MainActor func perform() async throws -> some IntentResult {
        UserDefaults.standard.set(true, forKey: "pendingLabIncident")
        return .result()
    }
}
struct LabShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: MarkLabIncident(), phrases: ["Incident în \(.applicationName)"], shortTitle: "Incident", systemImageName: "waveform")
    }
}
struct LabRoot: View {
    let pair: AirPodsPair
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: Store
    @State private var container: ModelContainer?
    @State private var failure = ""
    var body: some View {
        VStack {
            HStack { Text("AirPods Autonomy Lab").font(.title); Spacer() }.padding()
            if let container { LabPage(pair: pair).modelContainer(container) }
            else { Text(failure.isEmpty ? "Deschidere…" : failure).padding() }
        }.frame(minWidth: platformSheetWidth(340), minHeight: platformSheetMinimumHeight)
        .task {
            if let shared = store.sync?.container { container = shared }
            else { failure = store.error ?? "Stocarea nu este disponibilă / Stockage indisponible" }
        }
    }
}
struct LabPage: View {
    let pair: AirPodsPair
    @EnvironmentObject var store: Store
    @Environment(\.modelContext) private var context
    @Query(sort: \LabRecord.timestamp, order: .reverse) private var rawRecords: [LabRecord]
    private var records: [LabRecord] {
        var seen = Set<Data>(); let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        return rawRecords.filter { record in
            let value = CompleteBackup.Record(id:record.id,pairID:record.pairID,timestamp:record.timestamp,kind:record.kind,evidence:record.evidence,source:record.source,text:record.text)
            guard let key = try? encoder.encode(value) else { return true }; return seen.insert(key).inserted
        }
    }
    @State private var kind = "Incident sonor"
    @State private var note = ""
    @State private var message = ""
    @State private var importing = false
    @State private var ocr = false
    @State private var csvImport = false
    @State private var export = false
    @State private var exportData = Data()
    @State private var backupPassword = ""
    @State private var pending: Archive?
    @State private var recognized = ""
    @State private var route = "Indisponibil"
    @State private var routeTime: Date?
    @State private var healthSummary = ""
    @State private var healthRequestID = UUID()
    @Environment(\.scenePhase) private var labScenePhase
    @State private var reading = false
    private var fr: Bool { Localization.locale().language.languageCode?.identifier == "fr" }
    private func t(_ ro: String, _ fr: String) -> String { self.fr ? fr : ro }
    private let kinds = ["Incident sonor", "Întrerupere / switch", "Încărcare 5 min", "Încărcare 10 min", "Încărcare 15 min", "Repaus 8–12 h", "O singură cască L/R", "Microfon / dictare / apel", "A/B Logic Pro / Music / Spatial", "Încărcare optimizată", "Personalized Volume / Conversation Awareness", "Pause Media When Falling Asleep", "Baterie iPhone înainte/după", "AppleCare+ / service", "Confort auditiv", "Firmware beta neconfirmat"]
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(pair.name).font(.headline)
                GroupBox(t("Probă API public · prim-plan", "Sonde API publique · premier plan")) {
                    VStack(alignment: .leading) {
                        Text(route).textSelection(.enabled)
                        if let routeTime { Text(routeTime, style: .date); Text(routeTime, style: .time) }
                        Text(t("Baterie L/R/carcasă și firmware automat: Indisponibil. Folosește jurnalul manual sau OCR confirmat. Ruta nu dovedește identitatea modelului. Nu există monitorizare garantată în fundal.", "Batterie G/D/boîtier et firmware automatiques : Indisponible. Utilisez le journal manuel ou l’OCR confirmé. La route ne prouve pas le modèle. Aucun suivi garanti en arrière-plan."))
                        Button(t("Citește ruta și volumul", "Lire la route et le volume")) { probe() }
                    }
                }
                GroupBox(t("Jurnal structurat · Introdus", "Journal structuré · Saisi")) {
                    VStack(alignment: .leading) {
                        Picker(t("Protocol / eveniment", "Protocole / événement"), selection: $kind) { ForEach(kinds, id: \.self) { Text($0).tag($0) } }
                        TextEditor(text: $note).frame(minHeight: 110).accessibilityLabel(t("Detalii și rezultate reale", "Détails et résultats réels"))
                        Text(t("Notează T43/T44/T47–49 numai dacă ai datele originale. Pentru teste: firmware și canal, conținut, temperatură, rută, volum, mod, L/R, ore și niveluri înainte/după. Fiecare interval fără încărcare este un test separat.", "N’inscrivez T43/T44/T47–49 qu’avec les données originales. Notez firmware et canal, contenu, température, route, volume, mode, G/D, heures et niveaux avant/après. Chaque intervalle sans charge est un test distinct."))
                        Button(t("Salvează observația", "Enregistrer l’observation")) { if save(kind: kind, text: note) { note = "" } }.disabled(note.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty)
                        Button(t("Marchează incident acum", "Marquer un incident maintenant")) { save(kind: "Incident sonor", text: note.isEmpty ? "Incident marcat; completează detaliile într-o observație nouă." : note) }
                    }
                }
                GroupBox(t("Import și backup", "Import et sauvegarde")) {
                    VStack(alignment: .leading) {
                        SecureField(t("Parolă backup opțională · minimum 12 caractere", "Mot de passe facultatif · 12 caractères minimum"), text:$backupPassword)
                        Button(t("Importă jurnal JSON · previzualizare", "Importer JSON · aperçu")) { importing = true }
                        if let pending {
                            Text("\(pending.sessions.count) sesiuni · \(pending.observations.count) observații · \(pending.pairs.count) perechi")
                            Button(t("Confirmă adăugarea fără duplicate", "Confirmer l’ajout sans doublons")) { merge(pending) }
                            Button(t("Anulează", "Annuler")) { self.pending = nil }
                        }
                        Button(t("Importă CSV după șablon", "Importer CSV selon le modèle")) { csvImport = true }
                        Button(t("Importă captură OCR local", "Importer une capture OCR locale")) { ocr = true }.disabled(reading)
                        if !recognized.isEmpty {
                            TextEditor(text: $recognized).frame(minHeight: 120).accessibilityLabel("OCR · verifică procentele, componentele și firmware-ul")
                            Text(t("OCR este o propunere. Corectează și confirmă. Nu se salvează automat procente ca măsurători.", "L’OCR est une proposition. Corrigez puis confirmez. Aucun pourcentage n’est enregistré automatiquement comme mesure."))
                            Button(t("Confirmă textul OCR în jurnal", "Confirmer le texte OCR")) { if save(kind: "OCR confirmat", text: recognized, source: "Vision OCR + confirmare umană") { recognized = "" } }
                        }
                        Button(t("Exportă backup complet JSON", "Exporter la sauvegarde JSON complète")) { backup() }
                        Button(t("Exportă sesiuni CSV", "Exporter les sessions CSV")) { exportData = Data(LabTransfer.csv(store.archive).utf8); export = true }
                        Text(t("Importul CSV folosește șablonul documentat; coloanele arbitrare sunt respinse. Backupul complet include jurnalul vechi și observațiile Lab. Cu parolă: backup JSON criptat AES-GCM. Fără parolă: JSON lizibil. CSV rămâne lizibil. Parola nu este salvată.", "L’import CSV utilise le modèle documenté ; les colonnes arbitraires sont refusées. La sauvegarde complète inclut l’ancien journal et les observations Lab. Avec mot de passe : JSON chiffré AES-GCM. Sans mot de passe : JSON lisible. CSV reste lisible. Le mot de passe n’est pas enregistré."))
                    }
                }
                GroupBox(t("Autonomie pentru călătorie · Estimat", "Autonomie de voyage · Estimée")) {
                    Text(prediction)
                }
                GroupBox(t("Comparație modele · condiții egale", "Comparaison des modèles · conditions égales")) { Text(modelComparison) }
                GroupBox(t("Ghiduri și limite", "Guides et limites")) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(t("25/100 nu înseamnă un nivel dB cunoscut. Hiperacuzia nu poate fi evaluată de aplicație. Nu sunt generate sunete de test; oprește ascultarea dacă produce disconfort. HealthKit pe iPhone este opțional, numai la cerere; lipsa datelor nu dovedește refuzul permisiunii.", "25/100 ne correspond pas à un niveau dB connu. L’application n’évalue pas l’hyperacousie. Aucun son de test n’est généré ; arrêtez en cas d’inconfort. HealthKit sur iPhone est facultatif, sur demande ; aucune donnée ne prouve pas un refus de permission."))
                        #if os(iOS)
                        Button(t("Citește expunerea HealthKit · 24 h", "Lire l’exposition HealthKit · 24 h")) { Task { await readHealth() } }
                        Text(t("Rezultatele Sănătate sunt afișate temporar aici, fără salvare în jurnal, backup sau iCloud.", "Les résultats Santé sont affichés temporairement ici, sans enregistrement dans le journal, les sauvegardes ou iCloud."))
                        if !healthSummary.isEmpty {
                            Text(healthSummary).textSelection(.enabled)
                            Button(t("Șterge afișarea temporară", "Effacer l’affichage temporaire")) { healthRequestID = UUID(); healthSummary = "" }
                        }
                        #endif
                        Link("Apple · firmware stabil / stable", destination: URL(string:"https://support.apple.com/106340")!)
                        Link("Apple · beta", destination: URL(string:"https://developer.apple.com/support/install-beta/")!)
                        Link("Apple · identificare / identification", destination: URL(string:"https://support.apple.com/109525")!)
                        Link("Apple · Find My / Localiser", destination: URL(string:"https://support.apple.com/109020")!)
                        Text(t("Firmware: conectează carcasa la alimentare, închide capacul și păstrează căștile lângă dispozitivul conectat la Wi-Fi cel puțin 30 minute; verifică apoi în Configurări. Nu există Force update. 9B42a/9B43a rămân raportări neconfirmate, separate de stabil. Setările ANC, Spatial, microfon, optimizare încărcare, sunete carcasă și somn se modifică în interfața Apple, dacă modelul le oferă.", "Firmware : alimentez le boîtier, fermez le couvercle et gardez les écouteurs près de l’appareil connecté au Wi-Fi pendant au moins 30 minutes ; vérifiez ensuite dans Réglages. Aucun Force update. 9B42a/9B43a restent non confirmés, séparés du stable. ANC, Spatial, micro, charge optimisée, sons et sommeil se règlent chez Apple, selon le modèle."))
                        Text(t("App Intents: în Scurtături alege «Deschide jurnalul de incidente», apoi atribuie scurtătura butonului Acțiune. AirBuddy și iCloud sunt opționale și neintegrate. Nu citim localizări Find My, istoricul altor dispozitive sau EQ-ul altor aplicații.", "App Intents : dans Raccourcis, choisissez l’ouverture du journal d’incidents puis affectez-le au bouton Action. AirBuddy et iCloud restent facultatifs et non intégrés. Aucun accès aux positions Localiser, à l’historique d’autres appareils ou à leur EQ."))
                    }
                }
                Text(t("Raport lunar / Apple Support", "Rapport mensuel / Apple Support")).font(.headline)
                Text(monthlyReport).textSelection(.enabled).accessibilityLabel(monthlyReport)
                ForEach(records.filter { $0.pairID == pair.id },id: \.persistentModelID) { record in
                    VStack(alignment: .leading) {
                        Text(record.kind).font(.headline)
                        Text("\(record.evidence) · \(record.source) · \(record.timestamp.formatted())")
                        Text(record.text).textSelection(.enabled)
                    }.padding().background(.quaternary, in: RoundedRectangle(cornerRadius: 8))
                }
                if !message.isEmpty { Text(message).textSelection(.enabled).accessibilityLabel(message) }
            }.padding().buttonStyle(LargeButtonStyle())
        }
        .onAppear {
            if UserDefaults.standard.bool(forKey:"pendingLabIncident") { kind = "Incident sonor"; note = "Incident à confirmer / de confirmat"; UserDefaults.standard.removeObject(forKey:"pendingLabIncident") }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                let rawData = try CompleteBackup.boundedData(url,limit:30_000_000)
                guard rawData.count <= 30_000_000 else { throw CocoaError(.fileReadTooLarge) }
                let data = ProtectedBackup.isProtected(rawData) ? try ProtectedBackup.open(rawData, password:backupPassword) : rawData
                if let wrapper = try? JSONDecoder().decode(LabBackup.self, from:data) {
                    guard [1,2].contains(wrapper.schemaVersion), Set(wrapper.records.map(\.id)).count == wrapper.records.count,
                          wrapper.records.allSatisfy({ entry in Evidence(rawValue:entry.evidence) != nil && entry.timestamp <= Date() && wrapper.archive.pairs.contains { $0.id == entry.pairID } }) else { throw CocoaError(.fileReadCorruptFile) }
                    pending = try LabTransfer.decodeArchive(JSONEncoder().encode(wrapper.archive)); pendingLab = wrapper.records }
                else { pending = try LabTransfer.decodeArchive(data); pendingLab = [] }
            } catch { message = error.localizedDescription }
        }
        .fileImporter(isPresented: $csvImport, allowedContentTypes: [.commaSeparatedText, .plainText]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                guard let text = String(data:try CompleteBackup.boundedData(url,limit:20_000_000),encoding:.utf8) else { throw CocoaError(.fileReadCorruptFile) }
                var archive = try LabTransfer.csvArchive(text)
                for i in archive.sessions.indices {
                    guard let pair = store.archive.pairs.first(where: { $0.id == archive.sessions[i].pairID }) else { throw CocoaError(.fileReadCorruptFile) }
                    archive.sessions[i].device = pair.device
                    guard archive.sessions[i].validation == nil else { throw CocoaError(.fileReadCorruptFile) }
                }
                archive.pairs = store.archive.pairs
                pending = archive; pendingLab = []
            } catch { message = error.localizedDescription }
        }
        .fileImporter(isPresented: $ocr, allowedContentTypes: [.png, .jpeg, .heic]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                let data = try CompleteBackup.boundedData(url,limit:20_000_000)
                guard data.count < 20_000_000 else { throw CocoaError(.fileReadTooLarge) }
                reading = true
                Task {
                    do { recognized = try await Self.recognize(data) } catch { message = error.localizedDescription }
                    reading = false
                }
            } catch { message = error.localizedDescription }
        }
        .fileExporter(isPresented: $export, document: JSONDocument(data:exportData), contentType: .data, defaultFilename: "AirPods-backup") { result in
            if case .failure(let error) = result { message = error.localizedDescription }
        }
        .onDisappear { healthRequestID = UUID(); healthSummary = "" }
        .onChange(of:labScenePhase) { _,phase in if phase != .active { healthRequestID = UUID(); healthSummary = "" } }
        .preference(key:UnsavedEdits.self,value:!note.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty || !recognized.isEmpty || pending != nil)
    }
    @State private var pendingLab: [LabBackup.Entry] = []
    @discardableResult private func save(kind: String, text: String, source: String = "Manual", evidence: Evidence = .entered) -> Bool {
        let record = LabRecord(pairID:pair.id, kind:kind, text:text, source:source, evidence:evidence)
        context.insert(record)
        do { try context.save(); message = t("Salvat local.", "Enregistré localement."); return true }
        catch { context.rollback(); message = error.localizedDescription; return false }
    }
    private func merge(_ archive: Archive) {
        guard store.error == nil else { message = store.error ?? "Eroare"; return }
        do {
            guard let sync = store.sync else { throw CocoaError(.fileReadUnknown) }
            let incoming = CompleteBackup(archive:archive,records:pendingLab.map { .init(id:$0.id,pairID:$0.pairID,timestamp:$0.timestamp,kind:$0.kind,evidence:$0.evidence,source:$0.source,text:$0.text) })
            try sync.restore(incoming,overwriteExisting:false)
            pending = nil; pendingLab = []; message = "Import confirmat / confirmé"
        } catch { message = error.localizedDescription }
    }
    private func backup() {
        do {
            let data = try JSONEncoder().encode(LabBackup(archive:store.archive, records:records.map(LabBackup.Entry.init)))
            exportData = backupPassword.isEmpty ? data : try ProtectedBackup.seal(data,password:backupPassword)
            export = true
        }
        catch { message = error.localizedDescription }
    }
    private var modelComparison: String {
        guard let ref = store.archive.sessions.filter({ $0.pairID == pair.id && $0.comparable && $0.conditions?.valid == true }).max(by:{ $0.end < $1.end }) else { return "Date insuficiente / Données insuffisantes" }
        let matched = store.archive.sessions.filter { s in
            s.comparable && s.conditions == ref.conditions && s.volume == ref.volume && s.mode == ref.mode && s.environment == ref.environment && s.source == ref.source && s.activity == ref.activity && s.eqSignature == ref.eqSignature
        }
        return [Device.four, Device.maria].map { device in
            let tests = matched.filter { $0.device == device }
            let rates = tests.compactMap { $0.samples.first(where:{ $0.component == .left })?.rate(hours:$0.hours) }
            let value = rates.isEmpty ? "Indisponibil / Indisponible" : String(format:"%.2f pp/h",rates.reduce(0,+)/Double(rates.count))
            return "\(device.displayName): \(value) · n=\(rates.count) · firmware \(Set(tests.map(\.firmware)).sorted().joined(separator:", "))"
        }.joined(separator:"\n") + "\nL / G · medie aritmetică / moyenne arithmétique. Fără diagnostic / Aucun diagnostic."
    }
    private var monthlyReport: String {
        let sessions = store.archive.sessions.filter { $0.pairID == pair.id && Calendar.current.isDate($0.start, equalTo:Date(), toGranularity:.month) }
        let events = records.filter { $0.pairID == pair.id && Calendar.current.isDate($0.timestamp, equalTo:Date(), toGranularity:.month) }
        return "\(pair.name) · \(Date().formatted(.dateTime.month(.wide).year()))\n\(sessions.count) sesiuni / sessions · \(events.count) observații / observations\nFirmware: \(Set(sessions.map(\.firmware)).sorted().joined(separator:", "))\nFără diagnostic de sănătate baterie / Aucun diagnostic de batterie."
    }
    private var prediction: String {
        guard let latest = store.archive.sessions.filter({ $0.pairID == pair.id && $0.comparable && $0.conditions?.valid == true && $0.conditions?.firmwareChannel != "unknown" }).max(by: { $0.end < $1.end }) else { return t("Sunt necesare minimum 3 teste comparabile fără încărcare.", "Au moins 3 tests comparables sans charge sont nécessaires.") }
        let rates = store.archive.sessions.filter { $0.comparable && $0.sameProtocol(as: latest) && $0.firmware == latest.firmware }.compactMap { $0.samples.first(where: { $0.component == .left })?.rate(hours:$0.hours) }
        guard let percent = latest.samples.first(where: { $0.component == .left })?.final,
              let range = DischargeSegment.autonomyRange(percent:Double(percent), matchedRates:rates) else { return t("Date insuficiente: 3 teste L, același protocol și firmware.", "Données insuffisantes : 3 tests G, même protocole et firmware.") }
        return String(format:"Estimat / Estimé: %.1f–%.1f h · %d teste/tests · ", range.lowerBound, range.upperBound, rates.count) + t("pornind de la ultima citire L, nu bateria curentă. Interval empiric min/max, fără garanție; încărcarea și pauzele invalidează proiecția.", "depuis la dernière lecture G, pas la batterie actuelle. Intervalle empirique min/max, sans garantie ; charge et pauses invalident la projection.")
    }
    #if os(iOS)
    private func readHealth() async {
        let requestID = UUID(); healthRequestID = requestID; healthSummary = ""
        guard HKHealthStore.isHealthDataAvailable(), let type = HKQuantityType.quantityType(forIdentifier:.headphoneAudioExposure) else { message = "HealthKit indisponibil / indisponible"; return }
        let health = HKHealthStore()
        do {
            try await health.requestAuthorization(toShare:[], read:[type])
            let predicate = HKQuery.predicateForSamples(withStart:Date().addingTimeInterval(-86400), end:Date(), options:.strictStartDate)
            let summary: String = try await withCheckedThrowingContinuation { continuation in
                let query = HKSampleQuery(sampleType:type, predicate:predicate, limit:100, sortDescriptors:[NSSortDescriptor(key:HKSampleSortIdentifierEndDate, ascending:false)]) { _, samples, error in
                    if let error { continuation.resume(throwing:error); return }
                    let values = (samples as? [HKQuantitySample] ?? []).map { sample in
                        "\(sample.startDate.formatted()) – \(sample.endDate.formatted()): \(sample.quantity.doubleValue(for:.decibelAWeightedSoundPressureLevel())) dBA · \(sample.sourceRevision.source.name)"
                    }
                    continuation.resume(returning:values.joined(separator:"\n"))
                }
                health.execute(query)
            }
            guard requestID == healthRequestID, labScenePhase == .active else { return }
            if summary.isEmpty { message = "Nicio mostră accesibilă; date absente sau acces limitat. / Aucun échantillon accessible." }
            else { healthSummary = summary }
        } catch { message = error.localizedDescription }
    }
    #endif
    private func probe() {
        #if os(iOS)
        let session = AVAudioSession.sharedInstance()
        route = "Măsurat · AVAudioSession · \(session.currentRoute.outputs.map(\.portName).joined(separator:", ")) · volum \(Int(session.outputVolume*100))/100"
        #else
        var address = AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyDefaultOutputDevice, mScope:kAudioObjectPropertyScopeGlobal, mElement:kAudioObjectPropertyElementMain)
        var device = AudioDeviceID(0); var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &device) == noErr else { route = "Indisponibil · CoreAudio"; return }
        address.mSelector = kAudioObjectPropertyName
        var rawName: Unmanaged<CFString>?; size = UInt32(MemoryLayout<CFString?>.size)
        let nameStatus = AudioObjectGetPropertyData(device, &address, 0, nil, &size, &rawName)
        let name = rawName?.takeRetainedValue() as String? ?? "Indisponibil"
        address = AudioObjectPropertyAddress(mSelector:kAudioHardwareServiceDeviceProperty_VirtualMainVolume, mScope:kAudioDevicePropertyScopeOutput, mElement:kAudioObjectPropertyElementMain)
        var volume = Float32(0); size = UInt32(MemoryLayout<Float32>.size)
        let status = AudioObjectGetPropertyData(device, &address, 0, nil, &size, &volume)
        route = "Măsurat · CoreAudio · \(nameStatus == noErr ? name : "Indisponibil") · volum \(status == noErr ? String(Int(volume*100)) + "/100" : "Indisponibil")"
        #endif
        routeTime = Date(); save(kind:"Probă API public", text:route, source:"API public · prim-plan", evidence:.measured)
    }
    nonisolated private static func recognize(_ data: Data) async throws -> String {
        try await Task.detached(priority:.userInitiated) {
            let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.usesLanguageCorrection = false
            try VNImageRequestHandler(data:data).perform([request])
            return request.results?.compactMap { $0.topCandidates(1).first?.string }.joined(separator:"\n") ?? ""
        }.value
    }
}
struct LabBackup: Codable {
    var schemaVersion = 2
    var archive: Archive
    var records: [Entry]
    struct Entry: Codable {
        var id: UUID; var pairID: UUID; var timestamp: Date; var kind: String; var evidence: String; var source: String; var text: String
        init(_ r: LabRecord) { id = r.id; pairID = r.pairID; timestamp = r.timestamp; kind = r.kind; evidence = r.evidence; source = r.source; text = r.text }
    }
}

@MainActor
final class JournalSync {
    let container: ModelContainer
    let vaultURL: URL
    let usesCloudSync: Bool
    let preferences: UserDefaults
    weak var store: Store?
    var timer: Timer?
    var lastPayload: Data?
    var needsMirrorRepair = false
    var preferencesObserver: NSObjectProtocol?
    static var cloudEnabled: Bool {
        #if LOCAL_MAC_DEBUG
        false
        #else
        Bundle.main.object(forInfoDictionaryKey:"CloudSyncEnabled") as? Bool == true
        #endif
    }
    static func makeContainer() throws -> ModelContainer {
        // Local builds keep the durable store while omitting unavailable cloud capabilities.
        #if LOCAL_MAC_DEBUG
        let database: ModelConfiguration.CloudKitDatabase = .none
        #else
        let database: ModelConfiguration.CloudKitDatabase = Bundle.main.object(forInfoDictionaryKey: "CloudSyncEnabled") as? Bool == true ? .private("iCloud.com.airpods.autonomylab") : .none
        #endif
        return try ModelContainer(for: Schema(versionedSchema: LabSchemaV3.self), migrationPlan: LabMigration.self,
            configurations: ModelConfiguration("AutonomyLab", cloudKitDatabase: database))
    }
    init(store: Store, container suppliedContainer: ModelContainer? = nil, startTimer: Bool = true, cloudSyncOverride: Bool? = nil, preferences: UserDefaults = .standard) throws {
        guard store.error == nil else { throw CocoaError(.fileReadCorruptFile) }
        let pendingPreferences = PreferenceCheckpoint.pending(in:preferences)
        self.preferences = preferences
        self.store = store; usesCloudSync = cloudSyncOverride ?? (suppliedContainer == nil && Self.cloudEnabled); vaultURL = store.url.deletingLastPathComponent().appending(path:"AutomaticBackups"); container = try suppliedContainer ?? Self.makeContainer()
        do { try removeExactDuplicates() } catch { store.serviceWarning = error.localizedDescription }
        let empty = try container.mainContext.fetchCount(FetchDescriptor<JournalRevision>()) == 0
        if !empty { try refresh() }
        if empty {
            lastPayload = nil
            if let settings = store.archive.settings { try PortablePreferences.apply(settings,to:preferences) }
        }
        if !pendingPreferences.isEmpty {
            let merged = (store.archive.settings ?? PortablePreferences.capture(preferences)).merging(pendingPreferences) { _,local in local }
            try PortablePreferences.apply(merged,to:preferences)
            store.archive.settings = merged
        }
        try publish(store.archive)
        try PreferenceCheckpoint.remember(in:preferences)
        do { try automaticBackup() } catch { store.serviceWarning = error.localizedDescription }
        #if !SWIFT_PACKAGE
        if usesCloudSync {
            #if os(macOS)
            NSApplication.shared.registerForRemoteNotifications()
            #else
            UIApplication.shared.registerForRemoteNotifications()
            #endif
        }
        #endif
        if startTimer {
            preferencesObserver = NotificationCenter.default.addObserver(forName:UserDefaults.didChangeNotification,object:nil,queue:.main) { [weak self] _ in
                Task { @MainActor in
                    do { try self?.capturePreferences() } catch { self?.store?.serviceWarning = error.localizedDescription }
                }
            }
        }
        if startTimer { timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
            Task { @MainActor in do { try self?.capturePreferences(); try self?.removeExactDuplicates(); try self?.refresh(); try self?.automaticBackup() } catch { self?.store?.serviceWarning = error.localizedDescription } }
        } }
    }
    func capturePreferences() throws {
        guard let store else { return }
        let settings = PortablePreferences.capture(preferences)
        try PortablePreferences.validate(settings)
        // publish also retries a previous failed durable save, even if memory already matches.
        store.archive.settings = settings
        try publish(store.archive)
        try PreferenceCheckpoint.remember(in:preferences)
    }
    func publish(_ archive: Archive) throws {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(archive)
        guard data != lastPayload else { return }
        let revision = JournalRevision(payload: data)
        if let latest = try container.mainContext.fetch(FetchDescriptor<JournalRevision>()).map(\.timestamp).max() { revision.timestamp = max(Date(), latest.addingTimeInterval(0.001)) }
        revision.basePayload = lastPayload ?? Data(); container.mainContext.insert(revision)
        do { try container.mainContext.save(); lastPayload = data } catch { container.mainContext.rollback(); throw error }
    }
    func refresh() throws {
        guard let store else { return }
        let revisions = try container.mainContext.fetch(FetchDescriptor<JournalRevision>()).map {
            CompleteBackup.Revision(id:$0.id, timestamp:$0.timestamp, payload:$0.payload, basePayload:$0.basePayload)
        }
        guard !revisions.isEmpty else { return }
        let merged = try JournalHistory.materialize(revisions)
        let e = JSONEncoder(); e.outputFormatting = [.sortedKeys]
        let mergedPayload = try e.encode(merged)
        let differsFromUI = try e.encode(store.archive) != mergedPayload
        guard mergedPayload != lastPayload || differsFromUI || needsMirrorRepair else { return }
        if let settings = merged.settings, settings != PortablePreferences.capture(preferences) { try PortablePreferences.apply(settings,to:preferences) }
        store.archive = merged
        // SwiftData is canonical. A secondary cache failure must not re-emit remote revisions.
        lastPayload = mergedPayload
        try PreferenceCheckpoint.remember(in:preferences)
        do {
            try FileManager.default.createDirectory(at: store.url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try JSONEncoder().encode(merged).write(to: store.url, options:.atomic)
            needsMirrorRepair = false
        } catch { needsMirrorRepair = true; store.serviceWarning = "Copia secundară nu a putut fi scrisă; datele SwiftData sunt păstrate. / Copie secondaire non écrite ; données SwiftData conservées. " + error.localizedDescription }
    }
    func backup() throws -> CompleteBackup {
        guard let store else { throw CocoaError(.fileReadUnknown) }
        let records = try container.mainContext.fetch(FetchDescriptor<LabRecord>()).map { r in
            CompleteBackup.Record(id:r.id, pairID:r.pairID, timestamp:r.timestamp, kind:r.kind, evidence:r.evidence, source:r.source, text:r.text)
        }
        let revisions = try container.mainContext.fetch(FetchDescriptor<JournalRevision>()).map { CompleteBackup.Revision(id:$0.id, timestamp:$0.timestamp, payload:$0.payload, basePayload:$0.basePayload) }
        let attachments = container.schema.entities.contains(where: { $0.name == "LabAttachment" }) ? try container.mainContext.fetch(FetchDescriptor<LabAttachment>()).map { a in
            CompleteBackup.Attachment(id:a.id,pairID:a.pairID,sessionID:a.sessionID,timestamp:a.timestamp,filename:a.filename,contentType:a.contentType,bytes:a.bytes)
        } : []
        return CompleteBackup(archive:try ExactDuplicates.archive(store.archive), records:try ExactDuplicates.rows(records).values, revisions:try ExactDuplicates.rows(revisions).values, preferences:PortablePreferences.capture(preferences), attachments:attachments.isEmpty ? nil : try ExactDuplicates.rows(attachments).values)
    }
    func removeExactDuplicates() throws {
        guard let store, !container.mainContext.hasChanges else { return }
        let context = container.mainContext
        let records = try context.fetch(FetchDescriptor<LabRecord>())
        let revisions = try context.fetch(FetchDescriptor<JournalRevision>())
        let recordValues = records.map { CompleteBackup.Record(id:$0.id,pairID:$0.pairID,timestamp:$0.timestamp,kind:$0.kind,evidence:$0.evidence,source:$0.source,text:$0.text) }
        let revisionValues = revisions.map { CompleteBackup.Revision(id:$0.id,timestamp:$0.timestamp,payload:$0.payload,basePayload:$0.basePayload) }
        let r = try ExactDuplicates.rows(recordValues); let h = try ExactDuplicates.rows(revisionValues)
        let count = r.duplicateIndices.count + h.duplicateIndices.count
        let conflicts = r.conflictingIDs + h.conflictingIDs
        if conflicts > 0 { store.cleanupMessage = "\(conflicts) ID-uri cu variante diferite păstrate / identifiants avec variantes différentes conservées"; return }
        guard count > 0 else { return }
        if usesCloudSync {
            // Different peers may have different local object IDs. Deleting their
            // chosen survivors can delete every copy; only project logical duplicates.
            store.cleanupMessage = "\(count) duplicate identice filtrate la afișare/export; înregistrările CloudKit sunt păstrate. / doublons identiques filtrés à l’affichage/export ; enregistrements CloudKit conservés."
            return
        }
        _ = try BackupVault.write(backup(),to:store.url.deletingLastPathComponent().appending(path:"CleanupRecovery"))
        do {
            for i in r.duplicateIndices { context.delete(records[i]) }
            for i in h.duplicateIndices { context.delete(revisions[i]) }
            try context.save()
            store.cleanupMessage = "\(count) duplicate identice curățate automat; copie de recuperare salvată. / doublons identiques nettoyés automatiquement ; copie de récupération enregistrée."
        } catch { context.rollback(); throw error }
    }
    func automaticBackup(force: Bool = false) throws {
        guard let store else { throw CocoaError(.fileReadUnknown) }
        let existing = try BackupVault.entries(in:vaultURL)
        if !force, let latest = existing.first, store.lastBackup != latest.date {
            do { _ = try BackupVault.verified(latest.url); store.lastBackup = latest.date }
            catch { store.lastBackup = nil; throw error }
        }
        guard force || (existing.first.map({ Date().timeIntervalSince($0.date) >= 86_400 }) ?? true) else { return }
        _ = try BackupVault.write(backup(),to:vaultURL)
        store.lastBackup = try BackupVault.entries(in:vaultURL).first?.date
        try ExtraBackupDestination.write(backup())
    }
    func restore(_ backup: CompleteBackup, overwriteExisting: Bool = true, replaceAll: Bool = false) throws {
        guard let store else { throw CocoaError(.fileReadUnknown) }
        _ = try CompleteBackup.decode(backup.encoded())
        try PortablePreferences.validate(backup.preferences)
        _ = try BackupMerge.archive(local:store.archive,incoming:backup.archive,overwriteExisting:false)
        var merged = replaceAll ? backup.archive : try BackupMerge.archive(local:store.archive,incoming:backup.archive,overwriteExisting:overwriteExisting)
        if !backup.preferences.isEmpty { merged.settings = overwriteExisting ? PortablePreferences.capture(preferences).merging(backup.preferences) { _,new in new } : PortablePreferences.capture(preferences).merging(backup.preferences) { old,_ in old } }
        // Recovery includes both the old state and the exact incoming alternative.
        let folder = store.url.deletingLastPathComponent().appending(path:"Recovery")
        _ = try BackupVault.write(self.backup(),to:folder)
        _ = try BackupVault.write(backup,to:folder)
        let context = container.mainContext
        do {
            let existing = try context.fetch(FetchDescriptor<LabRecord>())
            if replaceAll { for old in existing { context.delete(old) } }
            for r in backup.records {
                if !replaceAll, let old = existing.first(where: { $0.id == r.id }) {
                    if overwriteExisting { for variant in existing where variant.id == old.id { variant.pairID=r.pairID; variant.timestamp=r.timestamp; variant.kind=r.kind; variant.evidence=r.evidence; variant.source=r.source; variant.text=r.text } }
                    continue
                }
                let item = LabRecord(pairID:r.pairID, kind:r.kind, text:r.text, source:r.source, evidence:Evidence(rawValue:r.evidence) ?? .entered)
                item.id = r.id; item.timestamp = r.timestamp; context.insert(item)
            }
            if container.schema.entities.contains(where: { $0.name == "LabAttachment" }) {
                let oldAttachments = try context.fetch(FetchDescriptor<LabAttachment>())
                if replaceAll { for old in oldAttachments { context.delete(old) } }
                for a in backup.attachments ?? [] {
                    if !replaceAll, let old = oldAttachments.first(where: { $0.id == a.id }) {
                        if overwriteExisting { old.pairID=a.pairID; old.sessionID=a.sessionID; old.timestamp=a.timestamp; old.filename=a.filename; old.contentType=a.contentType; old.bytes=a.bytes }
                    } else {
                        let item = LabAttachment(pairID:a.pairID,filename:a.filename,contentType:a.contentType,bytes:a.bytes,sessionID:a.sessionID)
                        item.id=a.id; item.timestamp=a.timestamp; context.insert(item)
                    }
                }
            } else if !(backup.attachments ?? []).isEmpty { throw CocoaError(.featureUnsupported) }
            let current = try context.fetch(FetchDescriptor<JournalRevision>())
            for r in backup.revisions {
                if let old = current.first(where: { $0.id == r.id }) {
                    guard old.payload == r.payload, old.basePayload == r.basePayload, old.timestamp == r.timestamp else { throw CocoaError(.fileReadCorruptFile) }
                } else {
                    let item = JournalRevision(payload:r.payload); item.id = r.id; item.timestamp = r.timestamp; item.basePayload = r.basePayload; context.insert(item)
                }
            }
            let rows = try context.fetch(FetchDescriptor<JournalRevision>())
            let base = try JournalHistory.materialize(rows.map { .init(id:$0.id,timestamp:$0.timestamp,payload:$0.payload,basePayload:$0.basePayload) })
            let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
            let revision = JournalRevision(payload:try encoder.encode(merged))
            revision.basePayload = try encoder.encode(base)
            if let latest = rows.map(\.timestamp).max() { revision.timestamp = max(Date(),latest.addingTimeInterval(0.001)) }
            context.insert(revision)
            try context.save()
        } catch { context.rollback(); throw error }
        // Update the visible state even if the committed payload is already cached.
        store.archive = merged
        lastPayload = nil
        do { try refresh() } catch { store.serviceWarning = "Datele sunt salvate în SwiftData; copia secundară necesită verificare. / Données enregistrées dans SwiftData ; copie secondaire à vérifier. " + error.localizedDescription }
        if let settings = merged.settings { try PortablePreferences.apply(settings,to:preferences) }
    }

}
struct TransferPanel: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @State var importing = false
    @State var exporting = false
    @State var csv = false
    @State var data = Data()
    @State var pending: CompleteBackup?
    @State var snapshots: [BackupVault.Entry] = []
    @State var exportingCSV = false
    @State var exportFilename = "AirPods-backup.json"
    @State var transferBusy = false
    @State var format = "json"
    @State var exportType: UTType = .json
    @State var shareURL: URL?
    @State var attachmentShareURL: URL?
    @State var differences: [ImportDifference] = []
    @State var choices: [String:Bool] = [:]
    @State var fieldChoices: [String:Bool] = [:]
    @State var preferIncoming = false
    @State var replaceAll = false
    @State var restorePreferences = true
    @State var confirmingRestore = false
    @State var choosingBackupFolder = false
    @State var hasExtraBackup = ExtraBackupDestination.hasSelection()
    @State var addingAttachment = false
    @State var attachmentPairID = AirPodsPair.initial[0].id
    @State var attachmentSessionID: UUID?
    @State var attachments: [CompleteBackup.Attachment] = []
    @State var history: [CompleteBackup.Revision] = []
    @State var message = ""
    var french: Bool { Localization.locale().language.languageCode?.identifier == "fr" }
    func t(_ ro: String, _ fr: String) -> String { french ? fr : ro }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading, spacing:18) {
                Text(t("Backup și sincronizare", "Sauvegarde et synchronisation")).font(.title).accessibilityAddTraits(.isHeader)
                Text(t("Salvare locală automată. CloudKit sincronizează automat în versiunea semnată configurată. Ultima sincronizare completă nu poate fi verificată aici.", "Enregistrement local automatique. CloudKit synchronise automatiquement dans la version signée configurée. La dernière synchronisation complète ne peut pas être vérifiée ici."))
                Picker(t("Format de export", "Format d’export"),selection:$format) {
                    Text("JSON · backup").tag("json")
                    Text("CSV · backup").tag("csv")
                    Text("CSV · tabele ZIP / tableaux ZIP").tag("zip")
                    Text("Excel XLSX · tabele / tableaux").tag("xlsx")
                }
                Button(t("Exportă toate datele", "Exporter toutes les données")) { createExport() }.disabled(transferBusy)
                if transferBusy { ProgressView(t("Pregătirea fișierului…", "Préparation du fichier…")) }
                if let shareURL { ShareLink(item:shareURL) { Label(t("Partajează ultimul export", "Partager le dernier export"),systemImage:"square.and.arrow.up") } }
                Button(t("Importă și previzualizează", "Importer et prévisualiser")) { importing = true }
                if let b = pending { importPreview(b) }
                DisclosureGroup(t("Istoric și variante de recuperare", "Historique et versions de récupération")) {
                    Text(t("Ultimele 30 de revizii, inclusiv variante primite prin sincronizare. Deschiderea unei versiuni pregătește o previzualizare, fără a modifica datele. Acesta nu este un indicator că toate conflictele au fost detectate.", "Les 30 dernières révisions, dont les versions reçues par synchronisation. Ouvrir une version prépare un aperçu sans modifier les données. Cela ne signifie pas que tous les conflits ont été détectés."))
                    ForEach(history) { revision in
                        Button(revision.timestamp.ISO8601Format()+" · "+String(revision.id.uuidString.suffix(8))) { previewRevision(revision) }
                    }
                }
                attachmentsPanel
                GroupBox(t("Backup automat separat", "Sauvegarde automatique séparée")) {
                    VStack(alignment:.leading,spacing:12) {
                        Text(t("Alege un folder local sau iCloud Drive. Copiile suplimentare se scriu la backupul automat, cât aplicația rulează. Scrierea locală nu confirmă încărcarea în iCloud Drive.", "Choisissez un dossier local ou iCloud Drive. Les copies supplémentaires sont écrites pendant la sauvegarde automatique lorsque l’app fonctionne. Une écriture locale ne confirme pas l’envoi vers iCloud Drive."))
                        Button(t("Alege folderul și salvează prima copie", "Choisir le dossier et enregistrer la première copie")) { choosingBackupFolder = true }
                        if hasExtraBackup { Button(t("Oprește copiile suplimentare · păstrează fișierele", "Arrêter les copies supplémentaires · conserver les fichiers")) { ExtraBackupDestination.clear(); hasExtraBackup = false } }
                    }
                }
                safetyCenter
                Text(message).textSelection(.enabled)
                Text(t("Alege Pe dispozitiv sau iCloud Drive în Fișiere. XLSX/ZIP exportate aici conțin backup.json pentru restaurare fidelă. Importul folosește acel backup, nu modificările făcute în celulele Excel. Pentru fișiere recomprimate sau externe folosește intermediarul backup.json.", "Choisissez Sur mon appareil ou iCloud Drive dans Fichiers. Les XLSX/ZIP exportés ici contiennent backup.json pour une restauration fidèle. L’import utilise cette sauvegarde, pas les modifications des cellules Excel. Pour les fichiers recompressés ou externes, utilisez l’intermédiaire backup.json."))
            }.padding().frame(maxWidth:650)
        }
        .fileExporter(isPresented:$exporting, document:JSONDocument(data:data), contentType:exportType, defaultFilename:exportFilename) { if case .failure(let e) = $0 { message = e.localizedDescription } }
        .confirmationDialog(t("Confirmi restaurarea? Copiile de recuperare vor fi păstrate.", "Confirmer la restauration ? Les copies de récupération seront conservées."),isPresented:$confirmingRestore,titleVisibility:.visible) {
            Button(replaceAll ? t("Înlocuiește toate datele", "Remplacer toutes les données") : t("Aplică alegerile de import", "Appliquer les choix d’import"),role:replaceAll ? .destructive : nil) { commitImport() }
        }
        .fileImporter(isPresented:$choosingBackupFolder,allowedContentTypes:[.folder]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                try ExtraBackupDestination.select(url); hasExtraBackup = true
                guard let sync = store.sync else { throw CocoaError(.fileWriteUnknown) }
                try sync.automaticBackup(force:true)
                message = t("Copie scrisă în folder. Încărcarea în iCloud Drive este gestionată de sistem.", "Copie écrite dans le dossier. L’envoi vers iCloud Drive est géré par le système.")
            } catch { message = error.localizedDescription }
        }
        .fileImporter(isPresented:$addingAttachment, allowedContentTypes:[.image,.pdf,.plainText,.data]) { result in
            do { let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; try addAttachment(url) } catch { message = error.localizedDescription }
        }
        .preference(key:UnsavedEdits.self,value:pending != nil || transferBusy)
        .task { loadSnapshots(); loadAttachments(); if !store.archive.pairs.contains(where: { $0.id == attachmentPairID }), let first = store.archive.pairs.first { attachmentPairID = first.id } }
        .onChange(of:store.lastBackup) { _,_ in loadSnapshots() }
        .fileImporter(isPresented:$importing, allowedContentTypes:[.json,.commaSeparatedText,.zip,UTType(filenameExtension:"xlsx") ?? .data]) { result in
            do { let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; try prepareImport(CompleteBackup.readFile(url)) } catch { message = error.localizedDescription }
        }
    }

    private var quality: JournalQuality { JournalQuality(archive:store.archive) }
    private func createExport() {
        guard !transferBusy else { return }
        do {
            guard let sync = store.sync else { throw CocoaError(.fileReadUnknown) }
            let backup = try sync.backup(); let selectedFormat = format
            transferBusy = true
            Task { @MainActor in
                defer { transferBusy = false }
                do {
                    let result = try await Task.detached(priority:.userInitiated) { () -> (Data,URL) in
                        let bytes: Data
                        switch selectedFormat {
                        case "csv": bytes = try backup.csv()
                        case "zip": bytes = try backup.csvTablesArchive()
                        case "xlsx": bytes = try backup.xlsx()
                        default: bytes = try backup.encoded()
                        }
                        let folder = FileManager.default.temporaryDirectory.appending(path:"AirPods-share-"+UUID().uuidString)
                        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
                        let url = folder.appending(path:"AirPods-backup."+selectedFormat)
                        try bytes.write(to:url,options:.atomic)
                        return (bytes,url)
                    }.value
                    data = result.0; shareURL = result.1
                    exportFilename = "AirPods-backup."+selectedFormat
                    switch selectedFormat {
                    case "csv": exportType = .commaSeparatedText
                    case "zip": exportType = .zip
                    case "xlsx": exportType = UTType(filenameExtension:"xlsx") ?? .data
                    default: exportType = .json
                    }
                    exporting = true
                } catch { message = error.localizedDescription }
            }
        } catch { message = error.localizedDescription }
    }
    private func prepareImport(_ backup: CompleteBackup) throws {
        guard let sync = store.sync else { throw CocoaError(.fileReadUnknown) }
        differences = try backup.differences(from:sync.backup())
        choices = [:]; fieldChoices = [:]; replaceAll = false; preferIncoming = false; pending = backup
    }
    @ViewBuilder private func importPreview(_ b: CompleteBackup) -> some View {
        Text("\(b.archive.pairs.count) dispozitive / appareils · \(b.archive.sessions.count) sesiuni / sessions · \(b.records.count) Lab · \(b.attachments?.count ?? 0) fișiere / fichiers")
        Toggle(t("Înlocuire totală, inclusiv datele absente din import", "Remplacement total, y compris les données absentes de l’import"),isOn:$replaceAll)
        Toggle(t("Restabilește preferințele și biblioteca EQ", "Restaurer les préférences et la bibliothèque EQ"),isOn:$restorePreferences)
        if !replaceAll {
            Toggle(t("Implicit: preferă varianta importată în conflicte", "Par défaut : préférer la version importée en cas de conflit"),isOn:$preferIncoming)
            Text(t("Pentru fiecare diferență poți alege separat varianta importată. Valorile noi se adaugă. Copia locală și fișierul primit sunt păstrate în Recovery înainte de aplicare.", "Pour chaque différence, choisissez séparément la version importée. Les nouvelles valeurs sont ajoutées. La copie locale et le fichier reçu sont conservés dans Recovery avant application."))
            ForEach(differences) { difference in
                DisclosureGroup(difference.category + " · " + String(difference.id.suffix(8))) {
                    if difference.local != "—" {
                        Toggle(t("Folosește varianta importată", "Utiliser la version importée"),isOn:Binding(get:{ choices[difference.id] ?? preferIncoming },set:{ choices[difference.id] = $0 }))
                    }
                    if !difference.fields.isEmpty {
                        DisclosureGroup(t("Alege separat câmpurile", "Choisir séparément les champs")) {
                            ForEach(difference.fields) { field in
                                Toggle(field.id,isOn:Binding(get:{ fieldChoices[difference.id+"/"+field.id] ?? choices[difference.id] ?? preferIncoming },set:{ fieldChoices[difference.id+"/"+field.id] = $0 }))
                                Text(t("Local: ", "Local : ")+field.local).textSelection(.enabled)
                                Text(t("Importat: ", "Importé : ")+field.incoming).textSelection(.enabled)
                            }
                        }
                    }
                    Text(t("Local", "Local")).font(.headline)
                    Text(difference.local).font(.caption).textSelection(.enabled)
                    Text(t("Importat", "Importé")).font(.headline)
                    Text(difference.incoming).font(.caption).textSelection(.enabled)
                }
            }
        }
        Text(t("Înlocuirea totală elimină din starea activă datele care lipsesc din backup. Anulează dacă referințele sau modelele nu corespund.", "Le remplacement total retire de l’état actif les données absentes de la sauvegarde. Annulez si les références ou modèles ne correspondent pas."))
        Button(t("Revizuiește și confirmă restaurarea", "Vérifier et confirmer la restauration")) { confirmingRestore = true }
        Button(t("Anulează importul", "Annuler l’import")) { pending = nil; differences = [] }
    }
    private func commitImport() {
        do {
            guard let pending, let sync = store.sync else { throw CocoaError(.fileReadUnknown) }
            let resolved = try pending.resolved(against:sync.backup(),preferIncoming:preferIncoming,choices:choices,fieldChoices:fieldChoices,replaceAll:replaceAll,restorePreferences:restorePreferences)
            try sync.restore(resolved,replaceAll:replaceAll)
            self.pending = nil; differences = []; loadAttachments(); loadSnapshots()
            message = t("Restaurare salvată local; copiile de recuperare sunt păstrate.", "Restauration enregistrée localement ; copies de récupération conservées.")
        } catch { message = error.localizedDescription }
    }
    private func loadAttachments() {
        do {
            let backup = try store.sync?.backup()
            attachments = backup?.attachments ?? []
            history = Array((backup?.revisions ?? []).sorted { $0.timestamp > $1.timestamp }.prefix(30))
        } catch { message = error.localizedDescription }
    }
    private func previewRevision(_ revision:CompleteBackup.Revision) {
        do {
            guard let sync = store.sync else { throw CocoaError(.fileReadUnknown) }
            let archive = try JSONDecoder().decode(Archive.self,from:revision.payload)
            let current = try sync.backup()
            let ids = Set(archive.pairs.map(\.id)); let sessions = Set(archive.sessions.map(\.id))
            let backup = CompleteBackup(archive:archive,records:current.records.filter { ids.contains($0.pairID) },revisions:current.revisions,preferences:archive.settings ?? current.preferences,attachments:current.attachments?.filter { ids.contains($0.pairID) && ($0.sessionID == nil || sessions.contains($0.sessionID!)) })
            try prepareImport(CompleteBackup.decode(backup.encoded()))
        } catch { message = error.localizedDescription }
    }
    @ViewBuilder private var attachmentsPanel: some View {
        GroupBox(t("Atașamente", "Pièces jointes")) {
            VStack(alignment:.leading,spacing:12) {
                Picker(t("Dispozitivul atașamentului", "Appareil de la pièce jointe"),selection:$attachmentPairID) {
                    ForEach(store.archive.pairs) { Text($0.name).tag($0.id) }
                }.onChange(of:attachmentPairID) { _,_ in attachmentSessionID = nil }
                Picker(t("Sesiune asociată", "Session associée"),selection:$attachmentSessionID) {
                    Text(t("Fără sesiune", "Sans session")).tag(nil as UUID?)
                    ForEach(store.archive.sessions.filter { $0.pairID == attachmentPairID }) { Text($0.start.ISO8601Format()).tag(Optional($0.id)) }
                }
                Text(t("Imagini, PDF sau fișiere: maximum 10 MB fiecare și 50 MB în total. Fișierele sunt păstrate ca date, fără executare. ZIP include backupul și copii separate ale atașamentelor.", "Images, PDF ou fichiers : 10 Mo par fichier, 50 Mo au total. Les fichiers sont conservés comme données, sans exécution. Le ZIP inclut la sauvegarde et les pièces jointes séparées."))
                Button(t("Adaugă un atașament", "Ajouter une pièce jointe")) { addingAttachment = true }
                if let attachmentShareURL { ShareLink(item:attachmentShareURL) { Label(t("Partajează fișierul pregătit", "Partager le fichier préparé"),systemImage:"square.and.arrow.up") } }
                ForEach(attachments) { attachment in
                    Text("\(attachment.filename) · \(attachment.bytes.count) bytes · \(attachment.timestamp.ISO8601Format())").textSelection(.enabled)
                    Button(t("Pregătește fișierul pentru partajare: ", "Préparer le fichier à partager : ")+attachment.filename) {
                        do {
                            let directory = FileManager.default.temporaryDirectory.appending(path:"Attachment-"+UUID().uuidString)
                            try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
                            let url = directory.appending(path:attachment.filename)
                            try attachment.bytes.write(to:url,options:.atomic); attachmentShareURL = url
                        } catch { message = error.localizedDescription }
                    }
                }
            }
        }
    }
    private func addAttachment(_ url:URL) throws {
        guard let sync = store.sync, store.error == nil else { throw CocoaError(.fileWriteUnknown) }
        let bytes = try CompleteBackup.boundedData(url,limit:10_000_000)
        let backup = try sync.backup()
        if (backup.attachments ?? []).contains(where: { $0.pairID == attachmentPairID && $0.sessionID == attachmentSessionID && $0.filename == url.lastPathComponent && $0.bytes == bytes }) {
            message = t("Atașamentul identic există deja.", "La pièce jointe identique existe déjà."); return
        }
        var candidate = backup
        let type = (try? url.resourceValues(forKeys:[.contentTypeKey]).contentType?.identifier) ?? "public.data"
        let attachment = CompleteBackup.Attachment(pairID:attachmentPairID,sessionID:attachmentSessionID,filename:url.lastPathComponent,contentType:type,bytes:bytes)
        candidate.attachments = (candidate.attachments ?? []) + [attachment]
        _ = try CompleteBackup.decode(candidate.encoded())
        try sync.restore(candidate)
        loadAttachments(); try sync.automaticBackup(force:true)
        message = t("Atașament salvat local.", "Pièce jointe enregistrée localement.")
    }

    private func loadSnapshots() {
        do { if let sync = store.sync { snapshots = try BackupVault.entries(in:sync.vaultURL) } }
        catch { message = error.localizedDescription }
    }
    private func dateText(_ date: Date) -> String {
        let formatter = DateFormatter(); formatter.locale = Localization.locale()
        formatter.timeZone = TimeZone(identifier:"Europe/Zurich"); formatter.dateStyle = .medium; formatter.timeStyle = .short
        return formatter.string(from:date) + " · Europe/Zurich"
    }
    private var diagnosticText: String {
        let values: [String:Any] = ["reportVersion":1,"appVersion":Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? "development",
            "generatedAtUTC":Date().ISO8601Format(),"syncStatus":"not_verified", "devices":store.archive.pairs.count,
            "sessions":store.archive.sessions.count,"observations":store.archive.observations.count,
            "staleLatestReadings":quality.staleReadings,"invalidReadings":quality.invalidReadings,
            "sessionsWithoutSource":quality.incompleteSources,"nonComparableSessions":quality.nonComparableSessions,
            "estimatedReadings":quality.estimatedReadings,"hasDraft":quality.hasDraft]
        guard let bytes = try? JSONSerialization.data(withJSONObject:values,options:[.prettyPrinted,.sortedKeys]) else { return "Diagnostic unavailable" }
        return String(decoding:bytes,as:UTF8.self)
    }
    private var safetyCenter: some View {
        VStack(alignment:.leading,spacing:12) {
            Divider()
            Text(t("Siguranța datelor și calitatea testelor", "Sécurité des données et qualité des tests")).font(.headline).accessibilityAddTraits(.isHeader)
            Text(t("Copie locală automată la pornire dacă lipsește și apoi după 24 h, cât aplicația este activă. Copiile nu sunt șterse automat. Acestea nu dovedesc sincronizarea iCloud.", "Copie locale automatique au démarrage si absente, puis après 24 h tant que l’app est active. Aucune suppression automatique. Ces copies ne prouvent pas la synchronisation iCloud."))
            if let date = store.lastBackup { Text(t("Ultima copie locală: ", "Dernière copie locale : ") + dateText(date)) }
            else { Text(t("Nicio copie locală verificată în această sesiune.", "Aucune copie locale vérifiée pendant cette session.")) }
            if !store.cleanupMessage.isEmpty { Text(store.cleanupMessage).accessibilityIdentifier("cleanup.status") }
            Text(t("Curățarea automată elimină numai copii identice cu același UUID. Variantele diferite și evenimentele cu UUID diferite sunt păstrate.", "Le nettoyage automatique élimine uniquement les copies identiques avec le même UUID. Les variantes différentes et événements avec des UUID différents sont conservés."))
            if !store.serviceWarning.isEmpty { Text(store.serviceWarning).foregroundStyle(.orange).textSelection(.enabled) }
            Button(t("Creează acum o copie locală verificată", "Créer une copie locale vérifiée maintenant")) {
                do { guard let sync = store.sync else { throw CocoaError(.fileReadUnknown) }; try sync.automaticBackup(force:true); store.serviceWarning = ""; loadSnapshots(); message = t("Copie salvată și verificată.", "Copie enregistrée et vérifiée.") }
                catch { message = error.localizedDescription }
            }
            Text(t("Copii disponibile: ", "Copies disponibles : ") + String(snapshots.count))
            ForEach(Array(snapshots.prefix(5))) { entry in
                Button(t("Previzualizează copia: ", "Prévisualiser la copie : ") + dateText(entry.date)) {
                    do { try prepareImport(BackupVault.verified(entry.url)); message = t("Integritate verificată. Confirmă fuzionarea de mai sus pentru restaurare.", "Intégrité vérifiée. Confirmez la fusion ci-dessus pour restaurer.") }
                    catch { message = t("Copia nu a trecut verificarea: ", "La copie a échoué à la vérification : ") + error.localizedDescription }
                }
            }
            Text(t("Citiri recente devenite vechi: ", "Dernières mesures devenues anciennes : ") + String(quality.staleReadings))
            Text(t("Citiri invalide sau în viitor: ", "Mesures invalides ou futures : ") + String(quality.invalidReadings))
            Text(t("Sesiuni necomparabile: ", "Sessions non comparables : ") + String(quality.nonComparableSessions))
            Text(t("Sesiuni fără sursă: ", "Sessions sans source : ") + String(quality.incompleteSources))
            Text(t("Citiri estimate: ", "Mesures estimées : ") + String(quality.estimatedReadings))
            if quality.hasDraft { Text(t("Există o ciornă de test salvată, care poate fi reluată.", "Un brouillon de test enregistré peut être repris.")) }
            Text(t("Citirile mai vechi de 15 minute nu reprezintă bateria curentă. Un test cu încărcare, întreruperi sau protocol diferit nu trebuie comparat direct. Nu este diagnostic de sănătate a bateriei.", "Les mesures de plus de 15 minutes ne représentent pas la batterie actuelle. Les tests avec charge, interruptions ou protocoles différents ne sont pas directement comparables. Aucun diagnostic de santé de la batterie."))
            Button(t("Exportă raport tehnic fără nume și serii", "Exporter un rapport technique sans noms ni numéros de série")) { data = Data(diagnosticText.utf8); exportingCSV = false; exportFilename = "AirPods-diagnostic.json"; exporting = true }
            ShareLink(item:diagnosticText) { Text(t("Partajează raportul tehnic", "Partager le rapport technique")) }
        }
    }
}

func N(_ ro: String, _ fr: String) -> String { Localization.language() == "fr" ? fr : ro }
@MainActor final class MonitorNavigation: ObservableObject {
    @Published var history = NavigationHistory()
    @Published var homeToken = UUID()
    var selection: Binding<Int> { Binding(get:{ self.history.current },set:{ self.history.select($0) }) }
    func select(_ page: Int) { history.select(page) }
    func back() { history.back() }
    func home() { history.home(); homeToken = UUID() }
}
struct AppNavBar: View {
    var canGoBack = true
    var back: () -> Void
    var home: () -> Void
    var body: some View {
        ViewThatFits(in:.horizontal) {
            HStack(spacing:16) { controls; Spacer(minLength:0) }
            VStack(alignment:.leading,spacing:8) { controls }
        }.buttonStyle(LargeButtonStyle()).accessibilitySortPriority(10)
    }
    @ViewBuilder private var controls: some View {
        Button(action:back) { Label(N("Înapoi", "Retour"),systemImage:"chevron.backward") }
            .disabled(!canGoBack).keyboardShortcut("[",modifiers:.command).accessibilityIdentifier("navigation.back")
        Button(action:home) { Label(N("Acasă · Rezumat", "Accueil · Résumé"),systemImage:"house") }
            .keyboardShortcut("h",modifiers:[.command,.shift]).accessibilityIdentifier("navigation.home")
    }
}
struct UnsavedEdits: PreferenceKey { static let defaultValue = false; static func reduce(value: inout Bool, nextValue: () -> Bool) { value = value || nextValue() } }
struct DestinationShell<Content: View>: View {
    let title: String
    @ViewBuilder var content: () -> Content
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var navigation: MonitorNavigation
    @State private var dirty = false
    @State private var confirmLeave = false
    @State private var goHome = false
    var body: some View {
        VStack(alignment:.leading,spacing:8) {
            AppNavBar(back:{ requestLeave(home:false) },home:{ requestLeave(home:true) }).padding([.top,.horizontal])
            Text(title).font(.headline).accessibilityAddTraits(.isHeader).padding(.horizontal)
            content()
        }
        .onPreferenceChange(UnsavedEdits.self) { dirty = $0 }
        .interactiveDismissDisabled(dirty)
        .alert(N("Modificări nesalvate", "Modifications non enregistrées"),isPresented:$confirmLeave) {
            Button(N("Rămâi aici", "Rester ici"),role:.cancel) {}
            Button(N("Părăsește ecranul", "Quitter l’écran"),role:.destructive) { leave() }
        } message: { Text(N("Păstrează notele sau confirmă că vrei să pleci fără ele.", "Enregistrez les notes ou confirmez que vous souhaitez partir sans elles.")) }
    }
    private func requestLeave(home: Bool) { goHome = home; if dirty { confirmLeave = true } else { leave() } }
    private func leave() { if goHome { navigation.home() }; dismiss() }
}

struct PivotPage: View {
    @EnvironmentObject var store: Store
    @State private var dimension: PivotDimension = .firmware
    @State private var location: TestLocation?
    @State private var metric: PivotMetric = .sessions
    @State private var pairID: UUID?
    @State private var channel = ""
    @State private var days = 0
    @State private var reference: UUID?
    @State private var simplified = true
    @State private var showChart = false
    private func dimensionName(_ d: PivotDimension) -> String {
        switch d { case .pair:return N("Pereche", "Appareil"); case .firmware:return N("Firmware și canal", "Firmware et canal"); case .audioMode:return N("Mod audio", "Mode audio"); case .month:return N("Lună · Europe/Zurich", "Mois · Europe/Zurich"); case .location:return N("Loc de test", "Lieu du test") }
    }
    private func metricName(_ m: PivotMetric) -> String {
        switch m { case .sessions:return N("Număr de sesiuni pe componentă", "Nombre de sessions par composant"); case .hours:return N("Durată totală pe componentă", "Durée totale par composant"); case .dischargeRate:return N("Consum ponderat · pp/oră", "Décharge pondérée · points/heure") }
    }
    private var result: Result<PivotReport,Error> {
        Result { try PivotReport.build(archive:store.archive,dimension:dimension,metric:metric,pairID:pairID,channel:channel.isEmpty ? nil : channel,since:days == 0 ? nil : Date().addingTimeInterval(-Double(days)*86_400),referenceID:reference,location:location) }
    }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Picker(N("Grupează rândurile după", "Regrouper les lignes par"),selection:$dimension) { ForEach(PivotDimension.allCases,id: \.self) { Text(dimensionName($0)).tag($0) } }
                Picker(N("Valoarea calculată", "Valeur calculée"),selection:$metric) { ForEach(PivotMetric.allCases,id: \.self) { Text(metricName($0)).tag($0) } }
                Picker(N("Filtru pereche", "Filtre appareil"),selection:$pairID) {
                    Text(N("Toate perechile", "Tous les appareils")).tag(nil as UUID?)
                    ForEach(store.archive.pairs) { Text($0.name).tag(Optional($0.id)) }
                }
                Picker(N("Filtru loc de test", "Filtre du lieu de test"),selection:$location) {
                    Text(N("Toate locurile", "Tous les lieux")).tag(nil as TestLocation?)
                    ForEach(TestLocation.allCases,id: \.self) { Text($0.title(language:Localization.language())).tag(Optional($0)) }
                }
                Picker(N("Canal firmware", "Canal du firmware"),selection:$channel) {
                    Text(N("Toate canalele", "Tous les canaux")).tag("")
                    Text(N("Stabil", "Stable")).tag("stable"); Text("Beta").tag("beta"); Text(N("Necunoscut", "Inconnu")).tag("unknown")
                }
                Picker(N("Perioadă", "Période"),selection:$days) {
                    Text(N("Toată perioada", "Toute la période")).tag(0)
                    Text(N("Ultimele 30 de zile", "Les 30 derniers jours")).tag(30)
                    Text(N("Ultimele 90 de zile", "Les 90 derniers jours")).tag(90)
                }
                if metric == .dischargeRate {
                    Picker(N("Test de referință · protocol identic", "Test de référence · protocole identique"),selection:$reference) {
                        Text(N("Alege un test", "Choisir un test")).tag(nil as UUID?)
                        ForEach(store.archive.sessions.filter(\.comparable).sorted { $0.start > $1.start }) { s in
                            Text("\(store.archive.pairs.first { $0.id == s.pairID }?.name ?? s.device.displayName) · \(s.start.formatted(.dateTime.locale(Localization.locale()))) · \(s.firmware) · \(s.volume)% · \(L(s.mode))").tag(Optional(s.id))
                        }
                    }
                    Text(N("Consumul este suma scăderilor procentuale împărțită la suma orelor. Include numai aceeași pereche și același protocol ca testul ales, fără întreruperi sau încărcare. Nu este o estimare a sănătății bateriei.", "La décharge est la somme des baisses en points divisée par la somme des heures. Seuls le même appareil et le même protocole que le test choisi sont inclus, sans interruption ni charge. Aucun diagnostic de santé de la batterie."))
                }
                Toggle(N("Lectură simplificată pentru VoiceOver", "Lecture simplifiée pour VoiceOver"),isOn:$simplified)
                Toggle(N("Afișează și graficul pivot", "Afficher aussi le graphique croisé"),isOn:$showChart)
                switch result {
                case .failure(let error): Text(error.localizedDescription).foregroundStyle(.red)
                case .success(let report): content(report)
                }
            }.padding()
        }.frame(minWidth:platformSheetWidth(600),minHeight:400)
    }
    private func valueText(_ cell: PivotCell) -> String {
        let value = cell.value.formatted(.number.precision(.fractionLength(metric == .sessions ? 0 : 2)).locale(Localization.locale()))
        switch metric { case .sessions:return value + N(" sesiuni", " sessions"); case .hours:return value + N(" ore", " heures"); case .dischargeRate:return value + N(" puncte procentuale pe oră", " points par heure") }
    }
    private func spoken(_ cell: PivotCell) -> String {
        cell.groupLabel + ". " + L(cell.component.rawValue) + ". " + valueText(cell) + ". " + N("Mostre: ", "Échantillons : ") + String(cell.sessionCount)
    }
    @ViewBuilder private func content(_ report: PivotReport) -> some View {
        Text(N("După filtre: ", "Après filtres : ") + "\(report.includedSessions) " + N("sesiuni incluse; ", "sessions incluses ; ") + "\(report.excludedSessions) " + N("excluse pentru validare/protocol/conflicte.", "exclues pour validation/protocole/conflits.")).accessibilityAddTraits(.isHeader)
        if report.needsReference { Text(N("Selectează un test de referință pentru calculul consumului.", "Choisissez un test de référence pour calculer la décharge.")) }
        else if report.cells.isEmpty { Text(N("Nu există date pentru aceste filtre. Nu sunt afișate zerouri sau date simulate.", "Aucune donnée pour ces filtres. Aucun zéro ou donnée simulée n’est affiché.")) }
        else {
            Text(N("Fiecare coloană se referă la o componentă. Aceeași sesiune poate apărea la stânga, dreapta și carcasă; nu însuma coloanele ca număr de teste distincte. Liniuța înseamnă date absente.", "Chaque colonne représente un composant. Une session peut apparaître à gauche, à droite et pour le boîtier ; n’additionnez pas les colonnes pour compter les tests distincts. Un tiret signifie une donnée absente."))
            if simplified {
                ForEach(report.cells) { cell in Text(spoken(cell)).frame(maxWidth:.infinity,alignment:.leading).padding(.vertical,6).accessibilityIdentifier("pivot.cell") }
            } else {
                pivotTable(report.cells)
            }
            if showChart { pivotChart(report.cells) }
            ShareLink(item:report.cells.map(spoken).joined(separator:"\n")) { Text(N("Partagează rezumatul pivot", "Partager le résumé croisé")) }
        }
    }
    private func pivotTable(_ cells: [PivotCell]) -> some View {
        let groups = Array(Set(cells.map(\.groupID))).sorted()
        let components = Component.allCases.filter { component in cells.contains { $0.component == component } }
        return ScrollView(.horizontal) {
            Grid(alignment:.leading,horizontalSpacing:24,verticalSpacing:16) {
                GridRow {
                    Text(dimensionName(dimension)).bold().accessibilityAddTraits(.isHeader)
                    ForEach(components) { Text(L($0.rawValue)).bold().accessibilityAddTraits(.isHeader) }
                }
                ForEach(groups,id: \.self) { group in
                    GridRow {
                        Text(cells.first { $0.groupID == group }?.groupLabel ?? group).bold()
                        ForEach(components) { component in
                            if let cell = cells.first(where:{ $0.groupID == group && $0.component == component }) {
                                Text(valueText(cell)).accessibilityLabel(spoken(cell))
                            } else { Text("—").accessibilityLabel((cells.first { $0.groupID == group }?.groupLabel ?? group) + ". " + L(component.rawValue) + ". " + N("Date absente", "Données absentes")) }
                        }
                    }.accessibilityElement(children:.contain)
                }
            }.padding(.vertical,8)
        }.accessibilityIdentifier("pivot.table")
    }
    private func chartGroup(_ cell: PivotCell, _ cells: [PivotCell]) -> String {
        let groups = Array(Set(cells.filter { $0.groupLabel == cell.groupLabel }.map(\.groupID))).sorted()
        let name = dimension == .audioMode ? L(cell.groupLabel) : cell.groupLabel
        return groups.count > 1 ? name + " · " + String((groups.firstIndex(of:cell.groupID) ?? 0) + 1) : name
    }
    private func pivotChart(_ cells: [PivotCell]) -> some View {
        Chart(cells) { cell in
            BarMark(x:.value(dimensionName(dimension),chartGroup(cell,cells)),y:.value(metricName(metric),cell.value))
                .foregroundStyle(by:.value(L("Componentă"),L(cell.component.rawValue)))
                .position(by:.value(L("Componentă"),L(cell.component.rawValue)))
                .accessibilityLabel(Text(chartGroup(cell,cells) + ". " + L(cell.component.rawValue)))
                .accessibilityValue(Text(valueText(cell)))
        }
        .chartYAxisLabel(metricName(metric)).frame(height:300)
        .accessibilityLabel(N("Grafic pivot. Aceleași valori sunt disponibile în tabel sau lista simplificată.", "Graphique croisé. Les mêmes valeurs sont disponibles dans le tableau ou la liste simplifiée."))
        .accessibilityIdentifier("pivot.chart")
    }
}

struct BrandIcon: View {
    var body: some View {
        #if SWIFT_PACKAGE
        Image("BrandMark",bundle:.module).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius:8))
        #else
        Image("BrandMark").resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius:8))
        #endif
    }
}


/// Physical, user-operated maintenance only; never sends a reset command or alters the journal.
struct PairResetGuide: View {
    let device: Device
    var body: some View {
        DisclosureGroup(N("Repornire / resetare · ghid", "Redémarrage / réinitialisation · guide")) {
            VStack(alignment: .leading, spacing: 12) {
                Text(N("Pașii se efectuează manual, pentru această pereche. Aplicația nu poate declanșa sau verifica resetarea AirPods. Istoricul și identificatorul perechii rămân păstrate.", "Effectuez les gestes manuellement, pour cette paire. L’app ne peut ni déclencher ni vérifier la réinitialisation des AirPods. L’historique et l’identifiant de la paire sont conservés."))
                if device == .other {
                    Text(N("Confirmă modelul înainte de a urma o procedură. Deschide ghidul Apple de mai jos.", "Confirmez le modèle avant toute procédure. Ouvrez le guide Apple ci-dessous."))
                } else {
                    Text(N("Repornire (soft reset)", "Redémarrage (soft reset)")).font(.headline).accessibilityAddTraits(.isHeader)
                    Text(device.isMax
                        ? N("Încarcă la cel puțin 50%. Ține apăsate Digital Crown și butonul modului de ascultare până când lumina clipește portocaliu (aproximativ 10 secunde), apoi eliberează imediat. Dacă menții apăsat până la alb, resetezi la fabrică.", "Chargez à au moins 50 %. Maintenez Digital Crown et le bouton du mode d’écoute jusqu’au clignotement orange (environ 10 secondes), puis relâchez immédiatement. Maintenir jusqu’au blanc rétablit les réglages d’usine.")
                        : N("Pune ambele căști în carcasă și închide capacul pentru cel puțin 10 secunde.", "Placez les deux écouteurs dans le boîtier et fermez le couvercle pendant au moins 10 secondes."))
                    DisclosureGroup(N("Resetare la fabrică (hard reset) · arată pașii", "Réglages d’usine (hard reset) · afficher les étapes")) {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(N("Va trebui să asociezi din nou căștile. «Uită acest dispozitiv» le elimină de pe dispozitivele conectate la același cont Apple. Resetarea nu elimină asocierea de proprietate cu un alt cont Apple.", "Vous devrez jumeler les écouteurs à nouveau. « Oublier cet appareil » les retire des appareils utilisant le même compte Apple. La réinitialisation ne supprime pas leur association au compte Apple d’un autre propriétaire."))
                            Text(factorySteps)
                            Text(N("Lumina portocalie, apoi albă indică resetarea. Reconectează urmând instrucțiunile Apple. Aplicația nu marchează automat procedura drept reușită.", "Le voyant orange, puis blanc indique la réinitialisation. Reconnectez selon les instructions Apple. L’app ne déclare pas automatiquement la procédure réussie."))
                        }
                    }
                }
                Link(N("Instrucțiuni Apple · repornire și resetare", "Instructions Apple · redémarrer et réinitialiser"), destination: URL(string: "https://support.apple.com/en-lamr/guide/airpods/iph561965261/web")!)
                Link(N("Apple · procedura detaliată de resetare", "Apple · procédure détaillée de réinitialisation"), destination: URL(string: device.isMax ? "https://support.apple.com/en-us/119838" : "https://support.apple.com/en-ie/118531")!)
            }.padding(.vertical, 8).textSelection(.enabled)
        }
    }
    private var factorySteps: String {
        if device.isMax {
            return N("Încarcă la cel puțin 50%. Ține apăsate Digital Crown și butonul modului de ascultare aproximativ 15 secunde, până când lumina clipește portocaliu, apoi alb.", "Chargez à au moins 50 %. Maintenez Digital Crown et le bouton du mode d’écoute environ 15 secondes, jusqu’au clignotement orange, puis blanc.")
        }
        let modern: [Device] = [.four, .fourANC, .five, .maria, .proThree]
        let preparation = N("1. Pune căștile în carcasă, închide capacul și așteaptă 30 de secunde.\n2. În Configurări → Bluetooth, dacă sunt afișate, alege informații → Uită acest dispozitiv și confirmă. Pe Mac folosește Configurări sistem → Bluetooth.\n3. Deschide capacul.\n", "1. Placez les écouteurs dans le boîtier, fermez et attendez 30 secondes.\n2. Dans Réglages → Bluetooth, s’ils figurent dans la liste, choisissez les informations → Oublier cet appareil et confirmez. Sur Mac, utilisez Réglages Système → Bluetooth.\n3. Ouvrez le couvercle.\n")
        return preparation + (modern.contains(device)
            ? N("4. Atinge de două ori partea frontală cât lumina este aprinsă. Repetă când clipește alb. Atinge din nou de două ori când clipește mai repede.", "4. Touchez deux fois l’avant lorsque le voyant est allumé. Répétez lorsqu’il clignote blanc. Touchez deux fois une troisième fois lorsqu’il clignote plus rapidement.")
            : N("4. Ține apăsat butonul de configurare din spatele carcasei aproximativ 15 secunde, până când lumina clipește portocaliu, apoi alb.", "4. Maintenez le bouton de configuration à l’arrière du boîtier environ 15 secondes, jusqu’au clignotement orange, puis blanc."))
    }
}


struct PrivacyOverview: View {
    private var policyURL: URL? {
        guard let text = Bundle.main.object(forInfoDictionaryKey:"PrivacyPolicyURL") as? String, let url = URL(string:text), url.scheme == "https", url.host != nil else { return nil }
        return url
    }
    var body: some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18) {
                Text(N("Datele tale", "Vos données")).font(.title).accessibilityAddTraits(.isHeader)
                Text(N("Jurnalul, numele dispozitivelor, notele, atașamentele și preferințele sunt păstrate local. În versiunea configurată pentru iCloud, datele jurnalului și preferințele folosesc baza privată CloudKit a contului tău. Varianta locală Mac are CloudKit dezactivat.", "Le journal, les noms d’appareils, notes, pièces jointes et préférences sont conservés localement. Dans la version configurée pour iCloud, le journal et les préférences utilisent la base CloudKit privée de votre compte. La version locale Mac désactive CloudKit."))
                Text(N("Exporturi și partajare", "Exports et partage")).font(.headline).accessibilityAddTraits(.isHeader)
                Text(N("Tu alegi unde salvezi sau partajezi fișierele. Exporturile JSON, CSV, XLSX și ZIP pot conține note și atașamente personale. Folderul suplimentar de backup este separat de sincronizarea CloudKit. Copiile de recuperare rămân pe dispozitiv.", "Vous choisissez où enregistrer ou partager les fichiers. Les exports JSON, CSV, XLSX et ZIP peuvent contenir des notes et pièces jointes personnelles. Le dossier de sauvegarde supplémentaire est distinct de la synchronisation CloudKit. Les copies de récupération restent sur l’appareil."))
                Text(N("Permisiuni opționale", "Autorisations facultatives")).font(.headline).accessibilityAddTraits(.isHeader)
                Text(N("Bluetooth ajută la alegerea dispozitivului. Localizarea poate păstra un reper local ales la cerere; nu localizează căștile. Microfonul se configurează numai la cerere, fără înregistrare sau retransmitere a vocii. Sănătate afișează temporar expunerea audio, fără salvare automată în jurnal sau iCloud. Verificarea firmware contactează site-ul Apple.", "Bluetooth aide à choisir l’appareil. La localisation peut conserver un repère local sur demande ; elle ne localise pas les écouteurs. Le microphone est configuré sur demande, sans enregistrement ni retransmission de la voix. Santé affiche temporairement l’exposition audio, sans enregistrement automatique dans le journal ou iCloud. La vérification du programme interne contacte le site Apple."))
                Text(N("Aplicația nu include reclame sau analiză de utilizare și nu folosește un server propriu pentru jurnal. Nu introduce informații medicale personale în jurnalul sincronizat.", "L’app n’intègre ni publicité ni analyse d’utilisation et n’utilise pas de serveur propre pour le journal. N’inscrivez pas d’informations médicales personnelles dans le journal synchronisé."))
                if let policyURL { Link(N("Politica de confidențialitate a editorului", "Politique de confidentialité de l’éditeur"),destination:policyURL) }
            }.padding().frame(maxWidth:700,alignment:.leading).textSelection(.enabled)
        }
    }
}

struct AppRelease: Codable, Sendable {
    let version: String
    let build: Int
    let notesRO: String
    let notesFR: String
    let downloadURL: URL
    func validate() throws {
        guard build > 0, !version.isEmpty, version.count < 50,
              notesRO.count < 20000, notesFR.count < 20000,
              downloadURL.scheme == "https", downloadURL.host != nil,
              downloadURL.user == nil, downloadURL.password == nil else { throw URLError(.badServerResponse) }
    }
}
@MainActor final class AppUpdates: ObservableObject {
    @Published var release: AppRelease?
    @Published var checking = false
    @Published var message = ""
    @Published var checkedAt: Date?
    private var attemptedAt: Date?
    func check(automatic: Bool = false) async {
        guard !checking else { return }
        if automatic, let attemptedAt, Date().timeIntervalSince(attemptedAt) < 86400 { return }
        guard let text = Bundle.main.object(forInfoDictionaryKey: "UpdateFeedURL") as? String,
              let url = URL(string: text), url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil else {
            if !automatic { message = N("Adresa de actualizare nu este configurată. Nu s-a verificat online.", "L’adresse de mise à jour n’est pas configurée. Aucune vérification en ligne.") }
            return
        }
        checking = true; attemptedAt = Date(); defer { checking = false }
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 20
            request.cachePolicy = .reloadIgnoringLocalCacheData
            let (bytes, response) = try await URLSession.shared.bytes(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200,
                  response.url?.scheme == "https" else { throw URLError(.badServerResponse) }
            var data = Data()
            for try await byte in bytes {
                guard data.count < 262144 else { throw URLError(.dataLengthExceedsMaximum) }
                data.append(byte)
            }
            let candidate = try JSONDecoder().decode(AppRelease.self, from: data)
            try candidate.validate()
            let installed = Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0
            release = candidate.build > installed ? candidate : nil
            checkedAt = Date()
            message = release == nil ? N("Nu este disponibilă o versiune mai nouă în sursa verificată.", "Aucune nouvelle version dans la source consultée.") : N("Este disponibilă o actualizare.", "Une mise à jour est disponible.")
        } catch {
            message = N("Verificarea nu a reușit. Versiunea instalată rămâne disponibilă.", "La vérification a échoué. La version installée reste disponible.")
        }
    }
}
struct AppUpdatesView: View {
    @ObservedObject var updates: AppUpdates
    var body: some View {
        Form {
            Text(N("Versiune instalată: ", "Version installée : ") + (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"))
            Toggle(N("Verifică automat la deschidere, cel mult o dată pe zi", "Vérifier à l’ouverture, au maximum une fois par jour"), isOn: Binding(get: { UserDefaults.standard.bool(forKey: "automaticAppUpdates") }, set: { UserDefaults.standard.set($0, forKey: "automaticAppUpdates") }))
            Button(N("Verifică actualizările", "Rechercher les mises à jour")) { Task { await updates.check() } }.disabled(updates.checking)
            if updates.checking { ProgressView() }
            Text(updates.message).accessibilityAddTraits(.updatesFrequently)
            if let date = updates.checkedAt { Text(N("Ultima verificare reușită: ", "Dernière vérification réussie : ") + date.formatted()) }
            if let release = updates.release {
                Text(release.version).font(.headline)
                Text(N(release.notesRO, release.notesFR)).textSelection(.enabled)
                Link(N("Deschide pagina de descărcare", "Ouvrir la page de téléchargement"), destination: release.downloadURL)
            }
            Text(N("Instalarea necesită confirmarea ta. Această versiune nu înlocuiește automat aplicația și nu șterge datele.", "L’installation nécessite votre confirmation. Cette version ne remplace pas automatiquement l’app et ne supprime pas les données."))
            Section(N("Noutăți în 1.5.3", "Nouveautés de la version 1.5.3")) {
                Text(N("Verificare opțională a actualizărilor și afișarea noutăților. Corecția redării muzicii din 1.5.2 este inclusă.", "Vérification facultative des mises à jour et affichage des nouveautés. Le correctif de lecture musicale de la version 1.5.2 est inclus."))
            }
        }.padding().frame(minWidth: 320, minHeight: 320)
    }
}
