import SwiftUI
import UserNotifications
#if os(macOS)
import AppKit
#else
import UIKit
import AudioToolbox
#endif
#if canImport(MonitorCore)
import MonitorCore
#endif

struct DashboardPage: View {
    let pair: AirPodsPair
    @EnvironmentObject var store: Store
    @EnvironmentObject var audio: AudioLab
    @EnvironmentObject var live: LiveMonitor
    @EnvironmentObject var alerts: BatteryAlerts
    @State private var levels: [Component: Int] = [:]
    @State private var selected = Set<Component>()
    @State private var observedAt = Date()
    @State private var confirmed = false
    @State private var message = ""
    @State private var referenceID: UUID?
    var readings: [BatteryObservation] { store.archive.latestBattery(pair: pair) }
    var tests: [Session] { store.archive.sessions.filter { $0.pairID == pair.id && $0.comparable && $0.end <= Date() }.sorted { $0.end > $1.end } }
    var reference: Session? { tests.first { $0.id == referenceID } ?? tests.first }
    var snapshot: WidgetSnapshot { WidgetSnapshot(pairName: pair.name, readings: readings, language: Localization.locale().identifier, trackTitle: audio.playing ? audio.title : nil, earbudAlertThreshold: alerts.preferences.earbudThreshold, caseAlertThreshold: alerts.preferences.caseThreshold, criticalAlertThreshold: alerts.preferences.criticalThreshold) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("Battery overview")).font(.headline)
                Text(pair.name).font(.title3.bold())
                Text(L("Last observed battery, not a live reading. Values older than 15 minutes are marked as old; they are never extrapolated."))
                TimelineView(.periodic(from: .now, by: 60)) { timeline in
                    VStack(alignment: .leading, spacing: 14) {
                        ForEach(pair.device.components) { component in
                            GroupBox {
                                VStack(alignment: .leading, spacing: 6) {
                                    Label(L(component.rawValue), systemImage: component.batterySymbol).font(.headline)
                                    if let value = readings.first(where: { $0.component == component }) {
                                        Text("\(value.level)%").font(.largeTitle.monospacedDigit())
                                        Text("Introdus / Saisi · \(value.evidenceLabel.rawValue)")
                                        if let severity = alerts.preferences.severity(component: component, level: value.level) {
                                            Label(severity == .critical ? L("Critical at last observation") : L("Low at last observation"), systemImage: "exclamationmark.triangle.fill").foregroundStyle(severity == .critical ? .red : .orange)
                                        }
                                        VerticalValue(title: L(component.rawValue), value: .constant(Double(value.level)), editable: false)
                                        Text(L("Observed at {0}", date(value.observedAt)))
                                        Text(value.stale(at: timeline.date) ? L("Old observation · refresh manually") : L("Recent manual observation"))
                                        Text(value.fromTest ? L("Source: end of a saved test") : L("Source: manual battery observation")).font(.caption)
                                    } else { Text("Indisponibil / Indisponible · " + L("No observation for this component")) }
                                }.frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                    }
                }
                BatteryAlertSettings()
                GroupBox(L("Record battery now")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("Read the percentages in Apple’s battery interface, then enter only the components you can see. The initial values are not measurements."))
                        ForEach(pair.device.components) { component in
                            Toggle(L(component.rawValue), isOn: Binding(get: { selected.contains(component) }, set: { if $0 { selected.insert(component) } else { selected.remove(component) } }))
                            if selected.contains(component) {
                                PercentageControl(title: L(component.rawValue), value: Binding(get: { levels[component] ?? 100 }, set: { levels[component] = $0 }))
                            }
                        }
                        DatePicker(L("Observation time"), selection: $observedAt, in: ...Date())
                        Button(L("Use current time")) { observedAt = Date() }
                        Toggle(L("I entered actual observed percentages"), isOn: $confirmed)
                        Button(L("Save battery observation")) { saveObservation() }.disabled(store.error != nil)
                        Text(message)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(L("Widget and Dynamic Island")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("Publish the selected pair’s last observations, including their original time. Widgets refresh when the system permits; Live Activities do not read AirPods in the background."))
                        Button(L("Update widget and existing Live Activity")) { Task { await live.publish(snapshot) } }.disabled(readings.isEmpty)
                        #if os(iOS)
                        Button(L("Start / replace Live Activity · iPhone")) { Task { await live.start(pairID: pair.id, snapshot: snapshot) } }.disabled(readings.isEmpty)
                        Button(L("Stop Live Activity")) { Task { await live.end() } }
                        #else
                        Text(L("Dynamic Island is an iPhone feature. Use the widget on Mac."))
                        #endif
                        Text(live.message)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox(L("First, latest, best and average consumption")) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text(L("Only the same physical pair and protocol are compared. Best means the lowest observed consumption per hour, not a battery health score."))
                        if !tests.isEmpty {
                            Picker(L("Reference protocol"), selection: $referenceID) {
                                Text(L("Use the latest comparable test")).tag(nil as UUID?)
                                ForEach(tests) { Text(L("{0} · {1}% · {2}", date($0.end), String($0.volume), L($0.mode))).tag(Optional($0.id)) }
                            }
                        }
                        if let reference {
                            ForEach(pair.device.components) { component in
                                if let result = AutonomySummary.calculate(sessions: tests, anchor: reference, component: component) {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(L(component.rawValue)).font(.headline)
                                        Text(L("First: {0} pp/hour · {1}", number(result.first.rate), date(result.first.session.end)))
                                        Text(L("Latest: {0} pp/hour · {1}", number(result.last.rate), date(result.last.session.end)))
                                        Text(L("Best: {0} pp/hour · {1}", number(result.best.rate), date(result.best.session.end)))
                                        Text(L("Mean: {0} pp/hour · tests: {1}", number(result.mean), String(result.count)))
                                        if result.count > 1 {
                                            Text(L("Latest minus first: {0} pp/hour", number(result.differenceFromFirst)))
                                            Text(L("Latest minus best: {0} pp/hour", number(result.differenceFromBest)))
                                            if let change = result.percentageChangeFromFirst { Text(L("Relative change from first: {0}% · negative means less consumption", number(change))) }
                                            else { Text(L("Relative change is undefined because the first rate is zero.")) }
                                        } else { Text(L("One comparable test is not enough to establish a trend.")) }
                                    }
                                    Divider()
                                }
                            }
                        } else { Text(L("Save a comparable test to see these results.")) }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
            }.padding()
        }.onAppear {
            if levels.isEmpty {
                selected = Set(pair.device.components)
                for c in pair.device.components { levels[c] = readings.first { $0.component == c }?.level ?? 100 }
            }
        }
    }
    func saveObservation() {
        guard confirmed, !selected.isEmpty, observedAt <= Date() else { message = L("Choose components, confirm the measured values and use a time that is not in the future."); return }
        for c in pair.device.components where selected.contains(c) {
            store.archive.observations.append(.init(pairID: pair.id, component: c, level: levels[c] ?? 100, observedAt: observedAt))
        }
        store.save()
        if store.error == nil { message = L("Battery observation saved."); confirmed = false; Task { await live.publish(snapshot) } }
        else { message = L("Observation is in memory. Export the journal before closing.") }
    }
    func number(_ value: Double) -> String { value.formatted(.number.precision(.fractionLength(1)).locale(Localization.locale())) }
    func date(_ value: Date) -> String { value.formatted(.dateTime.day().month(.abbreviated).hour().minute().locale(Localization.locale())) }
}

@MainActor
final class BatteryAlerts: ObservableObject {
    @Published var preferences = BatteryAlertPreferences() {
        didSet { if preferences.isValid, let data = try? JSONEncoder().encode(preferences) { UserDefaults.standard.set(data, forKey: "batteryAlertPreferences") } }
    }
    @Published var message = ""
    @Published private(set) var notificationAllowed = false
    private var latches: [String: BatteryAlertLatch] = [:]
    private var primed = false
    private var restoreToken: NSObjectProtocol?
    #if os(macOS)
    private var sound: NSSound?
    #else
    private var soundID: SystemSoundID = 0
    #endif
    init() {
        restoreToken = NotificationCenter.default.addObserver(forName:Notification.Name("AirPodsPortableSettingsRestored"),object:nil,queue:.main) { [weak self] _ in
            Task { @MainActor in
                if let data = UserDefaults.standard.data(forKey:"batteryAlertPreferences"), let settings = try? JSONDecoder().decode(BatteryAlertPreferences.self,from:data), settings.isValid { self?.preferences = settings }
            }
        }
        if let data = UserDefaults.standard.data(forKey: "batteryAlertPreferences"), let settings = try? JSONDecoder().decode(BatteryAlertPreferences.self, from: data), settings.isValid { preferences = settings }
        if let data = UserDefaults.standard.data(forKey: "batteryAlertLatches"), let saved = try? JSONDecoder().decode([String: BatteryAlertLatch].self, from: data) { latches = saved }
    }
    private var soundURL: URL? {
        #if SWIFT_PACKAGE
        Bundle.module.url(forResource: "GentleBattery", withExtension: "wav")
        #else
        Bundle.main.url(forResource: "GentleBattery", withExtension: "wav")
        #endif
    }
    private var isActive: Bool {
        #if os(macOS)
        NSApplication.shared.isActive
        #else
        UIApplication.shared.applicationState == .active
        #endif
    }
    private func latest(_ archive: Archive) -> [BatteryObservation] { archive.pairs.flatMap { archive.latestBattery(pair: $0) } }
    func prime(_ archive: Archive) {
        guard !primed else { return }; primed = true
        BatteryAlertPolicy.prime(readings: latest(archive), preferences: preferences, latches: &latches)
        persist()
    }
    func process(_ archive: Archive) {
        let events = BatteryAlertPolicy.evaluate(readings: latest(archive), preferences: preferences, latches: &latches)
        persist()
        guard !events.isEmpty else { return }
        let body = events.map { event in
            let name = archive.pairs.first { $0.id == event.reading.pairID }?.name ?? "AirPods"
            return L("{0} · {1}: {2}%", name, L(event.reading.component.rawValue), String(event.reading.level))
        }.joined(separator: "\n")
        if preferences.visualEnabled && isActive { AccessibilityNotification.Announcement(L("Low battery: {0}", body)).post() }
        if preferences.soundEnabled {
            #if os(macOS)
            playGentleSound()
            #else
            if isActive { playGentleSound() }
            #endif
        }
        if preferences.systemNotifications && !isActive { Task { await deliver(body: body, pairID: events[0].reading.pairID) } }
    }
    private func persist() { if let data = try? JSONEncoder().encode(latches) { UserDefaults.standard.set(data, forKey: "batteryAlertLatches") } }
    func refreshNotificationStatus() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        notificationAllowed = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
        if !notificationAllowed { preferences.systemNotifications = false }
    }
    func requestNotifications() async {
        do {
            let granted = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound])
            notificationAllowed = granted; preferences.systemNotifications = granted
            message = granted ? L("System notifications enabled. Focus and system sound settings still apply.") : L("Notifications were not allowed. In-app visual and sound alerts remain available.")
        } catch { preferences.systemNotifications = false; message = L("Notification permission failed: {0}", error.localizedDescription) }
    }
    private func deliver(body: String, pairID: UUID) async {
        let content = UNMutableNotificationContent()
        content.title = L("Low AirPods / case battery")
        content.body = body; content.threadIdentifier = pairID.uuidString
        #if os(iOS)
        if preferences.soundEnabled && soundURL != nil { content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "GentleBattery.wav")) }
        #endif
        do { try await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "battery-" + UUID().uuidString, content: content, trigger: nil)) }
        catch { message = L("Notification could not be delivered: {0}", error.localizedDescription) }
    }
    func playGentleSound() {
        guard preferences.soundEnabled else { return }
        guard let url = soundURL else { message = L("Sound playback is unavailable. The visual warning remains available."); return }
        #if os(macOS)
        sound?.stop()
        sound = NSSound(contentsOf: url, byReference: true); sound?.volume = 0.6; sound?.loops = false
        message = sound?.play() == true ? L("Gentle sound requested. Its loudness follows your device’s sound settings.") : L("Sound playback is unavailable. The visual warning remains available.")
        #else
        if soundID == 0 {
            guard AudioServicesCreateSystemSoundID(url as CFURL, &soundID) == noErr else { message = L("Sound playback is unavailable. The visual warning remains available."); return }
        }
        AudioServicesPlaySystemSound(soundID)
        message = L("Gentle sound requested. Its loudness follows your device’s sound settings.")
        #endif
    }
}
struct LowBatteryBanner: View {
    let pair: AirPodsPair
    @EnvironmentObject var store: Store
    @EnvironmentObject var alerts: BatteryAlerts
    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { context in
            let values = store.archive.latestBattery(pair: pair, now: context.date).filter { !$0.stale(at: context.date) && alerts.preferences.severity(component: $0.component, level: $0.level) != nil }
            if alerts.preferences.visualEnabled && !values.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    Label(L("Low AirPods / case battery"), systemImage: "exclamationmark.triangle.fill").font(.headline)
                    ForEach(values, id: \.component) { value in Text(L("{0}: {1}% · observed at {2}", L(value.component.rawValue), String(value.level), value.observedAt.formatted(.dateTime.hour().minute().locale(Localization.locale())))) }
                }.padding(10).frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.orange.opacity(0.18), in: RoundedRectangle(cornerRadius: 10))
                    .accessibilityElement(children: .combine)
            }
        }
    }
}
struct BatteryAlertSettings: View {
    @EnvironmentObject var alerts: BatteryAlerts
    var body: some View {
        GroupBox(L("Low battery alerts")) {
            VStack(alignment: .leading, spacing: 12) {
                Toggle(L("In-app warning banner"), isOn: $alerts.preferences.visualEnabled)
                Toggle(L("Gentle sound"), isOn: $alerts.preferences.soundEnabled)
                PercentageControl(title: L("Earbuds / Max warning: {0}%", String(alerts.preferences.earbudThreshold)), value: $alerts.preferences.earbudThreshold, range: max(5, alerts.preferences.criticalThreshold)...50)
                PercentageControl(title: L("Case warning: {0}%", String(alerts.preferences.caseThreshold)), value: $alerts.preferences.caseThreshold, range: max(5, alerts.preferences.criticalThreshold)...50)
                PercentageControl(title: L("Critical warning: {0}%", String(alerts.preferences.criticalThreshold)), value: $alerts.preferences.criticalThreshold, range: 1...min(alerts.preferences.earbudThreshold, alerts.preferences.caseThreshold))
                Button(L("Test gentle sound")) { alerts.playGentleSound() }.disabled(!alerts.preferences.soundEnabled)
                Button(L("Allow system notifications")) { Task { await alerts.requestNotifications() } }
                Toggle(L("System notifications when the app is not active"), isOn: $alerts.preferences.systemNotifications).disabled(!alerts.notificationAllowed)
                Text(L("Alerts follow newly saved, recent readings. They cannot detect an AirPods battery drop while the app has no new reading. An old percentage never triggers a sound."))
                Text(L("One warning per component and discharge episode, with one critical escalation. A reading at least 5 points above the low threshold re-arms the warning; a 10-minute cooldown limits repeats."))
                Text(L("Sounds use the current device output, not the case speaker. Silent mode, Focus and system volume may mute them. No critical alerts or system-volume changes."))
                Text(alerts.message).font(.callout)
            }.frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
