import SwiftUI
import Charts
import AVFAudio
import AudioToolbox
import UniformTypeIdentifiers
import MediaPlayer
#if canImport(MonitorCore)
import MonitorCore
#endif

/// Small synchronized mailbox: the audio callback never updates SwiftUI or schedules tasks.
private enum AudioFeatureError: LocalizedError {
    case unavailable
    var errorDescription: String? { L("Audio components are unavailable on this system. Battery features still work.") }
}
final class MeterBox: @unchecked Sendable {
    // Created outside MainActor: AVAudioEngine invokes this on its audio service queue.
    nonisolated static func makeTap(_ box: MeterBox) -> AVAudioNodeTapBlock {
        return { buffer, _ in
            guard let channels = buffer.floatChannelData, buffer.frameLength > 0, buffer.format.channelCount > 0 else { box.reset(); return }
            // Bounded min/max envelope of the first output channel, after EQ and player volume.
            // Never copy the AVAudioPCMBuffer outside the callback or publish UI state here.
            box.updateWaveform(AudioWaveformEnvelope.extract(UnsafeBufferPointer(start: channels[0], count: Int(buffer.frameLength))))
            var sum: Double = 0
            for c in 0..<Int(buffer.format.channelCount) {
                for i in 0..<Int(buffer.frameLength) { let sample = channels[c][i]; let x = sample.isFinite ? Double(sample) : 0; sum += x*x }
            }
            let rms = sqrt(sum / Double(Int(buffer.frameLength) * Int(buffer.format.channelCount)))
            box.update(min(0, max(-60, 20 * log10(max(rms, 0.0000001)))))
        }
    }
    private let lock = NSLock()
    private var db: Double = -60
    private var waveform: [Float] = []
    func update(_ value: Double) { lock.lock(); db = value; lock.unlock() }
    func read() -> Double { lock.lock(); defer { lock.unlock() }; return db }
    func updateWaveform(_ samples: [Float]) { lock.lock(); waveform = samples; lock.unlock() }
    func readWaveform() -> [Float] { lock.lock(); defer { lock.unlock() }; return waveform }
    func reset() { lock.lock(); db = -60; waveform = []; lock.unlock() }
}
@MainActor
final class AudioLab: ObservableObject {
    var onPlaybackChange: (@MainActor (String?) -> Void)?
    @Published var title = ""
    @Published var playing = false
    @Published var message = ""
    @Published var musicTitle = ""
    @Published var musicCheckedAt: Date?
    @Published var volume: Float = 0.25 { didSet { player?.volume = volume; settingsRevision += 1; UserDefaults.standard.set(Double(volume),forKey:"playerVolume") } }
    @Published private(set) var settingsRevision = 0
    @Published var settings = EQSettings() { didSet { settingsRevision += 1; applyEQ(); if let data = try? JSONEncoder().encode(settings) { UserDefaults.standard.set(data, forKey: "parametricEQ") } } }
    @Published private(set) var customPresets: [EQPreset] = []
    private var presetLibraryWritable = true
    private var engine: AVAudioEngine?
    private var player: AVAudioPlayerNode?
    private var eq: AVAudioUnitEQ?
    private let meter = MeterBox()
    private var file: AVAudioFile?
    private var scopedURL: URL?
    private var scopeGranted = false
    private var scheduled = false
    private var playbackToken = UUID()
    private var notificationTokens: [NSObjectProtocol] = []
    func reloadPortableSettings() {
        stop()
        if let data = UserDefaults.standard.data(forKey:"parametricEQ"), let value = try? JSONDecoder().decode(EQSettings.self,from:data), value.isValid { settings = value }
        if let data = UserDefaults.standard.data(forKey:"customEQPresets"), let values = try? JSONDecoder().decode([EQPreset].self,from:data), EQPreset.validLibrary(values) { customPresets = values; presetLibraryWritable = true }
        if let value = UserDefaults.standard.object(forKey:"playerVolume") as? Double, value.isFinite, (0...1).contains(value) { volume = Float(value) }
    }
    init() {
        notificationTokens.append(NotificationCenter.default.addObserver(forName:Notification.Name("AirPodsPortableSettingsRestored"),object:nil,queue:.main) { [weak self] _ in
            Task { @MainActor in self?.reloadPortableSettings() }
        })
        if let value = UserDefaults.standard.object(forKey:"playerVolume") as? Double, value.isFinite, (0...1).contains(value) { volume = Float(value) }
        if let data = UserDefaults.standard.data(forKey: "customEQPresets") {
            if let presets = try? JSONDecoder().decode([EQPreset].self, from: data), EQPreset.validLibrary(presets) { customPresets = presets }
            else { presetLibraryWritable = false; message = L("Saved presets could not be read. The original library is preserved; saving and deletion are disabled.") }
        }
        if let data = UserDefaults.standard.data(forKey: "parametricEQ"), let restored = try? JSONDecoder().decode(EQSettings.self, from: data), restored.isValid { settings = restored }
        #if os(iOS)
        notificationTokens.append(NotificationCenter.default.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let began = (note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt) == AVAudioSession.InterruptionType.began.rawValue
            if began { Task { @MainActor in self?.stop(); self?.message = L("Playback interrupted. Resume explicitly when ready.") } }
        })
        notificationTokens.append(NotificationCenter.default.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let removed = (note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt) == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue
            if removed { Task { @MainActor in self?.stop(); self?.message = L("Audio output disconnected. Playback stopped; check the route before playing again.") } }
        })
        #endif
    }
    func savePreset(name: String, device: Device? = nil, homePod: HomePodModel? = nil) {
        guard presetLibraryWritable else { message = L("Saved presets could not be read. The original library is preserved; saving and deletion are disabled."); return }
        let candidate = EQPreset(name: name, settings: settings, device: device, homePod: homePod)
        let proposed = customPresets + [candidate]
        guard EQPreset.validLibrary(proposed) else { message = L("Use a unique name of 1–60 characters, without line breaks. Maximum 50 saved presets. Existing presets are not overwritten."); return }
        persistPresets(proposed)
        if customPresets.contains(where: { $0.id == candidate.id }) { message = L("Preset saved locally: {0}", candidate.name) }
    }
    func updatePreset(id: UUID, name: String) {
        guard presetLibraryWritable else { message = L("Saved presets could not be read. The original library is preserved; saving and deletion are disabled."); return }
        guard let proposed = EQPreset.replacing(in: customPresets, id: id, name: name, settings: settings) else {
            message = L("Choose an existing personal preset and a unique valid name. Built-in presets cannot be changed."); return
        }
        persistPresets(proposed)
        message = L("Personal preset updated: {0}", proposed.first(where: { $0.id == id })?.name ?? name)
    }
    func removePreset(_ id: UUID) {
        guard presetLibraryWritable, let preset = customPresets.first(where: { $0.id == id }) else { return }
        persistPresets(customPresets.filter { $0.id != id })
        message = L("Personal preset deleted: {0}", preset.name)
    }
    private func persistPresets(_ presets: [EQPreset]) {
        guard EQPreset.validLibrary(presets), let data = try? JSONEncoder().encode(presets) else { return }
        UserDefaults.standard.set(data, forKey: "customEQPresets"); customPresets = presets
    }
    func applyPreset(_ preset: EQPreset) {
        guard preset.isValid else { return }
        settings = preset.settings; message = L("Preset applied: {0}", preset.name)
    }
    private func prepareEngine() throws {
        if engine != nil { return }
        let requirements: [(OSType, OSType)] = [(kAudioUnitType_Effect, kAudioUnitSubType_NBandEQ), (kAudioUnitType_Mixer, kAudioUnitSubType_MultiChannelMixer), (kAudioUnitType_Generator, kAudioUnitSubType_ScheduledSoundPlayer)]
        for (type, subtype) in requirements {
            var description = AudioComponentDescription(componentType: type, componentSubType: subtype, componentManufacturer: kAudioUnitManufacturer_Apple, componentFlags: 0, componentFlagsMask: 0)
            guard AudioComponentFindNext(nil, &description) != nil else { throw AudioFeatureError.unavailable }
        }
        let engine = AVAudioEngine(), player = AVAudioPlayerNode(), eq = AVAudioUnitEQ(numberOfBands: 10)
        self.engine = engine; self.player = player; self.eq = eq
        engine.attach(player); engine.attach(eq)
        engine.connect(player, to: eq, format: nil)
        engine.connect(eq, to: engine.mainMixerNode, format: nil)
        player.volume = volume
        engine.mainMixerNode.installTap(onBus: 0, bufferSize: 1024, format: nil, block: MeterBox.makeTap(meter))
        applyEQ()
    }
    var protocolSignature: String {
        let identity = [title, String(file?.length ?? 0), String(file?.processingFormat.sampleRate ?? 0), String(file?.processingFormat.channelCount ?? 0)]
        let encoded = (try? JSONEncoder().encode(identity).base64EncodedString()) ?? ""
        return settings.signature(playerGain: volume) + "|file:" + encoded
    }
    var dbFS: Double { playing ? meter.read() : -60 }
    var waveform: [Float] { playing ? meter.readWaveform() : [] }
    var hasFile: Bool { file != nil }
    var canStop: Bool { scheduled || playing }
    var duration: Double { guard let file else { return 0 }; return Double(file.length) / file.processingFormat.sampleRate }
    var elapsed: Double {
        guard scheduled, let player, let time = player.lastRenderTime, let position = player.playerTime(forNodeTime: time), position.sampleRate > 0 else { return 0 }
        return min(duration, max(0, Double(position.sampleTime) / position.sampleRate))
    }
    private func applyEQ() {
        guard settings.isValid, let eq else { return }
        eq.globalGain = Float(settings.effectivePreamp)
        let maxFrequency = max(20, min(20000, eq.outputFormat(forBus: 0).sampleRate * 0.45))
        for (index, band) in settings.bands.enumerated() {
            eq.bands[index].filterType = .parametric
            eq.bands[index].frequency = Float(min(band.frequency, maxFrequency))
            eq.bands[index].gain = Float(band.gain)
            eq.bands[index].bandwidth = Float(min(5, max(0.05, band.bandwidth)))
            eq.bands[index].bypass = settings.bypass
        }
    }
    func load(_ url: URL) {
        stop()
        if scopeGranted { scopedURL?.stopAccessingSecurityScopedResource() }
        scopeGranted = url.startAccessingSecurityScopedResource(); scopedURL = url
        do {
            try prepareEngine()
            guard let engine, let player, let eq else { throw AudioFeatureError.unavailable }
            let candidate = try AVAudioFile(forReading: url, commonFormat: .pcmFormatFloat32, interleaved: false)
            guard candidate.length > 0 else { throw CocoaError(.fileReadCorruptFile) }
            engine.stop()
            engine.disconnectNodeOutput(player); engine.disconnectNodeOutput(eq)
            engine.connect(player, to: eq, format: candidate.processingFormat)
            engine.connect(eq, to: engine.mainMixerNode, format: candidate.processingFormat)
            file = candidate; title = url.deletingPathExtension().lastPathComponent; settingsRevision += 1
            message = L("File ready. Playback starts only when you press Play.")
        } catch {
            file = nil; title = ""; updateNowPlaying(); message = L("Audio file could not be opened: {0}", error.localizedDescription)
            if scopeGranted { url.stopAccessingSecurityScopedResource(); scopeGranted = false }
        }
    }
    func playPause() {
        if playing { player?.pause(); meter.reset(); playing = false; updateNowPlaying(); return }
        guard let file else { message = L("Import an unprotected audio file first."); return }
        do {
            guard let engine, let player else { throw AudioFeatureError.unavailable }
            #if os(iOS)
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default)
            try session.setActive(true)
            #endif
            if !engine.isRunning { try engine.start() }
            applyEQ()
            if !scheduled {
                playbackToken = UUID(); let token = playbackToken
                player.scheduleFile(file, at: nil, completionCallbackType: .dataPlayedBack) { @Sendable [weak self] _ in
                    Task { @MainActor in
                        guard let self, self.playbackToken == token else { return }
                        self.playing = false; self.scheduled = false; self.updateNowPlaying()
                    }
                }
                scheduled = true
            }
            player.play(); playing = true; updateNowPlaying(); message = ""
        } catch { message = L("Playback failed: {0}", error.localizedDescription); stop() }
    }
    func stop() {
        playbackToken = UUID(); player?.stop(); scheduled = false; playing = false; meter.reset()
        engine?.pause(); updateNowPlaying(); MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        #if os(iOS)
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        #endif
    }
    private func updateNowPlaying() {
        // Publish only our own playback. Never read another app's private Now Playing state.
        onPlaybackChange?(playing ? title : nil)
        MPNowPlayingInfoCenter.default().nowPlayingInfo = title.isEmpty ? nil : [MPMediaItemPropertyTitle: title, MPNowPlayingInfoPropertyPlaybackRate: playing ? 1.0 : 0.0]
    }
    func readAppleMusic() {
        #if os(iOS)
        MPMediaLibrary.requestAuthorization { [weak self] status in
            Task { @MainActor in
                guard let self else { return }
                guard status == .authorized else { self.message = L("Apple Music access is unavailable. Local playback still works."); return }
                let item = MPMusicPlayerController.systemMusicPlayer.nowPlayingItem
                self.musicTitle = [item?.title, item?.artist].compactMap { $0 }.joined(separator: " · ")
                self.musicCheckedAt = Date()
                if self.musicTitle.isEmpty { self.message = L("Apple Music has no readable current item. Other apps are not covered.") }
            }
        }
        #else
        message = L("A universal current-track reader for other Mac apps is not implemented. The player below shows its own file.")
        #endif
    }
}
struct AudioLabPage: View {
    @EnvironmentObject var audio: AudioLab
    @State private var importing = false
    @State private var presetName = ""
    @State private var editingPresetID: UUID?
    @State private var presetDevice: Device = .four
    @State private var presetForHomePod = false
    @State private var presetHomePod: HomePodModel = .original
    @State private var builtInPreset: BuiltInEQPreset = .balanced
    @AppStorage("eqControlMode") private var controlModeRaw = EQControlMode.expert.rawValue
    private var controlMode: EQControlMode { EQControlMode(rawValue: controlModeRaw) ?? .expert }
    private var bandMinimumWidth: CGFloat { controlMode == .basic ? 180 : (controlMode == .advanced ? 320 : 460) }
    @State private var availableWidth: CGFloat = 350
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text(L("Audio player and parametric EQ")).font(.headline)
                Text(L("EQ and the real VU meter process only files played here. They do not change AirPods firmware, Apple Music, Spotify or the system-wide sound."))
                AudioRoutingPanel()
                Button(L("Import audio file")) { importing = true }
                Text(audio.title.isEmpty ? L("No file selected") : audio.title).font(.headline)
                HStack {
                    Button(audio.playing ? L("Pause") : L("Play")) { audio.playPause() }.disabled(!audio.hasFile)
                    Button(L("Stop")) { audio.stop() }.disabled(!audio.canStop)
                }
                Text(L("Player volume"))
                VerticalValue(title: L("Player volume"), value: Binding(get: { Double(audio.volume) * 100 }, set: { audio.volume = Float($0 / 100) }))
                TimelineView(.periodic(from: .now, by: 0.1)) { _ in
                    VStack(alignment: .leading) {
                        let level = audio.dbFS
                        if audio.hasFile {
                            Text(L("Playback: {0} / {1} seconds", number(audio.elapsed), number(audio.duration))).monospacedDigit()
                            ProgressView(value: audio.elapsed, total: max(0.001, audio.duration))
                                .accessibilityLabel(L("Playback progress"))
                                .accessibilityValue(L("Playback: {0} / {1} seconds", number(audio.elapsed), number(audio.duration)))
                        }
                        LiveWaveform(samples: audio.waveform, playing: audio.playing)
                        Text(L("Actual output level: {0} dBFS", level.formatted(.number.precision(.fractionLength(1)).locale(Localization.locale()))))
                        VerticalValue(title: L("VU meter for this player"), value: .constant(level), range: -60...0, unit: "dBFS", editable: false)
                    }
                }
                Text(L("dBFS is a digital signal level, not the sound pressure at your ears. Widgets and Dynamic Island do not display a fake animated VU meter.")).font(.callout)
                Toggle(L("Bypass EQ"), isOn: $audio.settings.bypass)
                Toggle(L("Automatic headroom for boosts"), isOn: $audio.settings.automaticHeadroom)
                Text(L("Preamp: {0} dB · effective: {1} dB", number(audio.settings.preamp), number(audio.settings.effectivePreamp)))
                VerticalValue(title: L("Preamp in decibels"), value: $audio.settings.preamp, range: -24...0, step: 0.5, unit: "dB")
                EQBandGraph(settings: audio.settings)
                GroupBox(L("EQ presets")) {
                    VStack(alignment: .leading, spacing: 14) {
                        ViewThatFits(in: .horizontal) {
                            HStack { flatAndReset }
                            VStack(alignment: .leading) { flatAndReset }
                        }
                        Text(L("Flat sets all ten gains to 0 dB and keeps frequencies, Q and preamp. Reset restores ten bands, Q 1, preamp −6 dB, automatic headroom on and bypass off. Saved presets are kept."))
                        Text(L("Built-in presets · read-only")).font(.headline).accessibilityAddTraits(.isHeader)
                        Picker(L("Built-in preset"), selection: $builtInPreset) {
                            ForEach(BuiltInEQPreset.allCases) { Text(L($0.rawValue)).tag($0) }
                        }
                        Button(L("Apply selected preset")) { editingPresetID = nil; audio.settings = builtInPreset.settings; audio.message = L("Preset applied: {0}", L(builtInPreset.rawValue)) }
                        Text(L("Gentle starting points for this player, not Apple presets or model-specific AirPods calibration. Listen at a comfortable volume and adjust to taste; no preset guarantees better sound."))
                        Text(L("Your personal presets")).font(.headline).accessibilityAddTraits(.isHeader)
                        Text(L("Load a preset to edit its controls and name, then update it explicitly. To adapt a built-in preset, apply it and save a new personal copy. Built-in presets cannot be renamed, overwritten or deleted."))
                        TextField(L("Name for your preset"), text: $presetName).textFieldStyle(.roundedBorder)
                        Toggle(N("Presetare pentru HomePod", "Préréglage pour HomePod"), isOn: $presetForHomePod)
                        if presetForHomePod {
                            Picker("HomePod", selection: $presetHomePod) {
                                ForEach(HomePodModel.allCases) { Text($0.rawValue).tag($0) }
                            }
                        } else {
                        Picker(N("Modelul presetării", "Modèle du préréglage"), selection: $presetDevice) {
                            ForEach(Device.allCases) { Text(L($0.displayName)).tag($0) }
                        }
                        }
                        Text(N("Presetarea salvată este etichetată cu modelul ales. Reglajele se aplică numai playerului aplicației, la cerere; nu reprezintă o calibrare Apple și nu identifică automat căștile conectate.", "Le préréglage enregistré porte le modèle choisi. Les réglages s’appliquent uniquement au lecteur de l’app, sur demande ; ce n’est pas un étalonnage Apple et les écouteurs connectés ne sont pas identifiés automatiquement."))
                        Button(L("Save current EQ as a new preset")) { audio.savePreset(name: presetName, device: presetForHomePod ? nil : presetDevice, homePod: presetForHomePod ? presetHomePod : nil) }
                        if let id = editingPresetID, let selected = audio.customPresets.first(where: { $0.id == id }) {
                            Text(L("Editing personal preset: {0}", selected.name))
                            Button(L("Update selected personal preset")) { audio.updatePreset(id: id, name: presetName) }
                        }
                        ForEach(audio.customPresets) { preset in
                            if let device = preset.device { Text(L(device.displayName)).font(.caption) }
                            if let homePod = preset.homePod { Text(homePod.rawValue).font(.caption) }
                            ViewThatFits(in: .horizontal) {
                                HStack { savedPresetControls(preset) }
                                VStack(alignment: .leading) { savedPresetControls(preset) }
                            }
                        }
                        if !audio.message.isEmpty { Text(audio.message).font(.callout).textSelection(.enabled) }
                        Text(L("Custom presets include frequency, gain, Q, preamp, headroom and bypass. Player volume is not changed. Applying EQ during an autonomy test changes its comparison conditions."))
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }
                Text(L("EQ control mode")).font(.headline)
                ViewThatFits(in: .horizontal) {
                    HStack { ForEach(EQControlMode.allCases) { modeButton($0) } }
                    VStack(alignment: .leading) { ForEach(EQControlMode.allCases) { modeButton($0) } }
                }.accessibilityElement(children: .contain)
                Text(L(controlMode.help)).font(.callout)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: min(bandMinimumWidth, max(140, availableWidth - 32))), spacing: 16, alignment: .top)], alignment: .leading, spacing: 16) {
                    ForEach(0..<audio.settings.bands.count, id: \.self) { i in
                        GroupBox(L("Band {0}", String(i + 1))) {
                            ViewThatFits(in: .horizontal) {
                                HStack(alignment: .top, spacing: 8) { bandControls(i) }
                                VStack(spacing: 18) { bandControls(i) }
                            }
                            .frame(maxWidth: .infinity, alignment: .topLeading)
                        }
                        .accessibilityElement(children: .contain)
                    }
                }
                Text(L("Frequencies above the audio file’s sample-rate limit are clamped by the processor.")).font(.caption)
                Text(L("Settings are saved locally. Boosting without enough headroom may clip; reduce preamp or enable automatic headroom. No test tones or automatic playback."))
                Divider()
                Button(L("Read current Apple Music title · iPhone")) { audio.readAppleMusic() }
                if !audio.musicTitle.isEmpty {
                    Text(audio.musicTitle).textSelection(.enabled)
                    if let date = audio.musicCheckedAt { Text(L("Metadata checked at {0}", date.formatted(.dateTime.hour().minute().locale(Localization.locale())))) }
                }
                Text(L("This reads Apple Music metadata on request, not audio samples or a universal Now Playing feed. The EQ and meter do not apply to that track."))
                Text(audio.message)
            }.padding()
        }
        .onGeometryChange(for: CGFloat.self) { $0.size.width } action: { availableWidth = $0 }
        .onChange(of: audio.message) { _, text in
            if !text.isEmpty { AccessibilityNotification.Announcement(text).post() }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio]) { result in
            switch result { case .success(let url): audio.load(url); case .failure(let error): audio.message = L("Import failed: {0}", error.localizedDescription) }
        }
    }
    private func modeButton(_ mode: EQControlMode) -> some View {
        Button { controlModeRaw = mode.rawValue } label: {
            Text(L(mode.rawValue)).fixedSize(horizontal: true, vertical: false)
                .padding(.horizontal, 12).frame(minWidth: 72, minHeight: 44)
                .background(controlMode == mode ? Color.accentColor.opacity(0.22) : Color.secondary.opacity(0.10), in: RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(L(mode.rawValue))
        .accessibilityAddTraits(controlMode == mode ? .isSelected : [])
        .accessibilityIdentifier("eq.mode." + mode.rawValue.lowercased())
    }
    @ViewBuilder private var flatAndReset: some View {
        Button(L("Flat · zero band gains")) { audio.settings.flattenBands(); audio.message = L("Flat applied; preamp preserved.") }
        Button(L("Reset EQ · defaults")) { audio.settings = EQSettings(); audio.message = L("EQ defaults restored; saved presets kept.") }
    }
    @ViewBuilder private func savedPresetControls(_ preset: EQPreset) -> some View {
        Button(L("Load preset {0}", preset.name)) { audio.applyPreset(preset); editingPresetID = preset.id; presetName = preset.name }
        Button(L("Delete preset {0}", preset.name), role: .destructive) { audio.removePreset(preset.id); if editingPresetID == preset.id { editingPresetID = nil } }
    }
    @ViewBuilder func bandControls(_ i: Int) -> some View {
        if controlMode.showsFrequency {
            VerticalValue(title: L("Frequency for band {0}", String(i+1)), value: $audio.settings.bands[i].frequency, range: 20...20000, step: 1, unit: "Hz", logarithmic: true)
        }
        VStack {
            if !controlMode.showsFrequency { Text(L("Frequency: {0} Hz", number(audio.settings.bands[i].frequency))).font(.callout).monospacedDigit() }
            VerticalValue(title: L("Gain for band {0}", String(i+1)), value: $audio.settings.bands[i].gain, range: -12...12, step: 0.5, unit: "dB")
        }
        if controlMode.showsQ {
            VerticalValue(title: L("Q for band {0}", String(i+1)), value: $audio.settings.bands[i].q, range: 0.2...10, step: 0.1, unit: "Q")
        }
    }
    func number(_ x: Double) -> String { x.formatted(.number.precision(.fractionLength(1)).locale(Localization.locale())) }
}

/// Parameter graph, deliberately not an acoustic or processor-response measurement.
struct EQBandGraph: View {
    let settings: EQSettings
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(L("EQ band settings graph")).font(.headline)
            Chart(Array(settings.bands.enumerated()), id: \.offset) { index, band in
                RuleMark(x: .value(L("Frequency"), band.frequency), yStart: .value(L("Gain"), 0), yEnd: .value(L("Gain"), band.gain))
                PointMark(x: .value(L("Frequency"), band.frequency), y: .value(L("Gain"), band.gain))
                    .annotation(position: .top) { Text(String(index + 1)).font(.caption.bold()) }
                    .accessibilityLabel(L("Band {0}", String(index + 1)))
                    .accessibilityValue(L("Frequency: {0} Hz", band.frequency.formatted()) + ", " + L("Gain: {0} dB", band.gain.formatted()))
            }.chartXScale(domain: 20.0...20000.0, type: .log)
                .chartYScale(domain: -12.0...12.0)
                .chartXAxisLabel(L("Frequency") + " · Hz").chartYAxisLabel(L("Gain") + " · dB")
                .frame(height: 240)
            Text(L("Markers show band frequency and gain, not measured AirPods response. Q controls band width. The controls below provide exact values."))
            if settings.bypass { Text(L("Bypass EQ")) }
        }
    }
}


/// Real output-buffer amplitude envelope. This is not a spectrum or an EQ response curve.
private struct LiveWaveform: View {
    let samples: [Float]
    let playing: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var showWaveform = true
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(L("Live waveform · this player")).font(.headline)
            Toggle(L("Show live waveform"), isOn: $showWaveform)
            if showWaveform && !reduceMotion {
                Canvas { context, size in
                    let middle = size.height / 2
                    var axis = Path(); axis.move(to: CGPoint(x: 0, y: middle)); axis.addLine(to: CGPoint(x: size.width, y: middle))
                    context.stroke(axis, with: .color(.secondary.opacity(0.5)), lineWidth: 1)
                    guard samples.count >= 2 else { return }
                    var wave = Path()
                    // Each pair is the real min/max in a small bucket; a fixed ±1 digital scale.
                    for index in 0..<(samples.count / 2) {
                        let x = size.width * CGFloat(index) / CGFloat(max(1, samples.count / 2 - 1))
                        let low = CGFloat(min(1, max(-1, samples[index * 2])))
                        let high = CGFloat(min(1, max(-1, samples[index * 2 + 1])))
                        wave.move(to: CGPoint(x: x, y: middle - high * middle))
                        wave.addLine(to: CGPoint(x: x, y: middle - low * middle))
                    }
                    context.stroke(wave, with: .color(.accentColor), lineWidth: 1.5)
                }
                .frame(height: 150)
                .background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                .accessibilityHidden(true)
            }
            Text(L(playing && !samples.isEmpty ? "Real output samples · first channel · amplitude −1 to +1. No microphone or other-app audio is captured." : "No live waveform. Import a file and press Play; pause and stop do not animate simulated audio."))
                .font(.callout)
            if reduceMotion { Text(L("Live drawing is hidden while Reduce Motion is enabled. Numeric output level and playback progress remain available.")).font(.caption) }
        }
        .accessibilityElement(children: .contain)
    }
}

// Hardware controls use only public, capability-checked system interfaces.
#if os(macOS)
import CoreAudio
import AppKit
#else
import AVKit
import UIKit
#endif

@MainActor
final class AudioRoutingControls: ObservableObject {
    struct Port: Identifiable { let id: String; let name: String }
    @Published var inputs: [Port] = []
    @Published var outputs: [Port] = []
    @Published var inputID = ""
    @Published var outputID = ""
    @Published var inputGain: Double = 0
    @Published var outputGain: Double = 0
    @Published var canInputGain = false
    @Published var canOutputGain = false
    @Published var status = ""
    #if os(iOS)
    @Published var inputSession = false
    func enableInput() async {
        let granted = await AVAudioApplication.requestRecordPermission()
        guard granted else { status = N("Accesul la microfon este refuzat.", "Accès au microphone refusé."); return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.allowBluetoothHFP, .allowAirPlay, .defaultToSpeaker])
            try session.setActive(true)
            inputSession = true; refresh()
        } catch { status = error.localizedDescription }
    }
    func endInput() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setActive(false, options: .notifyOthersOnDeactivation)
            try session.setCategory(.playback, mode: .default)
            inputSession = false; refresh()
        } catch { status = error.localizedDescription }
    }
    func refresh() {
        let s = AVAudioSession.sharedInstance()
        inputs = (s.availableInputs ?? []).map { Port(id:$0.uid,name:$0.portName) }
        outputs = s.currentRoute.outputs.map { Port(id:$0.uid,name:$0.portName) }
        inputID = s.currentRoute.inputs.first?.uid ?? ""
        outputID = s.currentRoute.outputs.first?.uid ?? ""
        canInputGain = inputSession && s.isInputGainSettable
        inputGain = Double(s.inputGain); canOutputGain = false
    }
    func selectInput() {
        do {
            let s = AVAudioSession.sharedInstance()
            guard inputSession, let port = s.availableInputs?.first(where: { $0.uid == inputID }) else { refresh(); return }
            try s.setPreferredInput(port)
            refresh() // Display actual route, never the preference as a confirmed selection.
        } catch { status = error.localizedDescription; refresh() }
    }
    func selectOutput() {}
    func setGain(_ value: Double, input: Bool) {
        guard input, canInputGain, value.isFinite, (0...1).contains(value) else { return }
        do { try AVAudioSession.sharedInstance().setInputGain(Float(value)); refresh() }
        catch { status = error.localizedDescription; refresh() }
    }
    #else
    private func address(_ selector: AudioObjectPropertySelector, input: Bool = false) -> AudioObjectPropertyAddress {
        .init(mSelector:selector,mScope:input ? kAudioDevicePropertyScopeInput : kAudioDevicePropertyScopeOutput,mElement:kAudioObjectPropertyElementMain)
    }
    private func defaultDevice(input: Bool) -> AudioDeviceID {
        var a = AudioObjectPropertyAddress(mSelector: input ? kAudioHardwarePropertyDefaultInputDevice : kAudioHardwarePropertyDefaultOutputDevice,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var id: AudioDeviceID = 0; var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        guard AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&a,0,nil,&size,&id) == noErr else { return 0 }; return id
    }
    private func gain(input: Bool) -> (Double,Bool) {
        let id = defaultDevice(input:input)
        var a = address(kAudioDevicePropertyVolumeScalar,input:input)
        var settable = DarwinBoolean(false); var value: Float32 = 0; var size = UInt32(MemoryLayout<Float32>.size)
        guard id != 0, AudioObjectHasProperty(id,&a), AudioObjectGetPropertyData(id,&a,0,nil,&size,&value) == noErr else { return (0,false) }
        let ok = AudioObjectIsPropertySettable(id,&a,&settable) == noErr && settable.boolValue
        return (Double(value),ok)
    }
    func refresh() {
        var a = AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyDevices,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(AudioObjectID(kAudioObjectSystemObject),&a,0,nil,&size) == noErr else { status = N("Lista audio nu este disponibilă.", "Liste audio indisponible."); return }
        guard size >= MemoryLayout<AudioDeviceID>.size else { inputs = []; outputs = []; canInputGain = false; canOutputGain = false; return }
        var ids = [AudioDeviceID](repeating:0,count:Int(size)/MemoryLayout<AudioDeviceID>.size)
        let result = ids.withUnsafeMutableBytes { AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&a,0,nil,&size,$0.baseAddress!) }
        guard result == noErr else { status = "Core Audio: \(result)"; return }
        inputs = []; outputs = []
        for id in ids {
            var nameAddress = AudioObjectPropertyAddress(mSelector:kAudioObjectPropertyName,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
            var name: CFString = "Audio" as CFString; var nameSize = UInt32(MemoryLayout<CFString>.size)
            guard AudioObjectGetPropertyData(id,&nameAddress,0,nil,&nameSize,&name) == noErr else { continue }
            for input in [true,false] {
                var streams = address(kAudioDevicePropertyStreams,input:input); var bytes: UInt32 = 0
                if AudioObjectGetPropertyDataSize(id,&streams,0,nil,&bytes) == noErr && bytes > 0 {
                    let port = Port(id:String(id),name:name as String)
                    if input { inputs.append(port) } else { outputs.append(port) }
                }
            }
        }
        inputID = String(defaultDevice(input:true)); outputID = String(defaultDevice(input:false))
        (inputGain,canInputGain) = gain(input:true); (outputGain,canOutputGain) = gain(input:false)
    }
    private func select(input: Bool) {
        guard var id = AudioDeviceID(input ? inputID : outputID), (input ? inputs : outputs).contains(where: { $0.id == String(id) }) else { refresh(); return }
        var a = AudioObjectPropertyAddress(mSelector:input ? kAudioHardwarePropertyDefaultInputDevice : kAudioHardwarePropertyDefaultOutputDevice,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        let result = AudioObjectSetPropertyData(AudioObjectID(kAudioObjectSystemObject),&a,0,nil,UInt32(MemoryLayout<AudioDeviceID>.size),&id)
        status = result == noErr ? N("Preferința de sistem a fost actualizată.", "Préférence système mise à jour.") : "Core Audio: \(result)"
        refresh()
    }
    func selectInput() { select(input:true) }
    func selectOutput() { select(input:false) }
    func setGain(_ value: Double, input: Bool) {
        guard value.isFinite, (0...1).contains(value), input ? canInputGain : canOutputGain else { return }
        var a = address(kAudioDevicePropertyVolumeScalar,input:input); var level = Float32(value)
        let result = AudioObjectSetPropertyData(defaultDevice(input:input),&a,0,nil,UInt32(MemoryLayout<Float32>.size),&level)
        if result != noErr { status = "Core Audio: \(result)" }; refresh()
    }
    #endif
}

struct AudioRoutingPanel: View {
    @EnvironmentObject var audio: AudioLab
    @StateObject private var routing = AudioRoutingControls()
    @State private var homePodModel = "HomePod (1)"
    var body: some View {
        GroupBox(N("Surse audio · HomePod", "Sources audio · HomePod")) {
            VStack(alignment:.leading,spacing:14) {
                Picker(N("Model HomePod · referință", "Modèle HomePod · référence"),selection:$homePodModel) {
                    ForEach(["HomePod (1)","HomePod (2)","HomePod mini","HomePod mini 2"],id:\.self) { Text($0).tag($0) }
                }
                Text(N("Alegerea modelului este o referință, nu conectează boxa. Folosește ieșirea AirPlay oferită de sistem. Microfoanele HomePod nu sunt expuse aici ca intrare audio și nu au un reglaj de gain disponibil aplicației.", "Le choix du modèle est une référence, sans connexion automatique. Utilisez la sortie AirPlay proposée par le système. Les microphones HomePod ne sont pas exposés ici comme entrée audio et leur gain n’est pas réglable par l’app."))
                Button(N("Reîmprospătează sursele și nivelurile", "Actualiser les sources et niveaux")) { routing.refresh() }
                #if os(iOS)
                Text(N("Ieșire și volum de sistem / AirPlay", "Sortie et volume système / AirPlay")).font(.headline)
                SystemAudioRoutePicker().frame(width:64,height:48).accessibilityLabel(N("Alege ieșirea AirPlay", "Choisir la sortie AirPlay"))
                SystemAudioVolume().frame(height:48)
                Text(routing.outputs.map(\.name).joined(separator:", "))
                if !routing.inputSession {
                    Button(N("Activează selecția microfonului", "Activer la sélection du microphone")) { audio.stop(); Task { await routing.enableInput() } }
                } else {
                    Button(N("Încheie configurarea microfonului", "Terminer la configuration du microphone")) { routing.endInput() }
                }
                Text(N("Configurarea solicită permisiunea microfonului, dar nu înregistrează și nu retransmite vocea. Pornirea playerului revine la modul redare. Selectarea unui microfon Bluetooth poate schimba și ieșirea, calitatea și latența.", "La configuration demande l’autorisation du microphone sans enregistrer ni retransmettre la voix. Le lancement du lecteur rétablit le mode lecture. Choisir un microphone Bluetooth peut modifier la sortie, la qualité et la latence."))
                #else
                Text(N("Aceste reglaje schimbă dispozitivele și volumele implicite ale întregului Mac. Redarea aplicației este oprită înainte de schimbarea sursei.", "Ces réglages changent les appareils et volumes par défaut de tout le Mac. La lecture de l’app est arrêtée avant tout changement de source."))
                Picker(N("Ieșire de sistem", "Sortie système"),selection:$routing.outputID) {
                    Text("—").tag(""); ForEach(routing.outputs) { Text($0.name).tag($0.id) }
                }
                Button(N("Aplică ieșirea", "Appliquer la sortie")) { audio.stop(); routing.selectOutput() }.disabled(routing.outputs.isEmpty)
                if routing.canOutputGain {
                    Slider(value:Binding(get:{routing.outputGain},set:{routing.setGain($0,input:false)}),in:0...1) { Text(N("Volum de ieșire · sistem", "Volume de sortie · système")) }
                        .accessibilityValue("\(Int(routing.outputGain * 100)) %")
                } else { Text(N("Volumul hardware de ieșire nu este reglabil prin acest control. Folosește dispozitivul sau comenzile AirPlay.", "Le volume matériel de sortie n’est pas réglable ici. Utilisez l’appareil ou les commandes AirPlay.")) }
                Button(N("Deschide configurarea Sunet · inclusiv AirPlay", "Ouvrir les réglages Son · dont AirPlay")) {
                    NSWorkspace.shared.open(URL(string:"x-apple.systempreferences:com.apple.preference.sound")!)
                }
                #endif
                Picker(N("Sursă de intrare", "Source d’entrée"),selection:$routing.inputID) {
                    Text("—").tag(""); ForEach(routing.inputs) { Text($0.name).tag($0.id) }
                }
                Button(N("Aplică intrarea", "Appliquer l’entrée")) {
                    #if os(macOS)
                    audio.stop()
                    #endif
                    routing.selectInput()
                }.disabled(routing.inputs.isEmpty)
                if routing.canInputGain {
                    Slider(value:Binding(get:{routing.inputGain},set:{routing.setGain($0,input:true)}),in:0...1) { Text(N("Gain microfon", "Gain du microphone")) }
                        .accessibilityValue("\(Int(routing.inputGain * 100)) %")
                } else { Text(N("Gain-ul microfonului nu este reglabil pe ruta actuală. Nu este afișat un volum simulat.", "Le gain du microphone n’est pas réglable sur la route actuelle. Aucun volume simulé n’est affiché.")) }
                Text(routing.status).textSelection(.enabled)
                Link(N("Apple · identifică HomePod", "Apple · identifier le HomePod"),destination:URL(string:"https://support.apple.com/en-us/101609")!)
            }.frame(maxWidth:.infinity,alignment:.leading)
        }.onAppear { routing.refresh() }
        #if os(iOS)
        .onReceive(NotificationCenter.default.publisher(for:AVAudioSession.routeChangeNotification)) { _ in routing.refresh() }
        .onChange(of:audio.playing) { _, playing in if playing { routing.inputSession = false; routing.refresh() } }
        .onDisappear { if routing.inputSession { routing.endInput() } }
        #endif
    }
}
#if os(iOS)
struct SystemAudioRoutePicker: UIViewRepresentable {
    func makeUIView(context:Context) -> AVRoutePickerView { AVRoutePickerView() }
    func updateUIView(_ view:AVRoutePickerView,context:Context) {}
}
struct SystemAudioVolume: UIViewRepresentable {
    func makeUIView(context:Context) -> MPVolumeView { let v = MPVolumeView(); v.showsRouteButton = false; return v }
    func updateUIView(_ view:MPVolumeView,context:Context) {}
}
#endif
