import SwiftUI
#if canImport(MonitorCore)
import MonitorCore
#endif

/// The visual scale is decorative; VoiceOver gets one adjustable value and explicit buttons.
struct VerticalValue: View {
    let title: String
    @Binding var value: Double
    var range: ClosedRange<Double> = 0...100
    var step: Double = 1
    var unit: String = "%"
    var editable = true
    var logarithmic = false
    var manualStep: Double = 0.01
    @State private var entry = ""
    @State private var invalid = false
    private var formatted: String { value.formatted(.number.grouping(.never).precision(.fractionLength(2)).locale(Localization.locale())) }
    private var fraction: Double {
        let v = min(range.upperBound, max(range.lowerBound, value))
        return logarithmic ? log(v / range.lowerBound) / log(range.upperBound / range.lowerBound) : (v - range.lowerBound) / (range.upperBound - range.lowerBound)
    }
    private func set(_ proposed: Double) {
        guard proposed.isFinite else { return }
        value = min(range.upperBound, max(range.lowerBound, proposed))
    }
    var body: some View {
        VStack(spacing: 10) {
            Text(title).font(.headline).multilineTextAlignment(.center)
            Text("\(formatted) \(unit)").font(.title2.monospacedDigit()).accessibilityHidden(true)
            HStack(spacing: 10) {
                VStack { Text(range.upperBound.formatted()); Spacer(); Text(range.lowerBound.formatted()) }.font(.caption.monospacedDigit()).accessibilityHidden(true)
                GeometryReader { geometry in
                    ZStack(alignment: .bottom) {
                        RoundedRectangle(cornerRadius: 8).fill(Color.secondary.opacity(0.15))
                        RoundedRectangle(cornerRadius: 8).fill(Color.accentColor.opacity(0.65)).frame(height: geometry.size.height * fraction)
                        Path { path in
                            // Twenty divisions: every five percentage points on a 0–100 scale.
                            for index in 0...20 {
                                let y = geometry.size.height * Double(index) / 20
                                path.move(to: CGPoint(x: 0, y: y))
                                path.addLine(to: CGPoint(x: index % 5 == 0 ? 30 : 15, y: y))
                            }
                        }.stroke(Color.primary.opacity(0.65), lineWidth: 1)
                    }.contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 0).onChanged { event in
                        guard editable else { return }
                        let position = min(1, max(0, 1 - event.location.y / geometry.size.height))
                        let raw = logarithmic ? range.lowerBound * pow(range.upperBound / range.lowerBound, position) : range.lowerBound + position * (range.upperBound - range.lowerBound)
                        set((raw / step).rounded() * step)
                    })
                }.frame(width: 50, height: 150)
                .accessibilityRepresentation {
                    if editable {
                        Slider(value: Binding(get: { value }, set: { set($0) }), in: range, step: step)
                            .accessibilityLabel(title)
                            .accessibilityValue("\(formatted) \(unit)")
                            .accessibilityHint(L("Adjust by {0} {1}", String(step), unit))
                            .accessibilityAdjustableAction { direction in
                                switch direction { case .increment: set(value + step); case .decrement: set(value - step); @unknown default: break }
                            }
                    } else {
                        Text(title + ": " + formatted + " " + unit)
                    }
                }
            }
            if editable {
                HStack {
                    Button { set(value - step) } label: { Image(systemName: "minus").frame(minWidth: 44, minHeight: 44) }
                        .accessibilityLabel(L("Decrease {0}", title)).disabled(value <= range.lowerBound)
                    Button { set(value + step) } label: { Image(systemName: "plus").frame(minWidth: 44, minHeight: 44) }
                        .accessibilityLabel(L("Increase {0}", title)).disabled(value >= range.upperBound)
                }
                TextField(L("Exact value for {0}", title), text: $entry).textFieldStyle(.roundedBorder).frame(maxWidth: 180)
                    .onSubmit { commit() }
                Text(L(manualStep == 1 ? "Format 0.00 · whole percentages only" : "Format 0.00 · up to two decimal places")).font(.caption)
                Button(L("Apply exact value")) { commit() }.frame(minHeight: 44)
                if invalid { Text(L("Enter a number within the displayed range.")).foregroundStyle(.red) }
            }
        }.padding(8).frame(minWidth: 140, maxWidth: .infinity)
        .onAppear { entry = formatted }
        .onChange(of: value) { _, _ in entry = formatted; invalid = false }
    }
    private func commit() {
        guard let number = ExactControlInput.parse(entry, locale: Localization.locale(), range: range, step: manualStep) else { invalid = true; AccessibilityNotification.Announcement(L("Enter a number within the displayed range.")).post(); return }
        set(number); entry = formatted; invalid = false
        AccessibilityNotification.Announcement(title + ": " + formatted + " " + unit).post()
    }
}

struct PercentageControl: View {
    let title: String
    @Binding var value: Int
    var range: ClosedRange<Int> = 0...100
    var body: some View {
        VerticalValue(title: title, value: Binding(get: { Double(value) }, set: { value = Int($0.rounded()) }), range: Double(range.lowerBound)...Double(range.upperBound), manualStep: 1)
    }
}

