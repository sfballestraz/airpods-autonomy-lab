import SwiftUI
import WidgetKit
#if os(iOS)
import ActivityKit
#endif

struct BatteryEntry: TimelineEntry {
    var date: Date
    var snapshot: WidgetSnapshot?
}
struct BatteryProvider: TimelineProvider {
    func placeholder(in context: Context) -> BatteryEntry { .init(date: Date(), snapshot: nil) }
    func getSnapshot(in context: Context, completion: @escaping (BatteryEntry) -> Void) { completion(.init(date: Date(), snapshot: SharedSnapshotStore.read())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<BatteryEntry>) -> Void) {
        let now = Date(); let snapshot = SharedSnapshotStore.read()
        var entries = [BatteryEntry(date: now, snapshot: snapshot)]
        if let stale = snapshot?.staleDate, stale > now { entries.append(.init(date: stale, snapshot: snapshot)) }
        completion(Timeline(entries: entries, policy: .after(now.addingTimeInterval(1800))))
    }
}
struct BatteryWidgetCard: View {
    var snapshot: WidgetSnapshot?
    var now: Date
    var showTrack = true
    func w(_ key: String, _ args: String...) -> String { Localization.text(key, arguments: args, language: snapshot?.language) }
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            if let snapshot {
                Text(snapshot.pairName).font(.headline).lineLimit(1)
                Text(w("Last observed · not live")).font(.caption)
                ForEach(snapshot.readings, id: \.component) { reading in
                    HStack {
                        Label(w(reading.component.rawValue), systemImage: reading.component.batterySymbol).font(.caption).lineLimit(1)
                        Spacer()
                        Text("\(reading.level)%").font(.headline.monospacedDigit())
                        if snapshot.lowSeverity(for: reading) != nil { Image(systemName: "exclamationmark.triangle.fill").accessibilityLabel(w("Low at last observation")) }
                        Text(reading.observedAt, style: .time).font(.caption2)
                    }.accessibilityElement(children: .combine)
                }
                if snapshot.readings.contains(where: { $0.stale(at: now) }) { Text(w("Old observation · refresh manually")).font(.caption2).lineLimit(1) }
                if showTrack, let title = snapshot.trackTitle { Text(w("App player: {0}", title)).font(.caption2).lineLimit(1) }
            } else {
                Label("AirPods", systemImage: "earbuds")
                Text(w("Add an observation in the app, then publish it to the widget.")).font(.caption)
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct BatteryWidgetEntryView: View {
    @Environment(\.widgetFamily) private var family
    var entry: BatteryEntry
    var body: some View {
        BatteryWidgetCard(snapshot: entry.snapshot, now: entry.date, showTrack: family != .systemSmall)
            .containerBackground(.background, for: .widget)
            .environment(\.locale, Locale(identifier: entry.snapshot?.language ?? Localization.language()))
    }
}
struct BatteryWidget: Widget {
    let kind = "AirPodsBatteryObservation"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: BatteryProvider()) { entry in
            BatteryWidgetEntryView(entry: entry)
        }.configurationDisplayName(L("AirPods battery observation"))
            .description(L("The selected pair’s last manually observed battery levels, with timestamps."))
            .supportedFamilies([.systemSmall, .systemMedium])
    }
}
#if os(iOS)
struct BatteryLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: MonitorActivityAttributes.self) { context in
            BatteryWidgetCard(snapshot: context.state.snapshot, now: Date()).padding()
                .environment(\.locale, Locale(identifier: context.state.snapshot.language))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) { Label(context.state.snapshot.pairName, systemImage: "earbuds").lineLimit(1) }
                DynamicIslandExpandedRegion(.trailing) { if context.isStale { Image(systemName: "clock.badge.exclamationmark").accessibilityLabel(text("Old observation · refresh manually", context)) } }
                DynamicIslandExpandedRegion(.bottom) {
                    BatteryWidgetCard(snapshot: context.state.snapshot, now: Date())
                        .environment(\.locale, Locale(identifier: context.state.snapshot.language))
                }
            } compactLeading: {
                Image(systemName: context.isStale ? "clock" : (context.state.snapshot.primaryReading?.component.batterySymbol ?? "earbuds")).accessibilityLabel(text("Last observed · not live", context))
            } compactTrailing: {
                if let reading = context.state.snapshot.primaryReading {
                    Text("\(reading.level)%").monospacedDigit()
                        .accessibilityLabel(Localization.text("{0}: {1}% · last observed, not live", arguments: [Localization.text(reading.component.rawValue, language: context.state.snapshot.language), String(reading.level)], language: context.state.snapshot.language))
                } else { Text("—") }
            } minimal: {
                Image(systemName: context.isStale ? "clock" : "battery.100percent").accessibilityLabel(text("Last observed · not live", context))
            }
        }
    }
    func text(_ key: String, _ context: ActivityViewContext<MonitorActivityAttributes>) -> String { Localization.text(key, language: context.state.snapshot.language) }
}
#endif
@main
struct MonitorWidgets: WidgetBundle {
    var body: some Widget {
        BatteryWidget()
        #if os(iOS)
        BatteryLiveActivity()
        #endif
    }
}
