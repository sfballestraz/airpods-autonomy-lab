import Foundation

public struct BatteryObservation: Codable, Identifiable, Hashable, Sendable {
    public var evidence: Evidence?
    public var evidenceLabel: Evidence { evidence ?? .entered }
    public var id: UUID
    public var pairID: UUID
    public var component: Component
    public var level: Int
    public var observedAt: Date
    public var fromTest: Bool
    public init(id: UUID = UUID(), pairID: UUID, component: Component, level: Int, observedAt: Date, fromTest: Bool = false) {
        self.evidence = .entered
        self.id = id; self.pairID = pairID; self.component = component; self.level = level; self.observedAt = observedAt; self.fromTest = fromTest
    }
    public func valid(at now: Date) -> Bool { (0...100).contains(level) && observedAt <= now }
    public func stale(at now: Date) -> Bool { now.timeIntervalSince(observedAt) >= 900 }
}
public extension Archive {
    func latestBattery(pair: AirPodsPair, now: Date = Date()) -> [BatteryObservation] {
        var candidates = observations.filter { $0.pairID == pair.id && $0.valid(at: now) && pair.device.components.contains($0.component) }
        for session in sessions where session.pairID == pair.id && session.validation == nil && session.end <= now {
            candidates += session.samples.map { BatteryObservation(id: session.id, pairID: pair.id, component: $0.component, level: $0.final, observedAt: session.end, fromTest: true) }
        }
        return pair.device.components.compactMap { component in
            candidates.enumerated().filter { $0.element.component == component }.max { a,b in
                let lhs = a.element, rhs = b.element
                if lhs.observedAt != rhs.observedAt { return lhs.observedAt < rhs.observedAt }
                if lhs.fromTest != rhs.fromTest { return lhs.fromTest && !rhs.fromTest }
                return a.offset < b.offset
            }?.element
        }
    }
}
public struct RateResult: Sendable {
    public var session: Session
    public var rate: Double
}
public struct AutonomySummary: Sendable {
    public var first: RateResult
    public var last: RateResult
    public var best: RateResult
    public var mean: Double
    public var count: Int
    public var differenceFromFirst: Double { last.rate - first.rate }
    public var differenceFromBest: Double { last.rate - best.rate }
    /// Negative means less consumption. Undefined for a zero baseline.
    public var percentageChangeFromFirst: Double? { first.rate > 0 ? 100 * differenceFromFirst / first.rate : nil }
    public static func calculate(sessions: [Session], anchor: Session, component: Component, now: Date = Date()) -> Self? {
        guard anchor.comparable, anchor.end <= now else { return nil }
        let results = sessions.filter { $0.end <= now && $0.comparable && $0.sameProtocol(as: anchor) }.compactMap { s -> RateResult? in
            guard let rate = s.samples.first(where: { $0.component == component })?.rate(hours: s.hours), rate.isFinite else { return nil }
            return RateResult(session: s, rate: rate)
        }.sorted { $0.session.end == $1.session.end ? $0.session.id.uuidString < $1.session.id.uuidString : $0.session.end < $1.session.end }
        guard let first = results.first, let last = results.last, let best = results.min(by: { $0.rate < $1.rate }) else { return nil }
        return Self(first: first, last: last, best: best, mean: results.map(\.rate).reduce(0,+) / Double(results.count), count: results.count)
    }
}
public struct EQBand: Codable, Equatable, Sendable {
    public var frequency: Double
    public var gain: Double
    public var q: Double
    public init(frequency: Double, gain: Double = 0, q: Double = 1) { self.frequency = frequency; self.gain = gain; self.q = q }
    public var bandwidth: Double { 2 * asinh(1 / (2 * q)) / log(2) }
}
public struct EQSettings: Codable, Equatable, Sendable {
    public static let frequencies: [Double] = [31.5,63,125,250,500,1000,2000,4000,8000,16000]
    public var bands: [EQBand] = frequencies.map { EQBand(frequency: $0) }
    public var preamp: Double = -6
    public var bypass: Bool = false
    public var automaticHeadroom: Bool = true
    public init() {}
    private enum CodingKeys: String, CodingKey { case bands, preamp, bypass, automaticHeadroom }
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        bands = try c.decode([EQBand].self, forKey: .bands)
        preamp = try c.decode(Double.self, forKey: .preamp)
        bypass = try c.decode(Bool.self, forKey: .bypass)
        automaticHeadroom = try c.decode(Bool.self, forKey: .automaticHeadroom)
        // Retain every legacy filter exactly; extra filters are neutral, not interpolated.
        if bands.count == 5 { bands += [31.5,125,500,2000,8000].map { EQBand(frequency: $0) } }
        guard isValid else { throw DecodingError.dataCorruptedError(forKey: .bands, in: c, debugDescription: "Invalid EQ settings") }
    }
    public var isValid: Bool {
        bands.count == 10 && preamp.isFinite && (-24...0).contains(preamp) && bands.allSatisfy {
            $0.frequency.isFinite && (20...20000).contains($0.frequency) && $0.gain.isFinite && (-12...12).contains($0.gain) && $0.q.isFinite && (0.2...10).contains($0.q)
        }
    }
    public var effectivePreamp: Double { bypass ? 0 : (automaticHeadroom ? min(preamp, -bands.reduce(0) { $0 + max(0, $1.gain) }) : preamp) }
    public func signature(playerGain: Float) -> String { signature + "|gain:" + String(playerGain.bitPattern) }
    public var signature: String {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        return (try? encoder.encode(self).base64EncodedString()) ?? "invalid"
    }
}
public struct WidgetSnapshot: Codable, Hashable, Sendable {
    public var pairName: String
    public var readings: [BatteryObservation]
    public var language: String
    public var publishedAt: Date
    public var trackTitle: String?
    public var earbudAlertThreshold: Int?
    public var caseAlertThreshold: Int?
    public var criticalAlertThreshold: Int?
    public init(pairName: String, readings: [BatteryObservation], language: String, publishedAt: Date = Date(), trackTitle: String? = nil, earbudAlertThreshold: Int? = nil, caseAlertThreshold: Int? = nil, criticalAlertThreshold: Int? = nil) {
        self.pairName = pairName; self.readings = readings; self.language = language; self.publishedAt = publishedAt; self.trackTitle = trackTitle
        self.earbudAlertThreshold = earbudAlertThreshold; self.caseAlertThreshold = caseAlertThreshold; self.criticalAlertThreshold = criticalAlertThreshold
    }
    public var staleDate: Date { readings.map { $0.observedAt.addingTimeInterval(900) }.min() ?? publishedAt }
}
public enum SharedSnapshotStore {
    public static var groupID: String { Bundle.main.object(forInfoDictionaryKey: "AirPodsAppGroup") as? String ?? "group.ch.local.AirPodsMonitor" }
    private static var url: URL? {
        guard !groupID.isEmpty else { return nil }
        return FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: groupID)?.appendingPathComponent("battery-widget.json")
    }
    public static func read() -> WidgetSnapshot? {
        guard let url, let data = try? Data(contentsOf: url) else { return nil }
        guard let snapshot = try? JSONDecoder().decode(WidgetSnapshot.self, from: data), !snapshot.readings.isEmpty, snapshot.readings.allSatisfy({ $0.valid(at: Date()) }) else { return nil }
        return snapshot
    }
    public static func write(_ snapshot: WidgetSnapshot) throws {
        guard let url else { throw CocoaError(.fileNoSuchFile) }
        try JSONEncoder().encode(snapshot).write(to: url, options: .atomic)
    }
}

public enum BatteryAlertSeverity: Int, Codable, Comparable, Sendable {
    case low = 1, critical = 2
    public static func < (lhs: Self, rhs: Self) -> Bool { lhs.rawValue < rhs.rawValue }
}
public struct BatteryAlertPreferences: Codable, Equatable, Sendable {
    public var visualEnabled = true
    public var soundEnabled = true
    public var systemNotifications = false
    public var earbudThreshold = 20
    public var caseThreshold = 20
    public var criticalThreshold = 10
    public init() {}
    public var isValid: Bool { (5...50).contains(earbudThreshold) && (5...50).contains(caseThreshold) && (1...min(earbudThreshold, caseThreshold)).contains(criticalThreshold) }
    public func threshold(for component: Component) -> Int { component == .caseBattery ? caseThreshold : earbudThreshold }
    public func severity(component: Component, level: Int) -> BatteryAlertSeverity? {
        guard (0...100).contains(level), level <= threshold(for: component) else { return nil }
        return level <= min(criticalThreshold, threshold(for: component)) ? .critical : .low
    }
}
public struct BatteryAlertLatch: Codable, Sendable {
    public var observationID: UUID?
    public var observedAt: Date?
    public var severity: BatteryAlertSeverity?
    public var lastAlertAt: Date?
    public init() {}
}
public struct BatteryAlertEvent: Sendable {
    public var reading: BatteryObservation
    public var severity: BatteryAlertSeverity
}
public enum BatteryAlertPolicy {
    public static func key(_ reading: BatteryObservation) -> String { reading.pairID.uuidString + ":" + reading.component.rawValue }
    /// One low alert per discharge episode, with a critical escalation. New episodes require +5 pp recovery.
    public static func evaluate(readings: [BatteryObservation], preferences: BatteryAlertPreferences, latches: inout [String: BatteryAlertLatch], now: Date = Date()) -> [BatteryAlertEvent] {
        guard preferences.isValid else { return [] }
        var events: [BatteryAlertEvent] = []
        for reading in readings where reading.valid(at: now) && !reading.stale(at: now) {
            let key = key(reading); var state = latches[key] ?? BatteryAlertLatch()
            guard state.observationID != reading.id, reading.observedAt >= (state.observedAt ?? .distantPast) else { continue }
            state.observationID = reading.id; state.observedAt = reading.observedAt
            if reading.level >= preferences.threshold(for: reading.component) + 5 { state.severity = nil }
            if let severity = preferences.severity(component: reading.component, level: reading.level), severity > (state.severity ?? .low) || state.severity == nil {
                let escalation = severity == .critical && state.severity == .low
                if escalation || now.timeIntervalSince(state.lastAlertAt ?? .distantPast) >= 600 {
                    events.append(.init(reading: reading, severity: severity)); state.lastAlertAt = now; state.severity = severity
                }
            }
            latches[key] = state
        }
        return events
    }
    /// Loading old history never emits a sound or a notification.
    public static func prime(readings: [BatteryObservation], preferences: BatteryAlertPreferences, latches: inout [String: BatteryAlertLatch]) {
        for reading in readings {
            let key = key(reading); var state = latches[key] ?? BatteryAlertLatch()
            guard state.observationID != reading.id, reading.observedAt >= (state.observedAt ?? .distantPast) else { continue }
            state.observationID = reading.id; state.observedAt = reading.observedAt
            if reading.level >= preferences.threshold(for: reading.component) + 5 { state.severity = nil }
            else if let severity = preferences.severity(component: reading.component, level: reading.level) { state.severity = max(state.severity ?? severity, severity) }
            latches[key] = state
        }
    }
}
public extension Component {
    var batterySymbol: String { self == .caseBattery ? "earbuds.case" : (self == .headphones ? "headphones" : "earbuds") }
}
public extension WidgetSnapshot {
    var primaryReading: BatteryObservation? {
        readings.sorted { lhs, rhs in
            let left = lowSeverity(for: lhs)?.rawValue ?? 0, right = lowSeverity(for: rhs)?.rawValue ?? 0
            if left != right { return left > right }
            if lhs.level != rhs.level { return lhs.level < rhs.level }
            return lhs.component.rawValue < rhs.component.rawValue
        }.first
    }
    func lowSeverity(for reading: BatteryObservation) -> BatteryAlertSeverity? {
        var preferences = BatteryAlertPreferences()
        preferences.earbudThreshold = earbudAlertThreshold ?? 20
        preferences.caseThreshold = caseAlertThreshold ?? 20
        preferences.criticalThreshold = criticalAlertThreshold ?? 10
        return preferences.severity(component: reading.component, level: reading.level)
    }
}

/// Strict localized numeric input; no grouping, suffixes, nonfinite numbers or silent clamping.
public enum ExactControlInput {
    public static func parse(_ text: String, locale: Locale, range: ClosedRange<Double>, step: Double) -> Double? {
        guard step.isFinite, step > 0 else { return nil }
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let separator = locale.decimalSeparator ?? "."
        let escaped = separator == "." ? "\\." : "[" + NSRegularExpression.escapedPattern(for: separator) + ".]"
        guard value.range(of: "^[+-]?[0-9]+(?:" + escaped + "[0-9]{1,2})?$", options: .regularExpression) != nil,
              let number = Double(value.replacingOccurrences(of: separator, with: ".")), number.isFinite,
              range.contains(number), abs(number / step - (number / step).rounded()) < 0.00001 else { return nil }
        return number
    }
}


public enum FirmwareComparison: String, Sendable {
    case unknown, upToDate, updateAvailable, differentOrBeta
    public static func compare(installed: String, official: String, verified: Bool) -> Self {
        func normalized(_ value: String) -> String { value.trimmingCharacters(in: .whitespacesAndNewlines).uppercased() }
        let current = normalized(installed), latest = normalized(official)
        guard verified, !current.isEmpty, !latest.isEmpty else { return .unknown }
        func parts(_ text: String) -> [Int]? {
            if text.range(of: "^[0-9]+[A-Z][0-9]+$", options: .regularExpression) != nil {
                let digits = text.prefix(while: { $0.isNumber })
                let suffix = text.dropFirst(digits.count)
                guard let major = Int(digits), let letter = suffix.first?.asciiValue, let build = Int(suffix.dropFirst()) else { return nil }
                return [major, Int(letter), build]
            }
            if text.range(of: "^[0-9]+(?:\\.[0-9]+){2}$", options: .regularExpression) != nil {
                return text.split(separator: ".").compactMap { Int($0) }
            }
            return nil
        }
        guard let a = parts(current), let b = parts(latest) else { return .differentOrBeta }
        if current == latest { return .upToDate }
        // Never order beta suffixes or compare dotted legacy builds to modern build identifiers.
        guard current.contains(".") == latest.contains(".") else { return .differentOrBeta }
        return a.lexicographicallyPrecedes(b) ? .updateAvailable : .differentOrBeta
    }
}

public enum AppleFirmwarePage {
    public static let url = URL(string: "https://support.apple.com/en-us/106340")!
    public static func modelName(_ device: Device) -> String? {
        switch device {
        case .four: return "AirPods 4"
        case .fourANC: return "AirPods 4 with Active Noise Cancellation"
        case .five: return "AirPods 5"
        case .maria: return "AirPods 5 with Wireless Charging Case"
        case .one: return "AirPods 1"
        case .two: return "AirPods 2"
        case .three: return "AirPods 3"
        case .proOne: return "AirPods Pro 1"
        case .proTwoLightning: return "AirPods Pro 2 with MagSafe Charging Case (Lightning)"
        case .proTwoUSB: return "AirPods Pro 2 with MagSafe Charging Case (USB-C)"
        case .proThree: return "AirPods Pro 3"
        case .maxLightning: return "AirPods Max 1 (Lightning)"
        case .maxUSB: return "AirPods Max 1 (USB-C)"
        case .maxTwo: return "AirPods Max 2"
        case .other: return nil
        }
    }
    /// Exact list-item match. Changed markup, missing models or conflicting entries fail closed.
    public static func version(in html: String, for device: Device) -> String? {
        guard let name = modelName(device), html.utf8.count <= 2_000_000,
              let expression = try? NSRegularExpression(pattern: "<li\\b[^>]*>(.*?)</li>", options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return nil }
        var versions = Set<String>()
        for match in expression.matches(in: html, range: NSRange(html.startIndex..., in: html)) {
            guard let range = Range(match.range(at: 1), in: html) else { continue }
            let text = String(html[range]).replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
                .replacingOccurrences(of: "&nbsp;", with: " ").replacingOccurrences(of: "&#160;", with: " ")
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
            let prefix = name + ":"
            guard text.hasPrefix(prefix) else { continue }
            let candidate = text.dropFirst(prefix.count).trimmingCharacters(in: .whitespacesAndNewlines)
            guard candidate.range(of: "^(?:[0-9]+[A-Z][0-9]+|[0-9]+(?:\\.[0-9]+){2})$", options: .regularExpression) != nil else { continue }
            versions.insert(candidate)
        }
        return versions.count == 1 ? versions.first : nil
    }
}

public enum CoverageRecord: String, Codable, CaseIterable, Sendable {
    case unknown = "Coverage unknown"
    case active = "AppleCare+ active · manual record"
    case inactive = "No active AppleCare+ · manual record"
}
public struct HostLocationMemo: Codable, Equatable, Sendable {
    public var latitude: Double
    public var longitude: Double
    public var accuracy: Double
    public var recordedAt: Date
    public var hostPlatform: String
    public init(latitude: Double, longitude: Double, accuracy: Double, recordedAt: Date, hostPlatform: String) {
        self.latitude = latitude; self.longitude = longitude; self.accuracy = accuracy; self.recordedAt = recordedAt; self.hostPlatform = hostPlatform
    }
    public func valid(at now: Date) -> Bool {
        latitude.isFinite && longitude.isFinite && (-90...90).contains(latitude) && (-180...180).contains(longitude) && accuracy.isFinite && accuracy > 0 && recordedAt <= now.addingTimeInterval(5)
    }
}
public struct PairDetails: Codable, Equatable, Sendable {
    public var primarySerial = ""
    public var leftSerial = ""
    public var rightSerial = ""
    public var caseSerial = ""
    public var coverage: CoverageRecord = .unknown
    public var coverageCheckedAt: Date?
    public var coverageExpiresAt: Date?
    public var location: HostLocationMemo?
    public init() {}
    public var validSerials: Bool {
        [primarySerial, leftSerial, rightSerial, caseSerial].allSatisfy { value in
            value.isEmpty || (value.count <= 40 && value.range(of: "^[A-Z0-9]+$", options: .regularExpression) != nil)
        }
    }
    public mutating func normalizeSerials() {
        primarySerial = primarySerial.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        leftSerial = leftSerial.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        rightSerial = rightSerial.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        caseSerial = caseSerial.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }
}
public enum ObservedLinkState: String, Sendable {
    case unknown = "Connection unknown"
    case connected = "Observed connected"
    case disconnected = "Observed disconnected"
    case otherRoute = "Not the current audio output · connection unconfirmed"
}
public struct DisconnectGuard: Sendable {
    private var armed = false
    private var lastAlertAt: Date?
    public init() {}
    public mutating func observe(_ state: ObservedLinkState, eligibleLoss: Bool, at date: Date) -> Bool {
        if state == .connected { armed = true; return false }
        guard state == .disconnected else { armed = false; return false }
        defer { armed = false }
        guard armed, eligibleLoss, lastAlertAt.map({ date.timeIntervalSince($0) >= 300 }) ?? true else { return false }
        lastAlertAt = date; return true
    }
}
public struct ReceptionSample: Identifiable, Sendable {
    public let id = UUID()
    public let value: Int
    public let date: Date
    public init?(rawRSSI: Int, at date: Date) {
        guard (-127...126).contains(rawRSSI) else { return nil }
        self.value = rawRSSI; self.date = date
    }
}
public extension Device {
    /// Capabilities of Apple's Find My interface, never a promise of third-party control.
    var findMySeparateComponents: Bool { [.fourANC, .maria, .proTwoUSB, .proTwoLightning, .proThree].contains(self) }
    var findMySeparationDocumented: Bool { [.three, .fourANC, .maria, .proOne, .proTwoUSB, .proTwoLightning, .proThree, .maxLightning, .maxUSB, .maxTwo].contains(self) }
}


public enum HomePodModel: String, Codable, CaseIterable, Identifiable, Sendable {
    case original = "HomePod (1)"
    case second = "HomePod (2)"
    case mini = "HomePod mini"
    case miniTwo = "HomePod mini 2"
    public var id: String { rawValue }
}

public struct EQPreset: Codable, Equatable, Identifiable, Sendable {
    public var id: UUID
    public var name: String
    public var settings: EQSettings
    public var device: Device?
    public var homePod: HomePodModel?
    public init(id: UUID = UUID(), name: String, settings: EQSettings, device: Device? = nil, homePod: HomePodModel? = nil) {
        self.id = id; self.name = name.trimmingCharacters(in: .whitespacesAndNewlines); self.settings = settings; self.device = device; self.homePod = homePod
    }
    public var isValid: Bool {
        !(device != nil && homePod != nil) && !name.isEmpty && name.count <= 60 && !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) && settings.isValid
    }
    public static func validLibrary(_ presets: [Self]) -> Bool {
        presets.count <= 50 && presets.allSatisfy(\.isValid) && Set(presets.map(\.id)).count == presets.count && Set(presets.map { $0.name.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "en_US_POSIX")) }).count == presets.count
    }
}
public extension EQPreset {
    static func replacing(in library: [Self], id: UUID, name: String, settings: EQSettings) -> [Self]? {
        guard validLibrary(library), let index = library.firstIndex(where: { $0.id == id }) else { return nil }
        var result = library
        result[index] = Self(id: id, name: name, settings: settings, device: library[index].device, homePod: library[index].homePod)
        return validLibrary(result) ? result : nil
    }
}
public enum BuiltInEQPreset: String, CaseIterable, Identifiable, Sendable {
    case balanced = "Balanced · starting point"
    case bass = "Gentle bass"
    case voice = "Speech clarity"
    case soft = "Softer treble"
    case jazz = "Jazz · gentle"
    case rock = "Rock · gentle"
    case pop = "Pop · gentle"
    case hipHop = "Hip-hop · gentle"
    case electronic = "Electronic · gentle"
    case techno = "Techno · gentle"
    case classical = "Classical · neutral"
    case acoustic = "Acoustic · gentle"
    case soul = "Soul / R&B · gentle"
    case reggae = "Reggae · gentle"
    case latin = "Latin · gentle"
    case ambient = "Ambient · gentle"
    case country = "Country · gentle"
    case metal = "Metal · gentle"
    public var id: String { rawValue }
    public var settings: EQSettings {
        var result = EQSettings()
        let gains: [Double]
        switch self {
        case .balanced: gains = [0, 0, 0, 0, 0]
        case .bass: gains = [2, 1, 0, 0, -1]
        case .voice: gains = [-2, -1, 1, 2, 0]
        case .soft: gains = [0, 0, 0, -2, -3]
        case .jazz: gains = [1, 0, 0, 1, 1]
        case .rock: gains = [1, -1, 1, 2, -1]
        case .pop: gains = [2, 0, 1, 1, 2]
        case .hipHop: gains = [3, 1, 1, 0, -1]
        case .electronic: gains = [2, 0, -1, 1, 2]
        case .techno: gains = [3, 1, -1, 1, 2]
        case .classical: gains = [0, 0, 0, 0, 0]
        case .acoustic: gains = [-1, 0, 1, 1, 0]
        case .soul: gains = [1, 0, 1, 1, 0]
        case .reggae: gains = [2, 1, 0, -1, 0]
        case .latin: gains = [1, -1, 1, 1, 1]
        case .ambient: gains = [1, 0, -1, -1, 0]
        case .country: gains = [0, -1, 1, 1, 1]
        case .metal: gains = [1, -1, 1, 1, -2]
        }
        let anchors: [Double] = [80,250,1000,4000,12000]
        for index in result.bands.indices {
            let f = result.bands[index].frequency
            if f <= anchors[0] { result.bands[index].gain = gains[0] }
            else if f >= anchors[4] { result.bands[index].gain = gains[4] }
            else if let upper = anchors.firstIndex(where: { $0 >= f }) {
                let lower = upper - 1
                let t = log(f / anchors[lower]) / log(anchors[upper] / anchors[lower])
                result.bands[index].gain = gains[lower] + t * (gains[upper] - gains[lower])
            }
        }
        return result
    }
}
public extension EQSettings {
    /// Flat band gains preserve frequency, Q and preamp. Reset uses the complete default settings.
    mutating func flattenBands() {
        for index in bands.indices { bands[index].gain = 0 }
        bypass = false
    }
}


/// Presentation preference only; changing mode never mutates DSP settings or saved presets.
public enum EQControlMode: String, CaseIterable, Identifiable, Sendable {
    case basic = "Basic"
    case advanced = "Advanced"
    case expert = "Expert"
    public var id: String { rawValue }
    public var showsFrequency: Bool { self != .basic }
    public var showsQ: Bool { self == .expert }
    public var help: String {
        switch self {
        case .basic: return "Basic mode: ten vertical gain controls. Existing frequencies and Q remain active; changing mode does not reset them."
        case .advanced: return "Advanced mode: frequency and gain for each band. Existing Q remains active; use Expert to edit it."
        case .expert: return "Expert mode: frequency, gain and Q for every band. All modes use the same ten parametric filters and saved settings."
        }
    }
}


public enum AudioWaveformEnvelope {
    public static func extract(_ samples: UnsafeBufferPointer<Float>, maximumBuckets: Int = 128) -> [Float] {
        guard !samples.isEmpty, (1...1024).contains(maximumBuckets) else { return [] }
        let bucketSize = max(1, (samples.count + maximumBuckets - 1) / maximumBuckets)
        var result: [Float] = []; result.reserveCapacity(min(samples.count, maximumBuckets) * 2)
        for start in stride(from: 0, to: samples.count, by: bucketSize) {
            var low = Float.infinity, high = -Float.infinity
            for i in start..<min(samples.count, start + bucketSize) {
                let sample = samples[i].isFinite ? samples[i] : 0
                low = min(low, sample); high = max(high, sample)
            }
            result.append(low); result.append(high)
        }
        return result
    }
}
