import Foundation

public enum Device: String, Codable, CaseIterable, Identifiable, Sendable {
    // Preserve existing raw values so saved journals remain readable.
    case four = "AirPods 4", maria = "AirPods 5 «Мария»"
    case one = "AirPods 1", two = "AirPods 2", three = "AirPods 3"
    case fourANC = "AirPods 4 cu ANC", five = "AirPods 5 · carcasă USB-C"
    case proOne = "AirPods Pro 1", proTwoLightning = "AirPods Pro 2 · Lightning"
    case proTwoUSB = "AirPods Pro 2 · USB-C", proThree = "AirPods Pro 3"
    case maxLightning = "AirPods Max 1 · Lightning", maxUSB = "AirPods Max 1 · USB-C"
    case maxTwo = "AirPods Max 2", other = "Alt model AirPods / necunoscut"
    public var id: String { rawValue }
    public var displayName: String { self == .maria ? "AirPods 5 · carcasă wireless" : rawValue }
    public var models: String {
        switch self {
        case .four: return "A3050 / A3053 · fără ANC și fără Adaptiv"
        case .maria: return "A3440 / A3439 · carcasă wireless · ANC și Adaptiv"
        case .fourANC: return "A3055 / A3056 · ANC și Adaptiv"
        case .other: return "Model neconfirmat: notează denumirea și numerele modelului în notele testului."
        default: return "Confirmă generația și varianta în Configurări → Bluetooth → informații."
        }
    }
    public var supportsANC: Bool {
        switch self { case .one, .two, .three, .four, .other: return false; default: return true }
    }
    public var supportsAdaptive: Bool {
        switch self { case .fourANC, .maria, .five, .proTwoLightning, .proTwoUSB, .proThree, .maxTwo: return true; default: return false }
    }
    public var isMax: Bool { [.maxLightning, .maxUSB, .maxTwo].contains(self) }
    public var audioModes: [String] {
        if self == .other { return ["Necunoscut", "Oprit", "ANC", "Transparență", "Adaptiv"] }
        return ["Oprit"] + (supportsANC ? ["ANC", "Transparență"] : []) + (supportsAdaptive ? ["Adaptiv"] : [])
    }
    public var components: [Component] { isMax ? [.headphones] : (self == .other ? Component.allCases : [.left, .right, .caseBattery]) }
    public var referenceFirmware: String? {
        switch self { case .four, .fourANC: return "9A348"; case .maria, .five: return "9A350"; default: return nil }
    }
}
public enum Component: String, Codable, CaseIterable, Identifiable, Sendable {
    case left = "Casca stângă", right = "Casca dreaptă", caseBattery = "Carcasă", headphones = "AirPods Max · baterie comună"
    public var id: String { rawValue }
}
public struct BatterySample: Codable, Equatable, Sendable {
    public var component: Component
    public var initial: Int
    public var final: Int
    public init(component: Component, initial: Int, final: Int) { self.component = component; self.initial = initial; self.final = final }
    public func rate(hours: Double) -> Double? {
        guard hours > 0, (0...100).contains(initial), (0...100).contains(final), final <= initial else { return nil }
        return Double(initial - final) / hours
    }
}
public struct LabConditions: Codable, Equatable, Sendable {
    public var contentID: String
    public var temperatureC: Double
    public var route: String
    public var firmwareChannel: String
    public var usage: String
    public init(contentID: String, temperatureC: Double, route: String, firmwareChannel: String, usage: String) {
        self.contentID = contentID; self.temperatureC = temperatureC; self.route = route; self.firmwareChannel = firmwareChannel; self.usage = usage
    }
    public var valid: Bool { !contentID.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && temperatureC.isFinite && (-30...60).contains(temperatureC) && !route.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty && ["stable", "beta", "unknown"].contains(firmwareChannel) && !usage.isEmpty }
}
public struct Session: Codable, Identifiable, Sendable {
    public var conditions: LabConditions?
    public var testContext: TestContext?

    public var id: UUID
    public var device: Device
    public var pairID: UUID?
    public var eqSignature: String?
    public var start: Date
    public var end: Date
    public var volume: Int
    public var mode: String
    public var environment: String
    public var firmware: String
    public var source: String
    public var activity: String
    public var notes: String
    public var interrupted: Bool
    public var samples: [BatterySample]
    public init(id: UUID = UUID(), device: Device, pairID: UUID? = nil, eqSignature: String? = nil, start: Date, end: Date, volume: Int, mode: String, environment: String, firmware: String, source: String, activity: String, notes: String, interrupted: Bool, samples: [BatterySample], conditions: LabConditions? = nil, testContext: TestContext? = nil) {
        self.conditions = conditions; self.testContext = testContext
        self.id = id; self.device = device; self.pairID = pairID; self.eqSignature = eqSignature; self.start = start; self.end = end; self.volume = volume; self.mode = mode; self.environment = environment; self.firmware = firmware; self.source = source; self.activity = activity; self.notes = notes; self.interrupted = interrupted; self.samples = samples
    }
    public var hours: Double { end.timeIntervalSince(start) / 3600 }
    public var validation: String? {
        if let reason = testContext?.validation { return reason }
        guard conditions?.valid != false else { return "Condiții de laborator invalide." }
        guard end > start else { return "Sfârșitul trebuie să fie după început." }
        guard end <= Date() else { return "Sfârșitul testului este în viitor. Păstrează ciorna până când testul se încheie." }
        guard (0...100).contains(volume) else { return "Volumul trebuie să fie între 0 și 100%." }
        guard device.audioModes.contains(mode) else { return "Modul audio nu este disponibil pentru modelul selectat." }
        guard samples.allSatisfy({ device.components.contains($0.component) }) else { return "Componentă incompatibilă cu modelul selectat." }
        guard !samples.isEmpty, Set(samples.map(\.component)).count == samples.count else { return "Alege cel puțin o componentă, fără duplicate." }
        guard samples.allSatisfy({ (0...100).contains($0.initial) && (0...100).contains($0.final) }) else { return "Bateria trebuie să fie între 0 și 100%." }
        guard !firmware.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return "Introdu firmware-ul sau «Necunoscut»." }
        return nil
    }
    public var comparable: Bool { validation == nil && recordedLocation != .mixed && device != .other && mode != "Necunoscut" && !interrupted && samples.allSatisfy { $0.final <= $0.initial } && !["necunoscut", "unknown", "inconnu"].contains(firmware.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()) }
    // Firmware intentionally omitted: compare the same protocol across firmware revisions.
    public func sameProtocol(as other: Session) -> Bool {
        testContext == other.testContext && conditions == other.conditions && pairID == other.pairID && eqSignature == other.eqSignature && device == other.device && volume == other.volume && mode == other.mode && environment == other.environment && source == other.source && activity == other.activity
    }
}
public enum Routine {
    public static func intervals(on date: Date, calendar: Calendar = .current) -> [(Date, Date)] {
        let slots = calendar.isDateInWeekend(date) ? [(13,45,15,0)] : [(7,45,9,30), (13,45,15,0)]
        return slots.compactMap { h,m,eh,em in
            guard let start = calendar.date(bySettingHour: h, minute: m, second: 0, of: date), let end = calendar.date(bySettingHour: eh, minute: em, second: 0, of: date) else { return nil }
            return (start,end)
        }
    }
}
public struct AirPodsPair: Codable, Identifiable, Sendable, Equatable {
    public let id: UUID
    public var name: String
    public var bluetoothID: String?
    public var details: PairDetails?
    public let device: Device
    public init(id: UUID = UUID(), name: String, device: Device, bluetoothID: String? = nil, details: PairDetails? = nil) { self.id = id; self.name = name; self.device = device; self.bluetoothID = bluetoothID; self.details = details }
    public static let initial: [AirPodsPair] = [
        .init(id: UUID(uuidString: "00000000-0000-4000-8000-000000000001")!, name: "AirPods 4", device: .four),
        .init(id: UUID(uuidString: "00000000-0000-4000-8000-000000000002")!, name: "Мария", device: .maria)
    ]
}
public struct Archive: Codable, Sendable {
    public var pairs: [AirPodsPair] = AirPodsPair.initial
    public var observations: [BatteryObservation] = []
    public var sessions: [Session] = []
    public var draft: Session?
    public var settings: [String:String]?
    public init() {}
    private enum CodingKeys: String, CodingKey { case pairs, sessions, draft, observations, settings }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        pairs = try container.decodeIfPresent([AirPodsPair].self, forKey: .pairs) ?? AirPodsPair.initial
        sessions = try container.decodeIfPresent([Session].self, forKey: .sessions) ?? []
        observations = try container.decodeIfPresent([BatteryObservation].self, forKey: .observations) ?? []
        draft = try container.decodeIfPresent(Session.self, forKey: .draft)
        settings = try container.decodeIfPresent([String:String].self,forKey:.settings)
        if let settings { try PortablePreferences.validate(settings) }
        pairs = try ExactDuplicates.rows(pairs).values
        sessions = try ExactDuplicates.rows(sessions).values
        observations = try ExactDuplicates.rows(observations).values
        guard !pairs.isEmpty, Set(pairs.map(\.id)).count == pairs.count else {
            throw DecodingError.dataCorruptedError(forKey: .pairs, in: container, debugDescription: "Lista perechilor este goală sau conține identificatori duplicați.")
        }
        // Old journals only knew the model. Assign each legacy model to one pair.
        for i in sessions.indices { var record = sessions[i]; assignPair(to: &record); sessions[i] = record }
        if var pending = draft { assignPair(to: &pending); draft = pending }
    }
    private mutating func assignPair(to session: inout Session) {
        if let id = session.pairID {
            if !pairs.contains(where: { $0.id == id }) { pairs.append(.init(id: id, name: session.device.displayName + " · recuperat", device: session.device)) }
        } else {
            let pair: AirPodsPair
            if let existing = pairs.first(where: { $0.device == session.device }) { pair = existing }
            else { pair = .init(name: session.device.displayName, device: session.device); pairs.append(pair) }
            session.pairID = pair.id
        }
    }
    public func nameError(_ name: String, excluding id: UUID? = nil) -> String? {
        let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return "Introdu un nume pentru pereche." }
        guard cleaned.count <= 60 else { return "Folosește un nume de cel mult 60 de caractere." }
        guard !pairs.contains(where: { $0.id != id && $0.name.compare(cleaned, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame }) else { return "Acest nume există deja. Alege un nume distinct." }
        return nil
    }
}

// Lab schema is independent of the legacy journal, which remains exportable.
public enum Evidence: String, Codable, CaseIterable, Sendable {
    case measured = "Măsurat", entered = "Introdus", estimated = "Estimat", unavailable = "Indisponibil"
}
public struct DischargeSegment: Codable, Equatable, Sendable {
    public var start: Date
    public var end: Date
    public var initial: Double
    public var final: Double
    public var charging: Bool
    public init(start: Date, end: Date, initial: Double, final: Double, charging: Bool = false) {
        self.start = start; self.end = end; self.initial = initial; self.final = final; self.charging = charging
    }
    public var rate: Double? {
        let hours = end.timeIntervalSince(start) / 3600
        guard hours.isFinite, hours > 0, initial.isFinite, final.isFinite,
              (0...100).contains(initial), (0...100).contains(final), final <= initial, !charging else { return nil }
        return (initial-final)/hours
    }
    public static func weightedRate(_ segments: [Self]) -> Double? {
        let valid = segments.filter { $0.rate != nil }
        guard !valid.isEmpty else { return nil }
        let ordered = valid.sorted { $0.start < $1.start }
        guard zip(ordered, ordered.dropFirst()).allSatisfy({ $0.end <= $1.start }) else { return nil }
        return valid.reduce(0) { $0 + $1.initial - $1.final } / valid.reduce(0) { $0 + $1.end.timeIntervalSince($1.start)/3600 }
    }
    // Empirical range only, not a calibrated confidence interval or battery diagnosis.
    public static func autonomyRange(percent: Double, matchedRates: [Double]) -> ClosedRange<Double>? {
        guard percent.isFinite, (0...100).contains(percent), matchedRates.count >= 3,
              matchedRates.allSatisfy({ $0.isFinite && $0 > 0 }),
              let low = matchedRates.min(), let high = matchedRates.max() else { return nil }
        return percent/high...percent/low
    }
}
public enum LabTransfer {
    public static func decodeArchive(_ data: Data) throws -> Archive {
        guard data.count <= 20_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let archive = try JSONDecoder().decode(Archive.self, from: data)
        guard Set(archive.sessions.map(\.id)).count == archive.sessions.count,
              archive.sessions.allSatisfy({ session in
                  session.validation == nil && archive.pairs.contains { $0.id == session.pairID && $0.device == session.device }
              }),
              Set(archive.observations.map(\.id)).count == archive.observations.count,
              archive.observations.allSatisfy({ observation in
                  observation.valid(at:Date()) && archive.pairs.contains { $0.id == observation.pairID && $0.device.components.contains(observation.component) }
              }) else { throw CocoaError(.fileReadCorruptFile) }
        return archive
    }
    public static func csv(_ archive: Archive) -> String {
        func escape(_ s: String) -> String {
            let safe = ["=", "+", "-", "@"].contains(String(s.prefix(1))) ? "'" + s : s
            return "\"" + safe.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        var rows = ["session_id,pair_id,start,end,firmware,volume,component,initial,final,pp_hour,notes"]
        for s in archive.sessions {
            for b in s.samples {
                rows.append([s.id.uuidString, s.pairID?.uuidString ?? "", ISO8601DateFormatter().string(from:s.start), ISO8601DateFormatter().string(from:s.end), s.firmware, String(s.volume), b.component.rawValue, String(b.initial), String(b.final), b.rate(hours:s.hours).map { String($0) } ?? "", s.notes].map(escape).joined(separator:","))
            }
        }
        return rows.joined(separator:"\n")
    }
}

public extension LabTransfer {
    // Deliberately strict template: no guessing L/R or mapping ambiguous percentages.
    static func csvArchive(_ text: String) throws -> Archive {
        guard text.utf8.count < 20_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let rows = try parseCSV(text)
        let header = ["pair_id","test_id","start","end","firmware","volume","mode","environment","source","activity","component","initial","final","notes"]
        guard rows.first == header else { throw CocoaError(.fileReadCorruptFile) }
        var archive = Archive(); archive.pairs = []; var sessions: [String:Session] = [:]
        let dates = ISO8601DateFormatter()
        for row in rows.dropFirst() {
            guard row.count == header.count, let pair = UUID(uuidString:row[0]), let start = dates.date(from:row[2]), let end = dates.date(from:row[3]), let volume = Int(row[5]), let component = Component(rawValue:row[10]), let initial = Int(row[11]), let final = Int(row[12]), !row[1].isEmpty else { throw CocoaError(.fileReadCorruptFile) }
            // CSV imports require a predefined pair; caller resolves the actual model below.
            let key = row[0] + ":" + row[1]
            let digest = Array(SHA256.hash(data:Data(key.utf8)).prefix(16))
            let stableID = UUID(uuid:(digest[0],digest[1],digest[2],digest[3],digest[4],digest[5],digest[6],digest[7],digest[8],digest[9],digest[10],digest[11],digest[12],digest[13],digest[14],digest[15]))
            var session = sessions[key] ?? Session(id:stableID, device:.other, pairID:pair, start:start, end:end, volume:volume, mode:row[6], environment:row[7], firmware:row[4], source:row[8], activity:row[9], notes:row[1] + " · " + row[13], interrupted:false, samples:[])
            guard session.start == start, session.end == end, session.volume == volume, session.firmware == row[4], session.mode == row[6], session.environment == row[7], session.source == row[8], session.activity == row[9], session.notes == row[1] + " · " + row[13] else { throw CocoaError(.fileReadCorruptFile) }
            session.samples.append(.init(component:component, initial:initial, final:final))
            guard session.validation == nil else { throw CocoaError(.fileReadCorruptFile) }
            sessions[key] = session
        }
        archive.sessions = sessions.values.sorted { $0.start < $1.start }
        return archive
    }
    static func parseCSV(_ text: String) throws -> [[String]] {
        var rows: [[String]] = []; var row: [String] = []; var field = ""
        var quoted = false; var closed = false; let chars = Array(text.replacingOccurrences(of:"\r\n", with:"\n")); var i = 0
        while i < chars.count {
            let c = chars[i]
            if quoted {
                if c == "\"" {
                    if i+1 < chars.count && chars[i+1] == "\"" { field.append("\""); i += 1 }
                    else { quoted = false; closed = true }
                } else { field.append(c) }
            } else if c == "," { row.append(field); field = ""; closed = false }
            else if c == "\n" { row.append(field); rows.append(row); row = []; field = ""; closed = false }
            else if c == "\"" && field.isEmpty && !closed { quoted = true }
            else { guard !closed && c != "\"" else { throw CocoaError(.fileReadCorruptFile) }; field.append(c) }
            i += 1
        }
        guard !quoted else { throw CocoaError(.fileReadCorruptFile) }
        if !row.isEmpty || !field.isEmpty || closed { row.append(field); rows.append(row) }
        return rows
    }
}

import CryptoKit
import CommonCrypto
import Security
public enum ProtectedBackup {
    private struct Envelope: Codable { var format: String; var salt: Data; var sealed: Data }
    private static func key(password: String, salt: Data) throws -> SymmetricKey {
        guard password.count >= 12, password.utf8.count <= 1024, salt.count == 16 else { throw NSError(domain:"AirPodsLab",code:1,userInfo:[NSLocalizedDescriptionKey:"Parola trebuie să aibă 12–1024 caractere / Mot de passe : 12–1024 caractères"]) }
        var derived = Data(count:32)
        let bytes = Array(password.utf8)
        let status = derived.withUnsafeMutableBytes { output in
            salt.withUnsafeBytes { saltBytes in
                bytes.withUnsafeBytes { passBytes in
                    CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), passBytes.baseAddress?.assumingMemoryBound(to:Int8.self), bytes.count, saltBytes.baseAddress?.assumingMemoryBound(to:UInt8.self), salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), 210_000, output.baseAddress?.assumingMemoryBound(to:UInt8.self), 32)
                }
            }
        }
        guard status == kCCSuccess else { throw CocoaError(.fileWriteUnknown) }
        return SymmetricKey(data:derived)
    }
    public static func seal(_ data: Data, password: String) throws -> Data {
        var salt = Data(count:16)
        let result = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault,16,$0.baseAddress!) }
        guard result == errSecSuccess else { throw CocoaError(.fileWriteUnknown) }
        let box = try AES.GCM.seal(data, using:key(password:password,salt:salt))
        guard let combined = box.combined else { throw CocoaError(.fileWriteUnknown) }
        return try JSONEncoder().encode(Envelope(format:"AirPodsLab-AES256GCM-PBKDF2SHA256-210000-v1",salt:salt,sealed:combined))
    }
    public static func open(_ data: Data, password: String) throws -> Data {
        guard data.count <= 30_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let envelope = try JSONDecoder().decode(Envelope.self,from:data)
        guard envelope.format == "AirPodsLab-AES256GCM-PBKDF2SHA256-210000-v1" else { throw CocoaError(.fileReadCorruptFile) }
        return try AES.GCM.open(AES.GCM.SealedBox(combined:envelope.sealed),using:key(password:password,salt:envelope.salt))
    }
    public static func isProtected(_ data: Data) -> Bool { (try? JSONDecoder().decode(Envelope.self,from:data)) != nil }
}

import SwiftData
@Model public final class LabRecord {
    public var id: UUID = UUID()
    public var pairID: UUID = UUID()
    public var timestamp: Date = Date()
    public var kind: String = ""
    public var evidence: String = Evidence.entered.rawValue
    public var source: String = "Manual"
    public var text: String = ""
    public init(pairID: UUID, kind: String, text: String, source: String = "Manual", evidence: Evidence = .entered) {
        self.pairID = pairID; self.kind = kind; self.text = text; self.source = source; self.evidence = evidence.rawValue
    }
}

// Immutable revisions avoid overwriting concurrent snapshots. UUIDs are logical IDs;
// duplicate transport rows are collapsed by revision ID, never by device name.
@Model public final class JournalRevision {
    public var id: UUID = UUID()
    public var timestamp: Date = Date()
    public var payload: Data = Data()
    public var basePayload: Data = Data()
    public init(payload: Data) { self.payload = payload }
}
public enum LabSchemaV1: VersionedSchema {
    public static var versionIdentifier: Schema.Version { .init(1, 0, 0) }
    public static var models: [any PersistentModel.Type] { [LabRecord.self] }
}
public enum LabSchemaV2: VersionedSchema {
    public static var versionIdentifier: Schema.Version { .init(2, 0, 0) }
    public static var models: [any PersistentModel.Type] { [LabRecord.self, JournalRevision.self] }
}
@Model public final class LabAttachment {
    public var id: UUID = UUID()
    public var pairID: UUID = UUID()
    public var sessionID: UUID?
    public var timestamp: Date = Date()
    public var filename: String = ""
    public var contentType: String = "public.data"
    @Attribute(.externalStorage) public var bytes: Data = Data()
    public init(pairID:UUID, filename:String, contentType:String, bytes:Data, sessionID:UUID? = nil) {
        self.pairID = pairID; self.filename = filename; self.contentType = contentType; self.bytes = bytes; self.sessionID = sessionID
    }
}
public enum LabSchemaV3: VersionedSchema {
    public static var versionIdentifier: Schema.Version { .init(3,0,0) }
    public static var models: [any PersistentModel.Type] { [LabRecord.self,JournalRevision.self,LabAttachment.self] }
}
public enum LabMigration: SchemaMigrationPlan {
    public static var schemas: [any VersionedSchema.Type] { [LabSchemaV1.self, LabSchemaV2.self, LabSchemaV3.self] }
    public static var stages: [MigrationStage] { [.lightweight(fromVersion: LabSchemaV1.self, toVersion: LabSchemaV2.self), .lightweight(fromVersion: LabSchemaV2.self, toVersion: LabSchemaV3.self)] }
}
public struct CompleteBackup: Codable, Sendable {
    public var schemaVersion = 4
    public var exportedAt = Date()
    public var timeZone = "Europe/Zurich"
    public var archive: Archive
    public var records: [Record]
    public var revisions: [Revision]
    public var preferences: [String: String]
    public var attachments: [Attachment]?
    public struct Attachment: Codable, Identifiable, Equatable, Sendable {
        public var id: UUID; public var pairID: UUID; public var sessionID: UUID?; public var timestamp: Date; public var filename: String; public var contentType: String; public var bytes: Data
        public init(id:UUID = UUID(), pairID:UUID, sessionID:UUID? = nil, timestamp:Date = Date(), filename:String, contentType:String, bytes:Data) { self.id=id; self.pairID=pairID; self.sessionID=sessionID; self.timestamp=timestamp; self.filename=filename; self.contentType=contentType; self.bytes=bytes }
    }
    public struct Record: Codable, Sendable { public init(id: UUID, pairID: UUID, timestamp: Date, kind: String, evidence: String, source: String, text: String) { self.id=id; self.pairID=pairID; self.timestamp=timestamp; self.kind=kind; self.evidence=evidence; self.source=source; self.text=text }; public var id: UUID; public var pairID: UUID; public var timestamp: Date; public var kind: String; public var evidence: String; public var source: String; public var text: String }
    public struct Revision: Codable, Sendable { public init(id: UUID, timestamp: Date, payload: Data, basePayload: Data = Data()) { self.id=id; self.timestamp=timestamp; self.payload=payload; self.basePayload=basePayload }; public var id: UUID; public var timestamp: Date; public var payload: Data; public var basePayload: Data }
    public init(archive: Archive, records: [Record] = [], revisions: [Revision] = [], preferences: [String:String] = [:], attachments:[Attachment]? = nil) { self.archive = archive; self.records = records; self.revisions = revisions; self.preferences = preferences; self.attachments = attachments }
    public func encoded() throws -> Data {
        let e = JSONEncoder(); e.dateEncodingStrategy = .custom { date, encoder in
            var c = encoder.container(keyedBy: BackupDateKeys.self)
            try c.encode(date.ISO8601Format(), forKey:.utc)
            try c.encode(date.timeIntervalSinceReferenceDate, forKey:.referenceSeconds)
        }; e.outputFormatting = [.sortedKeys]
        let data = try e.encode(self)
        guard data.count <= 100_000_000 else { throw TransferSizeError.limitExceeded }
        return data
    }
    public static func decode(_ data: Data) throws -> Self {
        guard data.count <= 100_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let d = JSONDecoder(); d.dateDecodingStrategy = .custom { decoder in
            let c = try decoder.container(keyedBy: BackupDateKeys.self)
            let seconds = try c.decode(Double.self, forKey:.referenceSeconds)
            let utc = try c.decode(String.self, forKey:.utc)
            guard seconds.isFinite else { throw CocoaError(.fileReadCorruptFile) }
            let date = Date(timeIntervalSinceReferenceDate:seconds)
            guard utc == date.ISO8601Format() else { throw CocoaError(.fileReadCorruptFile) }
            return date
        }
        var b = try d.decode(Self.self, from: data)
        b.records = try ExactDuplicates.rows(b.records).values
        b.revisions = try ExactDuplicates.rows(b.revisions).values
        guard [2,3,4].contains(b.schemaVersion), !b.archive.pairs.isEmpty,
              Set(b.archive.sessions.map(\.id)).count == b.archive.sessions.count,
              Set(b.records.map(\.id)).count == b.records.count,
              b.records.allSatisfy({ r in b.archive.pairs.contains { $0.id == r.pairID } }) else { throw CocoaError(.fileReadCorruptFile) }
        guard Set(b.archive.observations.map(\.id)).count == b.archive.observations.count,
              Set(b.revisions.map(\.id)).count == b.revisions.count,
              b.records.allSatisfy({ Evidence(rawValue:$0.evidence) != nil }),
              b.archive.sessions.allSatisfy({ s in s.pairID.map { id in b.archive.pairs.contains { $0.id == id && $0.device == s.device } } ?? false }),
              b.archive.observations.allSatisfy({ o in b.archive.pairs.contains { $0.id == o.pairID } }) else { throw CocoaError(.fileReadCorruptFile) }
        guard b.archive.sessions.allSatisfy({ $0.validation == nil }),
              b.archive.observations.allSatisfy({ o in o.valid(at:Date()) && b.archive.pairs.contains(where: { $0.id == o.pairID && $0.device.components.contains(o.component) }) }) else { throw CocoaError(.fileReadCorruptFile) }
        // Validate every embedded historical snapshot before touching persistent storage.
        if !b.revisions.isEmpty { _ = try JournalHistory.materialize(b.revisions) }
        let attachments = b.attachments ?? []
        guard attachments.count <= 500, Set(attachments.map(\.id)).count == attachments.count, attachments.reduce(0,{ $0 + $1.bytes.count }) <= 50_000_000,
              attachments.allSatisfy({ a in a.bytes.count <= 10_000_000 && !a.filename.isEmpty && a.filename.count <= 255 && !a.filename.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) && !a.filename.contains("/") && !a.filename.contains("\\") && a.filename != "." && a.filename != ".." && b.archive.pairs.contains(where: { $0.id == a.pairID }) && (a.sessionID == nil || b.archive.sessions.contains(where: { $0.id == a.sessionID && $0.pairID == a.pairID })) }) else { throw CocoaError(.fileReadCorruptFile) }
        b.schemaVersion = 4
        return b
    }
    // One RFC4180 table with a versioned, base64 JSON payload. This is a faithful
    // interchange format, not a flattened analytical spreadsheet.
    public func csv() throws -> Data { Data(("format,schemaVersion,payloadBase64\r\nAirPodsAutonomyLab,\(schemaVersion)," + (try encoded()).base64EncodedString() + "\r\n").utf8) }
    public static func fromCSV(_ data: Data) throws -> Self {
        guard data.count <= 134_000_100 else { throw CocoaError(.fileReadTooLarge) }
        guard let s = String(data:data, encoding:.utf8) else { throw CocoaError(.fileReadCorruptFile) }
        let lines = s.components(separatedBy:"\r\n")
        guard lines.count == 3, lines[0] == "format,schemaVersion,payloadBase64", lines[2].isEmpty else { throw CocoaError(.fileReadCorruptFile) }
        let row = lines[1].split(separator:",", omittingEmptySubsequences:false)
        guard row.count == 3, row[0] == "AirPodsAutonomyLab", ["2","3","4"].contains(String(row[1])), let raw = Data(base64Encoded:String(row[2])) else { throw CocoaError(.fileReadCorruptFile) }
        guard let object = try JSONSerialization.jsonObject(with:raw) as? [String:Any], object["schemaVersion"] as? Int == Int(row[1]) else { throw CocoaError(.fileReadCorruptFile) }
        return try decode(raw)
    }
}

private enum BackupDateKeys: String, CodingKey { case utc, referenceSeconds }

/// Rebuild from immutable history, never from a possibly stale UI snapshot.
/// Conflicts converge by revision order while original alternatives stay recoverable.
public enum JournalHistory {
    public static func materialize(_ revisions: [CompleteBackup.Revision]) throws -> Archive {
        var merged = Archive()
        merged.pairs = []
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        var seen: [UUID: CompleteBackup.Revision] = [:]
        for r in revisions {
            if let old = seen[r.id] {
                guard old.payload == r.payload, old.basePayload == r.basePayload, old.timestamp == r.timestamp else { throw CocoaError(.fileReadCorruptFile) }
            } else { seen[r.id] = r }
        }
        func reconcile<T: Codable & Identifiable>(_ local: inout [T], _ incoming: [T], _ base: [T]) throws where T.ID == UUID {
            guard Set(incoming.map(\.id)).count == incoming.count else { throw CocoaError(.fileReadCorruptFile) }
            let removed = Set(base.map(\.id)).subtracting(incoming.map(\.id))
            local.removeAll { removed.contains($0.id) }
            for item in incoming {
                if let old = base.first(where: { $0.id == item.id }), try encoder.encode(old) == encoder.encode(item) { continue }
                if let i = local.firstIndex(where: { $0.id == item.id }) { local[i] = item }
                else { local.append(item) }
            }
        }
        for revision in seen.values.sorted(by: { $0.timestamp == $1.timestamp ? $0.id.uuidString < $1.id.uuidString : $0.timestamp < $1.timestamp }) {
            let incoming = try JSONDecoder().decode(Archive.self, from:revision.payload)
            let base = revision.basePayload.isEmpty ? nil : try JSONDecoder().decode(Archive.self, from:revision.basePayload)
            try reconcile(&merged.pairs, incoming.pairs, base?.pairs ?? [])
            try reconcile(&merged.sessions, incoming.sessions, base?.sessions ?? [])
            try reconcile(&merged.observations, incoming.observations, base?.observations ?? [])
            if let settings = incoming.settings {
                var current = merged.settings ?? [:]
                for (key,value) in settings where base?.settings?[key] != value { current[key] = value }
                merged.settings = current
            }
            if try encoder.encode(incoming.draft) != encoder.encode(base?.draft) { merged.draft = incoming.draft }
        }
        guard !merged.pairs.isEmpty else { throw CocoaError(.fileReadCorruptFile) }
        return merged
    }
}

public extension CompleteBackup {
    static func boundedData(_ url: URL, limit: Int) throws -> Data {
        let handle = try FileHandle(forReadingFrom:url)
        defer { try? handle.close() }
        var data = Data()
        while let chunk = try handle.read(upToCount:65_536), !chunk.isEmpty {
            guard data.count + chunk.count <= limit else { throw CocoaError(.fileReadTooLarge) }
            data.append(chunk)
        }
        return data
    }
    static func readFile(_ url: URL) throws -> CompleteBackup {
        let csv = url.pathExtension.lowercased() == "csv"
        let zipped = ["xlsx","zip"].contains(url.pathExtension.lowercased())
        let data = try boundedData(url,limit:zipped ? 200_000_000 : (csv ? 134_000_100 : 100_000_000))
        if ["xlsx","zip"].contains(url.pathExtension.lowercased()) { return try fromArchive(data) }
        return try csv ? fromCSV(data) : decode(data)
    }

}

public enum BackupMerge {
    /// UUIDs must never silently change the identity of an existing AirPods model.
    public static func archive(local: Archive, incoming: Archive, overwriteExisting: Bool = true) throws -> Archive {
        guard incoming.pairs.allSatisfy({ p in !local.pairs.contains { $0.id == p.id && $0.device != p.device } }) else { throw BackupMergeError.identityConflict }
        var merged = local
        func upsert<T: Identifiable>(_ rows: inout [T], _ additions: [T]) where T.ID == UUID {
            for row in additions { if let i = rows.firstIndex(where: { $0.id == row.id }) { if overwriteExisting { rows[i] = row } } else { rows.append(row) } }
        }
        upsert(&merged.pairs,incoming.pairs); upsert(&merged.sessions,incoming.sessions); upsert(&merged.observations,incoming.observations)
        if let draft = incoming.draft, overwriteExisting || merged.draft == nil { merged.draft = draft }
        if let settings = incoming.settings { if overwriteExisting { merged.settings = settings } else { merged.settings = (merged.settings ?? [:]).merging(settings) { local,_ in local } } }
        return merged
    }
}

public struct JournalQuality: Sendable {
    public let staleReadings: Int
    public let invalidReadings: Int
    public let incompleteSources: Int
    public let nonComparableSessions: Int
    public let estimatedReadings: Int
    public let hasDraft: Bool
    public init(archive: Archive, now: Date = Date()) {
        let latest = Dictionary(grouping:archive.observations) { "\($0.pairID)/\($0.component.rawValue)" }.values.compactMap { $0.max { $0.observedAt < $1.observedAt } }
        staleReadings = latest.filter { $0.stale(at:now) }.count
        invalidReadings = archive.observations.filter { !$0.valid(at:now) }.count
        incompleteSources = archive.sessions.filter { $0.source.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty }.count
        nonComparableSessions = archive.sessions.filter { !$0.comparable }.count
        estimatedReadings = archive.observations.filter { $0.evidenceLabel == .estimated }.count
        hasDraft = archive.draft != nil
    }
}

public enum BackupVault {
    public struct Entry: Identifiable, Sendable {
        public var id: String { url.lastPathComponent }
        public let url: URL
        public let date: Date
        public let bytes: Int
    }
    public static func entries(in directory: URL) throws -> [Entry] {
        guard FileManager.default.fileExists(atPath:directory.path) else { return [] }
        return try FileManager.default.contentsOfDirectory(at:directory, includingPropertiesForKeys:[.contentModificationDateKey,.fileSizeKey,.isRegularFileKey], options:.skipsHiddenFiles).filter { $0.pathExtension == "json" }.compactMap { url in
            let v = try url.resourceValues(forKeys:[.contentModificationDateKey,.fileSizeKey,.isRegularFileKey])
            guard v.isRegularFile == true else { return nil }
            return Entry(url:url,date:v.contentModificationDate ?? .distantPast,bytes:v.fileSize ?? 0)
        }.sorted { $0.date == $1.date ? $0.id < $1.id : $0.date > $1.date }
    }
    @discardableResult public static func write(_ backup: CompleteBackup, to directory: URL) throws -> URL {
        let data = try backup.encoded()
        _ = try CompleteBackup.decode(data) // Never label an unrestorable file as a valid backup.
        try FileManager.default.createDirectory(at:directory, withIntermediateDirectories:true)
        let url = directory.appending(path:UUID().uuidString + ".json")
        #if os(iOS)
        try data.write(to:url, options:[.atomic,.completeFileProtectionUnlessOpen])
        #else
        try data.write(to:url, options:.atomic)
        #endif
        let hash = SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined()
        try Data(hash.utf8).write(to:url.appendingPathExtension("sha256"), options:.atomic)
        _ = try verified(url)
        return url
    }
    public static func verified(_ url: URL) throws -> CompleteBackup {
        // Bounded read before hashing. A checksum detects accidental damage, not authenticity.
        let data = try CompleteBackup.boundedData(url,limit:100_000_000)
        let backup = try CompleteBackup.decode(data)
        let expectedBytes = try CompleteBackup.boundedData(url.appendingPathExtension("sha256"),limit:64)
        guard expectedBytes.count == 64, let expected = String(data:expectedBytes,encoding:.utf8) else { throw CocoaError(.fileReadCorruptFile) }
        let actual = SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined()
        guard expected == actual else { throw CocoaError(.fileReadCorruptFile) }
        return backup
    }
}

public enum BackupMergeError: LocalizedError {
    case identityConflict
    public var errorDescription: String? { "Același UUID desemnează modele AirPods diferite. / Le même UUID désigne des modèles AirPods différents." }
}

/// Only byte-equivalent encoded values with the same logical UUID are duplicates.
/// Different UUIDs or different payloads are retained, even when names match.
public enum ExactDuplicates {
    public struct Result<T> {
        public let values: [T]
        public let duplicateIndices: [Int]
        public let conflictingIDs: Int
    }
    public static func rows<T: Codable & Identifiable>(_ rows: [T]) throws -> Result<T> where T.ID == UUID {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        var seen: [UUID:Set<Data>] = [:]; var values: [T] = []; var duplicates: [Int] = []
        for (index,row) in rows.enumerated() {
            let bytes = try encoder.encode(row)
            if seen[row.id,default:[]].contains(bytes) { duplicates.append(index) }
            else { seen[row.id,default:[]].insert(bytes); values.append(row) }
        }
        return Result(values:values,duplicateIndices:duplicates,conflictingIDs:seen.values.filter { $0.count > 1 }.count)
    }
    public static func archive(_ archive: Archive) throws -> Archive {
        var output = archive
        output.pairs = try rows(archive.pairs).values
        output.sessions = try rows(archive.sessions).values
        output.observations = try rows(archive.observations).values
        return output
    }
}
extension CompleteBackup.Record: Identifiable {}
extension CompleteBackup.Revision: Identifiable {}

public struct NavigationHistory: Sendable, Equatable {
    public private(set) var pages: [Int] = [0]
    public var current: Int { pages.last ?? 0 }
    public var canGoBack: Bool { pages.count > 1 }
    public init() {}
    public mutating func select(_ page: Int) {
        guard (0..<5).contains(page), page != current else { return }
        pages.append(page)
    }
    public mutating func back() { if canGoBack { pages.removeLast() } }
    public mutating func home() { pages = [0] }
}

public enum PivotDimension: String, CaseIterable, Sendable { case pair, firmware, audioMode, month, location }
public enum PivotMetric: String, CaseIterable, Sendable { case sessions, hours, dischargeRate }
public struct PivotCell: Identifiable, Sendable {
    public var id: String { groupID + "/" + component.rawValue }
    public let groupID: String
    public let groupLabel: String
    public let component: Component
    public let sessionCount: Int
    public let hours: Double
    public let drop: Double
    public let value: Double
}
public struct PivotReport: Sendable {
    public let cells: [PivotCell]
    public let includedSessions: Int
    public let excludedSessions: Int
    public let needsReference: Bool
    public static func build(archive: Archive, dimension: PivotDimension, metric: PivotMetric,
                             pairID: UUID? = nil, channel: String? = nil, since: Date? = nil,
                             referenceID: UUID? = nil, location: TestLocation? = nil) throws -> Self {
        let sessions = try ExactDuplicates.rows(archive.sessions).values
        let ambiguous = Set(Dictionary(grouping:sessions,by: \.id).filter { $0.value.count > 1 }.keys)
        let candidates = sessions.filter { s in
            (location == nil || s.recordedLocation == location) && (pairID == nil || s.pairID == pairID) && (channel == nil || (s.conditions?.firmwareChannel ?? "unknown") == channel) && (since.map { s.start >= $0 } ?? true)
        }
        let reference = sessions.first { $0.id == referenceID && $0.comparable && !ambiguous.contains($0.id) }
        if metric == .dischargeRate && reference == nil { return .init(cells:[],includedSessions:0,excludedSessions:candidates.count,needsReference:true) }
        let included = candidates.filter { s in
            guard !ambiguous.contains(s.id), s.validation == nil, s.hours.isFinite else { return false }
            if metric == .dischargeRate, let reference { return s.comparable && s.sameProtocol(as:reference) }
            return true
        }
        struct Key: Hashable { var id: String; var label: String; var component: Component }
        struct Aggregate { var n = 0; var hours = 0.0; var drop = 0.0 }
        var buckets: [Key:Aggregate] = [:]
        var calendar = Calendar(identifier:.gregorian); calendar.timeZone = TimeZone(identifier:"Europe/Zurich")!
        for s in included {
            let label: String; let id: String
            switch dimension {
            case .pair:
                id = s.pairID?.uuidString ?? "unknown"
                label = archive.pairs.first { $0.id == s.pairID }?.name ?? s.device.displayName
            case .firmware:
                let channel = s.conditions?.firmwareChannel ?? "unknown"
                id = s.firmware + "/" + channel; label = s.firmware + " · " + channel
            case .location: id = s.recordedLocation.rawValue; label = s.recordedLocation.title(language:Localization.language())
            case .audioMode: id = s.mode; label = s.mode
            case .month:
                let c = calendar.dateComponents([.year,.month],from:s.start)
                id = String(format:"%04d-%02d",c.year ?? 0,c.month ?? 0); label = id
            }
            for sample in s.samples {
                if metric == .dischargeRate && sample.rate(hours:s.hours) == nil { continue }
                let key = Key(id:id,label:label,component:sample.component)
                var b = buckets[key] ?? Aggregate(); b.n += 1; b.hours += s.hours; b.drop += Double(sample.initial - sample.final); buckets[key] = b
            }
        }
        var cells: [PivotCell] = []
        for (key,bucket) in buckets {
            var value = Double(bucket.n)
            if metric == .hours { value = bucket.hours }
            if metric == .dischargeRate { value = bucket.drop / bucket.hours }
            let cell = PivotCell(groupID:key.id,groupLabel:key.label,component:key.component,sessionCount:bucket.n,hours:bucket.hours,drop:bucket.drop,value:value)
            cells.append(cell)
        }
        cells.sort { left,right in
            if left.groupID == right.groupID { return left.component.rawValue < right.component.rawValue }
            return left.groupID < right.groupID
        }
        return .init(cells:cells,includedSessions:included.count,excludedSessions:candidates.count - included.count,needsReference:false)
    }
}

public enum TestLocation: String, Codable, CaseIterable, Sendable {
    case quietIndoor, home, office, restaurant, train, bus, boat, tram, metro, airplane, carPassenger, outdoors, transport, mixed, other, unknown
    public var legacyValue: String { title(language:"ro") }
    public func title(language: String) -> String {
        let names: [TestLocation:[String]] = [
            .quietIndoor:["Interior liniștit","Intérieur calme","Quiet indoors"], .home:["Acasă","À la maison","Home"],
            .office:["Birou","Bureau","Office"], .restaurant:["Restaurant / cafenea","Restaurant / café","Restaurant / café"],
            .train:["Tren","Train","Train"], .bus:["Autobuz","Bus","Bus"], .boat:["Vapor / feribot","Bateau / ferry","Boat / ferry"],
            .tram:["Tramvai","Tramway","Tram"], .metro:["Metrou","Métro","Metro"], .airplane:["Avion","Avion","Airplane"],
            .carPassenger:["Mașină · pasager","Voiture · passager","Car · passenger"], .outdoors:["Exterior","Extérieur","Outdoors"],
            .transport:["Transport","Transport non précisé","Unspecified transport"], .mixed:["Mixt · mai multe locuri","Mixte · plusieurs lieux","Mixed · several places"],
            .other:["Alt loc","Autre lieu","Other place"], .unknown:["Loc necunoscut","Lieu inconnu","Unknown place"]]
        return names[self]![language == "fr" ? 1 : language == "en" ? 2 : 0]
    }
    public static func fromLegacy(_ text: String) -> Self {
        let normalized = text.trimmingCharacters(in:.whitespacesAndNewlines).folding(options:[.caseInsensitive,.diacriticInsensitive],locale:Locale(identifier:"en_US_POSIX"))
        if ["mixt","mixte","mixed"].contains(normalized) { return .mixed }
        for location in allCases {
            for language in ["ro","fr","en"] {
                if location.title(language:language).folding(options:[.caseInsensitive,.diacriticInsensitive],locale:Locale(identifier:"en_US_POSIX")) == normalized { return location }
            }
        }
        return .unknown // Never guess a train from the generic old label Transport.
    }
}
public enum DeclaredNoise: String, Codable, CaseIterable, Sendable {
    case unknown, quiet, moderate, loud
    public func title(language: String) -> String {
        let names: [DeclaredNoise:[String]] = [.unknown:["Necunoscut","Inconnu","Unknown"],.quiet:["Liniștit","Calme","Quiet"],.moderate:["Moderat","Modéré","Moderate"],.loud:["Zgomotos","Bruyant","Loud"]]
        return names[self]![language == "fr" ? 1 : language == "en" ? 2 : 0]
    }
}
public struct TestContext: Codable, Equatable, Sendable {
    public var location: TestLocation
    public var noise: DeclaredNoise
    public var details: String
    public init(location: TestLocation, noise: DeclaredNoise = .unknown, details: String = "") { self.location=location; self.noise=noise; self.details=details }
    public var validation: String? {
        if details.count > 300 { return "Detaliile locului pot avea maximum 300 de caractere. / Les détails du lieu sont limités à 300 caractères." }
        if [.mixed,.other].contains(location), details.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty { return "Descrie locul sau traseul mixt. / Décrivez le lieu ou le trajet mixte." }
        return nil
    }
}
public extension Session {
    var recordedLocation: TestLocation { testContext?.location ?? TestLocation.fromLegacy(environment) }
}

/// Explicit allowlist: never restore permissions, account credentials, paths or hardware volume.
public enum PortablePreferences {
    public static let dataKeys = ["parametricEQ","customEQPresets","batteryAlertPreferences"]
    public static func capture(_ defaults: UserDefaults = .standard) -> [String:String] {
        var values = ["appLanguage":defaults.string(forKey:"appLanguage") ?? "system"]
        let encoder = JSONEncoder()
        let initialData: [String:Data] = ["parametricEQ":(try? encoder.encode(EQSettings())) ?? Data(),"customEQPresets":(try? encoder.encode([EQPreset]())) ?? Data(),"batteryAlertPreferences":(try? encoder.encode(BatteryAlertPreferences())) ?? Data()]
        for key in dataKeys { values[key] = (defaults.data(forKey:key) ?? initialData[key] ?? Data()).base64EncodedString() }
        values["playerVolume"] = String((defaults.object(forKey:"playerVolume") as? Double) ?? 0.25)
        values["eqControlMode"] = defaults.string(forKey:"eqControlMode") ?? EQControlMode.expert.rawValue
        if let pair = defaults.string(forKey:"selectedPairID") { values["selectedPairID"] = pair }
        values["firmwareSilentNotifications"] = defaults.bool(forKey:"firmwareSilentNotifications") ? "true" : "false"
        return values
    }
    public static func validate(_ values: [String:String]) throws {
        let decoder = JSONDecoder()
        for (key,value) in values {
            switch key {
            case "selectedPairID": guard UUID(uuidString:value) != nil else { throw CocoaError(.fileReadCorruptFile) }
            case "playerVolume": guard let v = Double(value), v.isFinite, (0...1).contains(v) else { throw CocoaError(.fileReadCorruptFile) }
            case "appLanguage": guard ["ro","fr","en","system"].contains(value) else { throw CocoaError(.fileReadCorruptFile) }
            case "eqControlMode": guard EQControlMode(rawValue:value) != nil else { throw CocoaError(.fileReadCorruptFile) }
            case "firmwareSilentNotifications": guard ["true","false"].contains(value) else { throw CocoaError(.fileReadCorruptFile) }
            case "parametricEQ":
                guard let data = Data(base64Encoded:value), data.count < 100_000, try decoder.decode(EQSettings.self,from:data).isValid else { throw CocoaError(.fileReadCorruptFile) }
            case "customEQPresets":
                guard let data = Data(base64Encoded:value), data.count < 2_000_000, try EQPreset.validLibrary(decoder.decode([EQPreset].self,from:data)) else { throw CocoaError(.fileReadCorruptFile) }
            case "batteryAlertPreferences":
                guard let data = Data(base64Encoded:value), data.count < 100_000, try decoder.decode(BatteryAlertPreferences.self,from:data).isValid else { throw CocoaError(.fileReadCorruptFile) }
            default: throw CocoaError(.fileReadCorruptFile)
            }
        }
    }
    public static func apply(_ values: [String:String], to defaults: UserDefaults = .standard) throws {
        try validate(values)
        for (key,value) in values {
            if key == "playerVolume" { defaults.set(Double(value),forKey:key) }
            else if dataKeys.contains(key) { defaults.set(Data(base64Encoded:value),forKey:key) }
            else if key == "firmwareSilentNotifications" { defaults.set(value == "true",forKey:key) }
            else { defaults.set(value,forKey:key) }
        }
        NotificationCenter.default.post(name:Notification.Name("AirPodsPortableSettingsRestored"),object:nil)
    }
}

public struct ImportDifference: Identifiable, Sendable {
    public let id: String
    public let category: String
    public let local: String
    public let incoming: String
    public var fields: [ImportFieldDifference] = []
}
public extension CompleteBackup {
    func differences(from local: CompleteBackup) throws -> [ImportDifference] {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys,.prettyPrinted]; encoder.dateEncodingStrategy = .iso8601
        func compare<T: Codable & Identifiable>(_ a:[T],_ b:[T],_ kind:String) throws -> [ImportDifference] where T.ID == UUID {
            try b.compactMap { incoming in
                guard let old = a.first(where: { $0.id == incoming.id }) else { return .init(id:kind+incoming.id.uuidString,category:kind,local:"—",incoming:String(decoding:try encoder.encode(incoming),as:UTF8.self)) }
                let oldData = try encoder.encode(old), newData = try encoder.encode(incoming)
                guard oldData != newData else { return nil }
                return .init(id:kind+incoming.id.uuidString,category:kind,local:String(decoding:oldData,as:UTF8.self),incoming:String(decoding:newData,as:UTF8.self),fields:try FieldReconciliation.differences(old,incoming))
            }
        }
        var rows = try compare(local.archive.pairs,archive.pairs,"Device")
        rows += try compare(local.archive.sessions,archive.sessions,"Session")
        rows += try compare(local.archive.observations,archive.observations,"Battery")
        rows += try compare(local.records,records,"Lab")
        rows += try compare(local.attachments ?? [],attachments ?? [],"Attachment")
        func preferenceText(_ key:String,_ value:String?) -> String {
            guard let value else { return "—" }
            if PortablePreferences.dataKeys.contains(key), let bytes = Data(base64Encoded:value), let object = try? JSONSerialization.jsonObject(with:bytes), let pretty = try? JSONSerialization.data(withJSONObject:object,options:[.prettyPrinted,.sortedKeys,.fragmentsAllowed]) { return String(decoding:pretty,as:UTF8.self) }
            return value
        }
        for key in Set(preferences.keys).union(local.preferences.keys).sorted() where preferences[key] != local.preferences[key] {
            rows.append(.init(id:"Preference/"+key,category:"Preference: "+key,local:preferenceText(key,local.preferences[key]),incoming:preferenceText(key,preferences[key])))
        }
        return rows
    }
}

/// Bounded ZIP32 with stored entries. No executable content, paths, compression bombs or extraction to disk.
/// XLSX files edited/recompressed by another application use JSON as the faithful import intermediary.
public enum StoredArchive {
    public static func crc32(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xffffffff
        for byte in data { crc ^= UInt32(byte); for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xedb88320 : 0) } }
        return crc ^ 0xffffffff
    }
    public static func encode(_ entries: [(String,Data)]) throws -> Data {
        guard entries.count <= 1000, Set(entries.map(\.0)).count == entries.count else { throw CocoaError(.fileWriteUnknown) }
        var out = Data(), central = Data()
        func put(_ value: UInt32, bytes: Int, into data: inout Data) { for i in 0..<bytes { data.append(UInt8(truncatingIfNeeded:value >> (8*i))) } }
        for (name,data) in entries {
            let nameData = Data(name.utf8)
            guard !name.hasPrefix("/"), !name.split(separator:"/").contains(".."), nameData.count < 65536, data.count <= 100_000_000, out.count + data.count < 200_000_000 else { throw CocoaError(.fileWriteOutOfSpace) }
            let offset = UInt32(out.count), crc = crc32(data), count = UInt32(data.count)
            put(0x04034b50,bytes:4,into:&out); put(20,bytes:2,into:&out); put(0x800,bytes:2,into:&out)
            put(0,bytes:2,into:&out); put(0,bytes:2,into:&out); put(33,bytes:2,into:&out)
            put(crc,bytes:4,into:&out); put(count,bytes:4,into:&out); put(count,bytes:4,into:&out)
            put(UInt32(nameData.count),bytes:2,into:&out); put(0,bytes:2,into:&out); out.append(nameData); out.append(data)
            put(0x02014b50,bytes:4,into:&central); put(20,bytes:2,into:&central); put(20,bytes:2,into:&central)
            put(0x800,bytes:2,into:&central); put(0,bytes:2,into:&central); put(0,bytes:2,into:&central); put(33,bytes:2,into:&central)
            put(crc,bytes:4,into:&central); put(count,bytes:4,into:&central); put(count,bytes:4,into:&central)
            put(UInt32(nameData.count),bytes:2,into:&central)
            for _ in 0..<4 { put(0,bytes:2,into:&central) }
            put(0,bytes:4,into:&central); put(offset,bytes:4,into:&central); central.append(nameData)
        }
        let offset = UInt32(out.count); out.append(central)
        put(0x06054b50,bytes:4,into:&out); put(0,bytes:2,into:&out); put(0,bytes:2,into:&out)
        put(UInt32(entries.count),bytes:2,into:&out); put(UInt32(entries.count),bytes:2,into:&out)
        put(UInt32(central.count),bytes:4,into:&out); put(offset,bytes:4,into:&out); put(0,bytes:2,into:&out)
        guard out.count <= 200_000_000 else { throw TransferSizeError.limitExceeded }
        return out
    }
    public static func decode(_ data: Data) throws -> [String:Data] {
        guard data.count <= 200_000_000 else { throw CocoaError(.fileReadTooLarge) }
        let bytes = [UInt8](data)
        func get(_ offset:Int,_ count:Int) throws -> Int {
            guard offset >= 0, count <= 4, offset + count <= bytes.count else { throw CocoaError(.fileReadCorruptFile) }
            return (0..<count).reduce(0) { $0 | Int(bytes[offset+$1]) << (8*$1) }
        }
        guard bytes.count >= 22, try get(bytes.count-22,4) == 0x06054b50 else { throw CocoaError(.fileReadCorruptFile) }
        let total = try get(bytes.count-12,2)
        guard total <= 1000, try get(bytes.count-14,2) == total, try get(bytes.count-18,2) == 0, try get(bytes.count-16,2) == 0 else { throw CocoaError(.fileReadCorruptFile) }
        var cursor = 0; var entries: [String:Data] = [:]
        for _ in 0..<total {
            guard try get(cursor,4) == 0x04034b50, try get(cursor+6,2) == 0x800, try get(cursor+8,2) == 0 else { throw CocoaError(.fileReadCorruptFile) }
            let count = try get(cursor+18,4), nameCount = try get(cursor+26,2), extra = try get(cursor+28,2)
            guard count <= 100_000_000, count == (try get(cursor+22,4)), extra == 0, cursor+30+nameCount+count <= bytes.count else { throw CocoaError(.fileReadCorruptFile) }
            let start = cursor+30
            guard let name = String(bytes:bytes[start..<start+nameCount],encoding:.utf8), !name.hasPrefix("/"), !name.contains("\\"), !name.split(separator:"/").contains(".."), entries[name] == nil else { throw CocoaError(.fileReadCorruptFile) }
            let payload = Data(bytes[(start+nameCount)..<(start+nameCount+count)])
            guard Int(crc32(payload)) == (try get(cursor+14,4)) else { throw CocoaError(.fileReadCorruptFile) }
            entries[name] = payload; cursor = start+nameCount+count
        }
        let centralOffset = try get(bytes.count-6,4), centralSize = try get(bytes.count-10,4)
        guard cursor == centralOffset, centralOffset + centralSize == bytes.count-22 else { throw CocoaError(.fileReadCorruptFile) }
        // Validate central-directory names, sizes, CRCs and offsets against the physical entries.
        var seen = Set<String>()
        for _ in 0..<total {
            guard try get(cursor,4) == 0x02014b50 else { throw CocoaError(.fileReadCorruptFile) }
            let n = try get(cursor+28,2), extra = try get(cursor+30,2), comment = try get(cursor+32,2)
            guard cursor+46+n+extra+comment <= bytes.count-22, let name = String(bytes:bytes[cursor+46..<cursor+46+n],encoding:.utf8), let payload = entries[name], seen.insert(name).inserted,
                  try get(cursor+20,4) == payload.count, try get(cursor+24,4) == payload.count, try get(cursor+16,4) == Int(crc32(payload)), try get(cursor+10,2) == 0 else { throw CocoaError(.fileReadCorruptFile) }
            let localOffset = try get(cursor+42,4)
            guard localOffset >= 0, localOffset+30+n <= centralOffset, try get(localOffset,4) == 0x04034b50, try get(localOffset+26,2) == n,
                  Data(bytes[(localOffset+30)..<(localOffset+30+n)]) == Data(name.utf8) else { throw CocoaError(.fileReadCorruptFile) }
            cursor += 46+n+extra+comment
        }
        guard cursor == bytes.count-22 else { throw CocoaError(.fileReadCorruptFile) }
        return entries
    }
}

public extension CompleteBackup {
    /// Human-readable sheets, with nested metadata preserved as JSON columns and a faithful JSON backup entry.
    func analysisTables() throws -> [(String,[[String]])] {
        let root = try JSONSerialization.jsonObject(with:encoded()) as! [String:Any]
        let archiveObject = root["archive"] as! [String:Any]
        func table(_ object:Any?) throws -> [[String]] {
            func flatten(_ source:[String:Any], prefix:String = "") -> [String:Any] {
                var result: [String:Any] = [:]
                for (key,value) in source {
                    let name = prefix.isEmpty ? key : prefix+"."+key
                    if let child = value as? [String:Any] { result.merge(flatten(child,prefix:name)) { _,new in new } }
                    else { result[name] = value }
                }
                return result
            }
            let rows = (object as? [[String:Any]] ?? []).map { flatten($0) }
            let keys = Set(rows.flatMap { $0.keys }).sorted()
            func text(_ value:Any?) throws -> String {
                guard let value else { return "" }
                if let s = value as? String { return s }
                if let n = value as? NSNumber { return n.stringValue }
                return String(decoding:try JSONSerialization.data(withJSONObject:value,options:[.sortedKeys,.fragmentsAllowed]),as:UTF8.self)
            }
            return [keys] + (try rows.map { row in try keys.map { try text(row[$0]) } })
        }
        var samples: [[String:Any]] = []
        for session in archiveObject["sessions"] as? [[String:Any]] ?? [] {
            for sample in session["samples"] as? [[String:Any]] ?? [] {
                var row = sample; row["sessionID"] = session["id"]; row["pairID"] = session["pairID"]; row["firmware"] = session["firmware"]; row["start"] = session["start"]; row["end"] = session["end"]
                samples.append(row)
            }
        }
        let attachmentRows: [[String:Any]] = (attachments ?? []).map { a in ["id":a.id.uuidString,"pairID":a.pairID.uuidString,"sessionID":a.sessionID?.uuidString ?? "","timestampUTC":a.timestamp.ISO8601Format(),"filename":a.filename,"contentType":a.contentType,"bytes":a.bytes.count] }
        return try [("Devices",table(archiveObject["pairs"])),("Sessions",table(archiveObject["sessions"])),("Samples",table(samples)),("Battery",table(archiveObject["observations"])),("Lab",table(root["records"])),("Attachments",table(attachmentRows)),("Preferences",[["key","value"]] + preferences.sorted { $0.key < $1.key }.map { [$0.key,$0.value] }), ("Metadata",[["schemaVersion","exportedAtUTC","timeZone"],[String(schemaVersion),exportedAt.ISO8601Format(),timeZone]])]
    }
    func csvTablesArchive() throws -> Data {
        var entries = try analysisTables().map { name,rows -> (String,Data) in
            let csv = rows.map { $0.map { value in
                let first = value.trimmingCharacters(in:.whitespacesAndNewlines).first
                let safe = first.map { "=+-@".contains($0) } == true ? "'" + value : value
                return "\"" + safe.replacingOccurrences(of:"\"",with:"\"\"") + "\""
            }.joined(separator:",") }.joined(separator:"\r\n") + "\r\n"
            return (name+".csv",Data(csv.utf8))
        }
        entries.append(("backup.json",try encoded()))
        for a in attachments ?? [] { entries.append(("attachments/"+a.id.uuidString+"/"+a.filename,a.bytes)) }
        return try StoredArchive.encode(entries)
    }
    func xlsx() throws -> Data {
        let tables = try analysisTables()
        func xml(_ s:String) -> String {
            String(s.unicodeScalars.filter { $0.value == 9 || $0.value == 10 || $0.value == 13 || ($0.value >= 32 && $0.value != 0xfffe && $0.value != 0xffff) }.map(Character.init))
                .replacingOccurrences(of:"&",with:"&amp;").replacingOccurrences(of:"<",with:"&lt;").replacingOccurrences(of:">",with:"&gt;").replacingOccurrences(of:"\"",with:"&quot;")
        }
        func column(_ index:Int) -> String { var n = index+1; var s = ""; while n > 0 { n -= 1; s = String(UnicodeScalar(65+n%26)!) + s; n /= 26 }; return s }
        var entries: [(String,Data)] = []
        var sheets = "", relations = "", types = ""
        for (i,table) in tables.enumerated() {
            let id = i+1
            sheets += "<sheet name=\"\(xml(table.0))\" sheetId=\"\(id)\" r:id=\"rId\(id)\"/>"
            relations += "<Relationship Id=\"rId\(id)\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet\(id).xml\"/>"
            types += "<Override PartName=\"/xl/worksheets/sheet\(id).xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            var rows = ""
            for (r,cells) in table.1.enumerated() {
                rows += "<row r=\"\(r+1)\">"
                for (c,text) in cells.enumerated() {
                    // Excel cells are bounded; full untruncated values remain in backup.json.
                    if text.count < 16, text.range(of:"^-?[0-9]+(\\.[0-9]+)?$",options:.regularExpression) != nil, let n = Double(text), n.isFinite {
                        rows += "<c r=\"\(column(c))\(r+1)\" t=\"n\"><v>\(text)</v></c>"
                    } else {
                        rows += "<c r=\"\(column(c))\(r+1)\" t=\"inlineStr\"><is><t xml:space=\"preserve\">\(xml(String(text.prefix(32000))))</t></is></c>"
                    }
                }
                rows += "</row>"
            }
            guard table.1.count <= 1_048_576 else { throw CocoaError(.fileWriteOutOfSpace) }
            entries.append(("xl/worksheets/sheet\(id).xml",Data(("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"+rows+"</sheetData></worksheet>").utf8)))
        }
        entries += [
            ("[Content_Types].xml",Data(("<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"json\" ContentType=\"application/json\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"+types+"</Types>").utf8)),
            ("_rels/.rels",Data("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>".utf8)),
            ("xl/workbook.xml",Data(("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>"+sheets+"</sheets></workbook>").utf8)),
            ("xl/_rels/workbook.xml.rels",Data(("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"+relations+"</Relationships>").utf8)),
            ("backup.json",try encoded())]
        return try StoredArchive.encode(entries)
    }
    static func fromArchive(_ data:Data) throws -> Self {
        let entries = try StoredArchive.decode(data)
        guard let backup = entries["backup.json"] else { throw CocoaError(.fileReadCorruptFile) }
        return try decode(backup)
    }
}

public extension CompleteBackup {
    /// Per-entity choices. false retains local; true uses incoming. Missing choices follow the selected default.
    func resolved(against local:CompleteBackup, preferIncoming:Bool, choices:[String:Bool] = [:], fieldChoices:[String:Bool] = [:], replaceAll:Bool = false, restorePreferences:Bool = true) throws -> CompleteBackup {
        if replaceAll {
            var result = self
            if !restorePreferences { result.preferences = local.preferences }
            result.archive.settings = result.preferences
            return try Self.decode(result.encoded())
        }
        func merge<T:Codable & Identifiable>(_ old:[T],_ incoming:[T],_ kind:String) throws -> [T] where T.ID == UUID {
            var result = old
            for value in incoming {
                if let index = result.firstIndex(where: { $0.id == value.id }) {
                    let prefix = kind+value.id.uuidString+"/"
                    let fields = Dictionary(uniqueKeysWithValues:fieldChoices.filter { $0.key.hasPrefix(prefix) }.map { (String($0.key.dropFirst(prefix.count)),$0.value) })
                    let useIncoming = choices[kind+value.id.uuidString] ?? preferIncoming
                    result[index] = try FieldReconciliation.merge(old:result[index],incoming:value,preferIncoming:useIncoming,choices:fields)
                } else { result.append(value) }
            }
            return result
        }
        var result = self
        result.archive = local.archive
        result.archive.pairs = try merge(local.archive.pairs,archive.pairs,"Device")
        result.archive.sessions = try merge(local.archive.sessions,archive.sessions,"Session")
        result.archive.observations = try merge(local.archive.observations,archive.observations,"Battery")
        if preferIncoming, let draft = archive.draft { result.archive.draft = draft }
        result.records = try merge(local.records,records,"Lab")
        let files = try merge(local.attachments ?? [],attachments ?? [],"Attachment")
        result.attachments = files.isEmpty ? nil : files
        result.preferences = local.preferences
        if restorePreferences {
            for (key,value) in preferences where local.preferences[key] == nil || (choices["Preference/"+key] ?? preferIncoming) { result.preferences[key] = value }
        }
        result.archive.settings = result.preferences
        return try Self.decode(result.encoded())
    }
}

/// Device-specific folder authorization; intentionally excluded from portable preferences.
public enum ExtraBackupDestination {
    private static let key = "extraBackupFolderBookmark"
    public static func select(_ url:URL, defaults:UserDefaults = .standard) throws {
        #if os(macOS)
        let bookmark = try url.bookmarkData(options:.withSecurityScope,includingResourceValuesForKeys:nil,relativeTo:nil)
        #else
        let bookmark = try url.bookmarkData(options:[],includingResourceValuesForKeys:nil,relativeTo:nil)
        #endif
        defaults.set(bookmark,forKey:key)
    }
    public static func clear(_ defaults:UserDefaults = .standard) { defaults.removeObject(forKey:key) }
    public static func hasSelection(_ defaults:UserDefaults = .standard) -> Bool { defaults.data(forKey:key) != nil }
    public static func write(_ backup:CompleteBackup, defaults:UserDefaults = .standard) throws {
        guard let bookmark = defaults.data(forKey:key) else { return }
        var stale = false
        #if os(macOS)
        let url = try URL(resolvingBookmarkData:bookmark,options:.withSecurityScope,relativeTo:nil,bookmarkDataIsStale:&stale)
        #else
        let url = try URL(resolvingBookmarkData:bookmark,options:[],relativeTo:nil,bookmarkDataIsStale:&stale)
        #endif
        guard !stale else { throw CocoaError(.fileReadNoPermission) }
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        var coordinationError: NSError?; var writeError: Error?
        NSFileCoordinator().coordinate(writingItemAt:url,options:.forMerging,error:&coordinationError) { folder in
            do { _ = try BackupVault.write(backup,to:folder) } catch { writeError = error }
        }
        if let coordinationError { throw coordinationError }
        if let writeError { throw writeError }
    }
}

public struct ImportFieldDifference: Identifiable, Sendable {
    public let id: String
    public let local: String
    public let incoming: String
}
/// Dictionaries merge by field; arrays remain atomic so indices never silently move.
public enum FieldReconciliation {
    private static func object<T:Encodable>(_ value:T) throws -> [String:Any] {
        guard let result = try JSONSerialization.jsonObject(with:JSONEncoder().encode(value)) as? [String:Any] else { throw CocoaError(.fileReadCorruptFile) }; return result
    }
    private static func render(_ value:Any?) throws -> String {
        guard let value else { return "—" }
        if let text = value as? String { return String(text.prefix(4000)) + (text.count > 4000 ? "…" : "") }
        return String(decoding:try JSONSerialization.data(withJSONObject:value,options:[.sortedKeys,.fragmentsAllowed]),as:UTF8.self)
    }
    public static func differences<T:Codable>(_ old:T,_ incoming:T) throws -> [ImportFieldDifference] {
        func walk(_ a:[String:Any],_ b:[String:Any],_ prefix:String) throws -> [ImportFieldDifference] {
            var rows: [ImportFieldDifference] = []
            for key in Set(a.keys).union(b.keys).sorted() where key != "id" {
                let path = prefix.isEmpty ? key : prefix+"/"+key
                if let av = a[key] as? [String:Any], let bv = b[key] as? [String:Any] { rows += try walk(av,bv,path) }
                else {
                    let oldRaw = try JSONSerialization.data(withJSONObject:a[key] ?? NSNull(),options:[.sortedKeys,.fragmentsAllowed])
                    let newRaw = try JSONSerialization.data(withJSONObject:b[key] ?? NSNull(),options:[.sortedKeys,.fragmentsAllowed])
                    if oldRaw != newRaw || (a[key] == nil) != (b[key] == nil) { rows.append(.init(id:path,local:try render(a[key]),incoming:try render(b[key]))) }
                }
            }
            return rows
        }
        return try walk(object(old),object(incoming),"")
    }
    public static func merge<T:Codable>(old:T,incoming:T,preferIncoming:Bool,choices:[String:Bool]) throws -> T {
        func walk(_ a:[String:Any],_ b:[String:Any],_ prefix:String) -> [String:Any] {
            var result: [String:Any] = [:]
            for key in Set(a.keys).union(b.keys) {
                let path = prefix.isEmpty ? key : prefix+"/"+key
                if key == "id" { result[key] = a[key] ?? b[key]; continue }
                if let av = a[key] as? [String:Any], let bv = b[key] as? [String:Any] { result[key] = walk(av,bv,path) }
                else { result[key] = (choices[path] ?? preferIncoming) ? b[key] : a[key] }
            }
            return result
        }
        let merged = try walk(object(old),object(incoming),"")
        return try JSONDecoder().decode(T.self,from:JSONSerialization.data(withJSONObject:merged,options:[.sortedKeys]))
    }
}

public enum TransferSizeError: LocalizedError {
    case limitExceeded
    public var errorDescription: String? { "Limita formatului de transfer a fost depășită; datele existente sunt păstrate. / Limite du format de transfert dépassée ; les données existantes sont conservées." }
}

/// A local checkpoint distinguishes offline preference edits from a fresh device's defaults.
public enum PreferenceCheckpoint {
    private static let key = "lastDurablePortablePreferences"
    public static func pending(in defaults:UserDefaults) -> [String:String] {
        guard let bytes = defaults.data(forKey:key), let baseline = try? JSONDecoder().decode([String:String].self,from:bytes), (try? PortablePreferences.validate(baseline)) != nil else { return [:] }
        return PortablePreferences.capture(defaults).filter { baseline[$0.key] != $0.value }
    }
    public static func remember(in defaults:UserDefaults) throws {
        let values = PortablePreferences.capture(defaults)
        try PortablePreferences.validate(values)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let bytes = try encoder.encode(values)
        if defaults.data(forKey:key) != bytes { defaults.set(bytes,forKey:key) }
    }
}
