#if os(iOS) && canImport(ActivityKit)
import ActivityKit
public struct MonitorActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        public var snapshot: WidgetSnapshot
        public init(snapshot: WidgetSnapshot) { self.snapshot = snapshot }
    }
    public var pairID: String
    public init(pairID: String) { self.pairID = pairID }
}
#endif
