#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
workspace_dir="$(cd "$project_dir/../.." && pwd)"
mode="${1:---check}"
if [[ "$mode" != '--check' && "$mode" != '--mac' && "$mode" != '--ios' ]]; then
  printf 'Utilizare: pregateste-publicare.command --check | --mac | --ios\n' >&2
  exit 2
fi
missing=0
if [[ ! "${AIRPODS_TEAM_ID:-}" =~ ^[A-Z0-9]{10}$ ]]; then
  printf 'Lipsește echipa Apple Developer (AIRPODS_TEAM_ID, 10 caractere).\n'
  missing=1
fi
if [[ ! "${AIRPODS_PRIVACY_URL:-}" =~ ^https://[^/[:space:]]+ ]]; then
  printf 'Lipsește URL-ul HTTPS public al politicii editorului (AIRPODS_PRIVACY_URL).\n'
  missing=1
fi
if [[ -z "${AIRPODS_PUBLISHER_NAME:-}" || ! "${AIRPODS_SUPPORT_URL:-}" =~ ^https://[^/[:space:]]+ ]]; then
  printf 'Lipsesc identitatea editorului sau pagina de suport (AIRPODS_PUBLISHER_NAME, AIRPODS_SUPPORT_URL).\n'
  missing=1
fi
identities="$(/usr/bin/security find-identity -v -p codesigning)"
if ! printf '%s' "$identities" | /usr/bin/grep -Eq '"(Apple Development|Apple Distribution|Developer ID Application):'; then
  printf 'Nu este disponibilă o identitate Apple validă de semnare.\n'
  missing=1
fi
/usr/bin/plutil -lint "$project_dir/Sources/AirPodsMonitor/Resources/PrivacyInfo.xcprivacy"
if [[ "$missing" -ne 0 ]]; then
  printf '\nPublicarea nu este pregătită. Nu s-a încărcat și nu s-a publicat nimic. Vezi PUBLICARE-1.5.1.md.\n'
  exit 2
fi
if [[ "$mode" == '--check' ]]; then
  printf 'Condițiile locale de bază sunt prezente. CloudKit production, App Store Connect, drepturile asupra conținutului, metadatele și testele pe aparate trebuie validate separat.\n'
  exit 0
fi
if [[ "$mode" == '--mac' ]]; then
  destination='generic/platform=macOS'
  archive_path="$workspace_dir/work/distribution/AirPodsMonitor-Mac.xcarchive"
else
  destination='generic/platform=iOS'
  archive_path="$workspace_dir/work/distribution/AirPodsMonitor-iOS.xcarchive"
fi
mkdir -p "$(dirname "$archive_path")"
xcodebuild -project "$project_dir/AirPodsMonitor.xcodeproj" \
  -scheme AirPodsMonitor-Signed -configuration Release \
  -destination "$destination" -archivePath "$archive_path" \
  DEVELOPMENT_TEAM="$AIRPODS_TEAM_ID" AIRPODS_PRIVACY_URL="$AIRPODS_PRIVACY_URL" \
  ENABLE_HARDENED_RUNTIME=YES CODE_SIGN_INJECT_BASE_ENTITLEMENTS=NO archive
printf '\nArhivă creată. În Organizer: Validate App, apoi distribuția potrivită. Nu s-a încărcat sau publicat nimic automat.\n'
open "$archive_path"
