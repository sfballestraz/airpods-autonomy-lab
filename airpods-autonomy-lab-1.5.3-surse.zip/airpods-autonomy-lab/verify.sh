#!/bin/bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
verification_dir="${1:-$project_dir/../../work/verification}"
mkdir -p "$verification_dir/cache" "$verification_dir/modules"
verification_dir="$(cd "$verification_dir" && pwd)"
export CLANG_MODULE_CACHE_PATH="$verification_dir/modules"
export SWIFTPM_MODULECACHE_OVERRIDE="$verification_dir/modules"
swift test --build-system native --disable-sandbox --package-path "$project_dir" --cache-path "$verification_dir/cache" --manifest-cache local --scratch-path "$verification_dir/package" -Xswiftc -disable-sandbox
xcodebuild -project "$project_dir/AirPodsMonitor.xcodeproj" -scheme AirPodsMonitor -destination 'generic/platform=macOS' -derivedDataPath "$verification_dir/mac" CODE_SIGNING_ALLOWED=NO OTHER_SWIFT_FLAGS=-disable-sandbox build
xcodebuild -project "$project_dir/AirPodsMonitor.xcodeproj" -scheme AirPodsMonitor -destination 'generic/platform=iOS' -derivedDataPath "$verification_dir/ios" CODE_SIGNING_ALLOWED=NO OTHER_SWIFT_FLAGS=-disable-sandbox build
