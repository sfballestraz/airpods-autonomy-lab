import XCTest
import AVFAudio
@testable import AirPodsMonitor

final class AudioCallbackTests: XCTestCase {
    @MainActor func testMeterCallbackRunsOffMainActor() async throws {
        let box = MeterBox()
        let callback = MeterBox.makeTap(box)
        let done = expectation(description: "Audio service callback")
        DispatchQueue.global().async {
            let format = AVAudioFormat(standardFormatWithSampleRate: 48000, channels: 2)!
            let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 128)!
            buffer.frameLength = 128
            for channel in 0..<2 {
                for frame in 0..<128 { buffer.floatChannelData![channel][frame] = 0.5 }
            }
            callback(buffer, AVAudioTime(sampleTime: 0, atRate: 48000))
            done.fulfill()
        }
        await fulfillment(of: [done], timeout: 5)
        XCTAssertEqual(box.read(), -6.020599913, accuracy: 0.001)
        XCTAssertFalse(box.readWaveform().isEmpty)
    }
}
