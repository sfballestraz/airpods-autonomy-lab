import XCTest
@testable import AirPodsMonitor
final class UpdateTests: XCTestCase {
    func testUpdateRejectsUnsafeLinkAndInvalidBuild() throws {
        for link in ["http://example.org/app.pkg", "file:///tmp/app.pkg", "https://user:secret@example.org/app.pkg"] {
            XCTAssertThrowsError(try AppRelease(version: "2.0", build: 10, notesRO: "nou", notesFR: "nouveau", downloadURL: URL(string: link)!).validate())
        }
        XCTAssertThrowsError(try AppRelease(version: "2.0", build: 0, notesRO: "nou", notesFR: "nouveau", downloadURL: URL(string: "https://example.org/app.pkg")!).validate())
        XCTAssertNoThrow(try AppRelease(version: "2.0", build: 10, notesRO: "nou", notesFR: "nouveau", downloadURL: URL(string: "https://example.org/app.pkg")!).validate())
    }
}
