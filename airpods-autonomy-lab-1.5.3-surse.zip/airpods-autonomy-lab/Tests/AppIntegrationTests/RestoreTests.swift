import XCTest
import SwiftData
import MonitorCore
@testable import AirPodsMonitor
final class RestoreTests: XCTestCase {
    @MainActor func fixture(cloudMode: Bool = false) throws -> (URL, Store, JournalSync) {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        let store = Store(journalURL:folder.appending(path:"journal.json"))
        let config = ModelConfiguration(url:folder.appending(path:"lab.store"),cloudKitDatabase:.none)
        let container = try ModelContainer(for:Schema(versionedSchema:LabSchemaV3.self),migrationPlan:LabMigration.self,configurations:config)
        let sync = try JournalSync(store:store,container:container,startTimer:false,cloudSyncOverride:cloudMode); store.sync = sync
        return (folder,store,sync)
    }
    @MainActor func testImportImmediatelyUpdatesVisibleStateAndSurvivesRestart() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        var incoming = Archive(); incoming.pairs[0].name = "Restauré Șț"
        try sync.restore(CompleteBackup(archive:incoming))
        XCTAssertEqual(store.archive.pairs[0].name,"Restauré Șț")
        XCTAssertEqual(try sync.backup().archive.pairs[0].name,"Restauré Șț")
        let restarted = Store(journalURL:store.url)
        _ = try JournalSync(store:restarted,container:sync.container,startTimer:false)
        XCTAssertEqual(restarted.archive.pairs[0].name,"Restauré Șț")
    }
    @MainActor func testIdentityConflictLeavesLocalStateUntouched() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        var incoming = Archive()
        incoming.pairs[0] = .init(id:store.archive.pairs[0].id,name:"wrong",device:.maria)
        let count = try sync.container.mainContext.fetchCount(FetchDescriptor<JournalRevision>())
        XCTAssertThrowsError(try sync.restore(.init(archive:incoming)))
        XCTAssertEqual(store.archive.pairs[0].device,.four)
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<JournalRevision>()),count)
    }
    @MainActor func testCorruptLegacyFileIsNotOverwritten() throws {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let file = folder.appending(path:"journal.json"); let bad = Data("broken".utf8); try bad.write(to:file)
        let store = Store(journalURL:file)
        XCTAssertNotNil(store.error)
        XCTAssertThrowsError(try JournalSync(store:store,startTimer:false))
        XCTAssertEqual(try Data(contentsOf:file),bad)
    }
}
extension RestoreTests {
    @MainActor func testConflictingTransportRevisionRollsBackInsertedLabRecord() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        let row = try XCTUnwrap(sync.container.mainContext.fetch(FetchDescriptor<JournalRevision>()).first)
        var changed = store.archive; changed.pairs[0].name = "Different payload"
        let conflict = CompleteBackup.Revision(id:row.id,timestamp:row.timestamp,payload:try JSONEncoder().encode(changed))
        let record = CompleteBackup.Record(id:UUID(),pairID:store.archive.pairs[0].id,timestamp:Date(),kind:"test",evidence:Evidence.entered.rawValue,source:"test",text:"must roll back")
        let backup = CompleteBackup(archive:store.archive,records:[record],revisions:[conflict])
        XCTAssertThrowsError(try sync.restore(backup))
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabRecord>()),0)
        XCTAssertEqual(store.archive.pairs[0].name,"AirPods 4")
    }
    @MainActor func testAutomaticBackupsAreNotRepeatedUntilDueAndCanBeForced() throws {
        let (folder,store,sync) = try fixture()
        defer { _ = store; try? FileManager.default.removeItem(at:folder) }
        XCTAssertEqual(try BackupVault.entries(in:sync.vaultURL).count,1)
        try sync.automaticBackup()
        XCTAssertEqual(try BackupVault.entries(in:sync.vaultURL).count,1)
        try sync.automaticBackup(force:true)
        XCTAssertEqual(try BackupVault.entries(in:sync.vaultURL).count,2)
    }
}
extension RestoreTests {
    @MainActor func testLegacyAddOnlyImportPreservesExistingNames() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        var incoming = Archive(); incoming.pairs[0].name = "Should not overwrite"
        let newPair = AirPodsPair(name:"New pair",device:.four); incoming.pairs.append(newPair)
        try sync.restore(.init(archive:incoming),overwriteExisting:false)
        XCTAssertEqual(store.archive.pairs[0].name,"AirPods 4")
        XCTAssertTrue(store.archive.pairs.contains { $0.id == newPair.id })
    }
}
extension RestoreTests {
    @MainActor func testAutomaticLocalCleanupMakesRecoveryCopyAndKeepsDifferentIDs() throws {
        let (folder,store,sync) = try fixture()
        defer { _ = store; try? FileManager.default.removeItem(at:folder) }
        let context = sync.container.mainContext
        let id = UUID(); let date = Date()
        for identifier in [id,id,UUID()] {
            let row = LabRecord(pairID:store.archive.pairs[0].id,kind:"test",text:"same")
            row.id = identifier; row.timestamp = date; context.insert(row)
        }
        try context.save(); try sync.removeExactDuplicates()
        XCTAssertEqual(try context.fetchCount(FetchDescriptor<LabRecord>()),2)
        XCTAssertEqual(try BackupVault.entries(in:folder.appending(path:"CleanupRecovery")).count,1)
        try sync.removeExactDuplicates(); XCTAssertEqual(try context.fetchCount(FetchDescriptor<LabRecord>()),2)
    }
    @MainActor func testCleanupDoesNotDeleteConflictingRecords() throws {
        let (folder,store,sync) = try fixture()
        defer { _ = store; try? FileManager.default.removeItem(at:folder) }
        let id = UUID()
        for text in ["A","B"] {
            let row = LabRecord(pairID:store.archive.pairs[0].id,kind:"test",text:text); row.id = id
            sync.container.mainContext.insert(row)
        }
        try sync.container.mainContext.save(); try sync.removeExactDuplicates()
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabRecord>()),2)
        XCTAssertFalse(store.cleanupMessage.isEmpty)
    }
}

extension RestoreTests {
    @MainActor func testCloudModeFiltersCopiesWithoutDeletingPhysicalRows() throws {
        let (folder,store,sync) = try fixture(cloudMode:true)
        defer { _ = store; try? FileManager.default.removeItem(at:folder) }
        let id = UUID(); let date = Date()
        for _ in 0..<2 {
            let row = LabRecord(pairID:store.archive.pairs[0].id,kind:"test",text:"same")
            row.id = id; row.timestamp = date; sync.container.mainContext.insert(row)
        }
        try sync.container.mainContext.save(); try sync.removeExactDuplicates()
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabRecord>()),2)
        XCTAssertEqual(try sync.backup().records.count,1)
        XCTAssertFalse(store.cleanupMessage.isEmpty)
    }
}
extension RestoreTests {
    @MainActor func testCleanupRecoveryFailureNeverDeletesOrBlocksOpening() throws {
        let (folder,store,sync) = try fixture()
        defer { _ = store; try? FileManager.default.removeItem(at:folder) }
        let id = UUID(); let date = Date()
        for _ in 0..<2 {
            let row = LabRecord(pairID:store.archive.pairs[0].id,kind:"test",text:"same")
            row.id = id; row.timestamp = date; sync.container.mainContext.insert(row)
        }
        try sync.container.mainContext.save()
        try Data("blocked directory".utf8).write(to:folder.appending(path:"CleanupRecovery"))
        let newStore = Store(journalURL:store.url)
        let reopened = try JournalSync(store:newStore,container:sync.container,startTimer:false)
        XCTAssertNil(newStore.error); XCTAssertFalse(newStore.serviceWarning.isEmpty)
        XCTAssertEqual(try reopened.container.mainContext.fetchCount(FetchDescriptor<LabRecord>()),2)
    }
}

extension RestoreTests {
    @MainActor func testAttachmentsAndFullReplacementCommitTogether() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        let attachment = CompleteBackup.Attachment(pairID:store.archive.pairs[0].id,filename:"capture.bin",contentType:"public.data",bytes:Data([1,2,3]))
        try sync.restore(.init(archive:store.archive,attachments:[attachment]))
        XCTAssertEqual(try sync.backup().attachments,[attachment])
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabAttachment>()),1)
        try sync.restore(.init(archive:store.archive),replaceAll:true)
        XCTAssertNil(try sync.backup().attachments)
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabAttachment>()),0)
        XCTAssertGreaterThanOrEqual(try BackupVault.entries(in:folder.appending(path:"Recovery")).count,4)
    }
    @MainActor func testConflictingRevisionRollsBackAttachmentInsert() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        let revision = try XCTUnwrap(sync.container.mainContext.fetch(FetchDescriptor<JournalRevision>()).first)
        var archive = store.archive; archive.pairs[0].name = "Other"
        let conflict = CompleteBackup.Revision(id:revision.id,timestamp:revision.timestamp,payload:try JSONEncoder().encode(archive))
        let attachment = CompleteBackup.Attachment(pairID:store.archive.pairs[0].id,filename:"test.bin",contentType:"public.data",bytes:Data([1]))
        XCTAssertThrowsError(try sync.restore(.init(archive:store.archive,revisions:[conflict],attachments:[attachment])))
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabAttachment>()),0)
    }
    @MainActor func testModelV2MigratesToV3WithoutLosingLabRecords() throws {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let config = ModelConfiguration(url:folder.appending(path:"old.store"),cloudKitDatabase:.none)
        let id = UUID()
        do {
            let old = try ModelContainer(for:Schema(versionedSchema:LabSchemaV2.self),configurations:config)
            let row = LabRecord(pairID:AirPodsPair.initial[0].id,kind:"Test",text:"Preserve")
            row.id = id; old.mainContext.insert(row); try old.mainContext.save()
        }
        let migrated = try ModelContainer(for:Schema(versionedSchema:LabSchemaV3.self),migrationPlan:LabMigration.self,configurations:config)
        XCTAssertEqual(try migrated.mainContext.fetch(FetchDescriptor<LabRecord>()).first?.id,id)
        let a = LabAttachment(pairID:AirPodsPair.initial[0].id,filename:"test",contentType:"public.data",bytes:Data([1,2]))
        migrated.mainContext.insert(a); try migrated.mainContext.save()
        XCTAssertEqual(try migrated.mainContext.fetch(FetchDescriptor<LabAttachment>()).first?.bytes,Data([1,2]))
    }
}

extension RestoreTests {
    @MainActor func testRestartPreservesOfflinePreferenceAndIndependentRemotePreference() throws {
        let suite = "OfflinePreferences-"+UUID().uuidString
        let preferences = try XCTUnwrap(UserDefaults(suiteName:suite))
        defer { preferences.removePersistentDomain(forName:suite) }
        preferences.set("ro",forKey:"appLanguage"); preferences.set("Basic",forKey:"eqControlMode")
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let store = Store(journalURL:folder.appending(path:"journal.json"))
        let configuration = ModelConfiguration(url:folder.appending(path:"lab.store"),cloudKitDatabase:.none)
        let container = try ModelContainer(for:Schema(versionedSchema:LabSchemaV3.self),migrationPlan:LabMigration.self,configurations:configuration)
        let sync = try JournalSync(store:store,container:container,startTimer:false,preferences:preferences); store.sync = sync
        try sync.capturePreferences(); store.save()
        let base = store.archive
        var remote = base; remote.settings?["eqControlMode"] = "Expert"
        let event = JournalRevision(payload:try JSONEncoder().encode(remote))
        event.basePayload = try JSONEncoder().encode(base); event.timestamp = Date().addingTimeInterval(5)
        container.mainContext.insert(event); try container.mainContext.save()
        // The local preference changed after the last durable checkpoint, without running a capture timer.
        preferences.set("fr",forKey:"appLanguage")
        let restarted = Store(journalURL:store.url)
        _ = try JournalSync(store:restarted,container:container,startTimer:false,preferences:preferences)
        XCTAssertEqual(preferences.string(forKey:"appLanguage"),"fr")
        XCTAssertEqual(preferences.string(forKey:"eqControlMode"),"Expert")
        XCTAssertEqual(restarted.archive.settings?["appLanguage"],"fr")
        XCTAssertEqual(restarted.archive.settings?["eqControlMode"],"Expert")
    }
    @MainActor func testMirrorFailureDoesNotRepublishRemoteChanges() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        try sync.capturePreferences(); store.save()
        let base = store.archive
        var remote = base; remote.pairs[0].name = "Remote name"
        let event = JournalRevision(payload:try JSONEncoder().encode(remote))
        event.basePayload = try JSONEncoder().encode(base); event.timestamp = Date().addingTimeInterval(5)
        sync.container.mainContext.insert(event); try sync.container.mainContext.save()
        try FileManager.default.removeItem(at:store.url)
        try FileManager.default.createDirectory(at:store.url,withIntermediateDirectories:true)
        try sync.refresh()
        XCTAssertEqual(store.archive.pairs[0].name,"Remote name")
        XCTAssertFalse(store.serviceWarning.isEmpty)
        let count = try sync.container.mainContext.fetchCount(FetchDescriptor<JournalRevision>())
        try sync.capturePreferences()
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<JournalRevision>()),count)
        try FileManager.default.removeItem(at:store.url)
        try sync.refresh()
        XCTAssertEqual(try JSONDecoder().decode(Archive.self,from:Data(contentsOf:store.url)).pairs[0].name,"Remote name")
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<JournalRevision>()),count)
    }
    @MainActor func testIdenticalTransportAttachmentsAreExportedOnce() throws {
        let (folder,store,sync) = try fixture()
        defer { try? FileManager.default.removeItem(at:folder) }
        let id = UUID(), timestamp = Date()
        for _ in 0..<2 {
            let attachment = LabAttachment(pairID:store.archive.pairs[0].id,filename:"capture.bin",contentType:"public.data",bytes:Data([1,2,3]))
            attachment.id = id; attachment.timestamp = timestamp; sync.container.mainContext.insert(attachment)
        }
        try sync.container.mainContext.save()
        let backup = try sync.backup()
        XCTAssertEqual(backup.attachments?.count,1)
        XCTAssertEqual(try CompleteBackup.decode(backup.encoded()).attachments?.count,1)
        XCTAssertEqual(try sync.container.mainContext.fetchCount(FetchDescriptor<LabAttachment>()),2)
    }
}
