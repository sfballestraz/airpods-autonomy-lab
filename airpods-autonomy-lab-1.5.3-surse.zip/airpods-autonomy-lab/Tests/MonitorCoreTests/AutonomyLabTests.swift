import XCTest
@testable import MonitorCore
final class AutonomyLabTests: XCTestCase {
    let date = Date(timeIntervalSince1970:1_700_000_000)
    func testSegmentsExcludeChargingAndWeightByDuration() {
        let a = DischargeSegment(start:date, end:date.addingTimeInterval(3600), initial:100, final:80)
        let b = DischargeSegment(start:date.addingTimeInterval(4200), end:date.addingTimeInterval(6000), initial:90, final:85)
        let charge = DischargeSegment(start:a.end, end:b.start, initial:80, final:90, charging:true)
        XCTAssertNil(charge.rate)
        XCTAssertEqual(DischargeSegment.weightedRate([a,charge,b])!, 25/1.5, accuracy:0.0001)
        XCTAssertNil(DischargeSegment.weightedRate([a,a]))
        XCTAssertNil(DischargeSegment(start:date,end:date,initial:100,final:50).rate)
        XCTAssertNil(DischargeSegment(start:date,end:a.end,initial:.nan,final:50).rate)
    }
    func testEmpiricalRangeNeedsThreeComparablePositiveRates() {
        XCTAssertNil(DischargeSegment.autonomyRange(percent:50,matchedRates:[10,20]))
        XCTAssertNil(DischargeSegment.autonomyRange(percent:50,matchedRates:[0,10,20]))
        XCTAssertEqual(DischargeSegment.autonomyRange(percent:50,matchedRates:[10,20,25]),2...5)
    }
    func testCSVQuotesAndRejection() throws {
        XCTAssertEqual(try LabTransfer.parseCSV("a,b\n\"one,two\",\"three\n\"\"four\"\"\"\n"), [["a","b"],["one,two","three\n\"four\""]])
        XCTAssertThrowsError(try LabTransfer.parseCSV("\"unfinished"))
        XCTAssertThrowsError(try LabTransfer.parseCSV("\"a\"bad"))
        XCTAssertThrowsError(try LabTransfer.csvArchive("wrong,header\n"))
    }
    func testCSVTemplateImportsActualRowsOnly() throws {
        let pair = AirPodsPair.initial[0].id.uuidString
        let header = "pair_id,test_id,start,end,firmware,volume,mode,environment,source,activity,component,initial,final,notes\n"
        let row = "\(pair),DEMO-T1,2023-11-14T10:00:00Z,2023-11-14T11:00:00Z,9A348,25,Oprit,tren,iPhone,music,Casca stângă,100,80,DEMO\n"
        let archive = try LabTransfer.csvArchive(header + row)
        XCTAssertEqual(archive.sessions.count,1)
        XCTAssertEqual(archive.sessions[0].samples[0].rate(hours:1),20)
        XCTAssertThrowsError(try LabTransfer.csvArchive(header + row + row))
    }
    func testArchiveValidationAndNoInventedHistory() throws {
        let archive = Archive()
        XCTAssertTrue(try LabTransfer.decodeArchive(JSONEncoder().encode(archive)).sessions.isEmpty)
        XCTAssertThrowsError(try LabTransfer.decodeArchive(Data("{} broken".utf8)))
    }
}
extension AutonomyLabTests {
    func testEncryptedBackupAuthentication() throws {
        let original = Data("DEMO · no real readings".utf8)
        let encrypted = try ProtectedBackup.seal(original,password:"demo-password-123")
        XCTAssertTrue(ProtectedBackup.isProtected(encrypted))
        XCTAssertEqual(try ProtectedBackup.open(encrypted,password:"demo-password-123"),original)
        XCTAssertThrowsError(try ProtectedBackup.open(encrypted,password:"wrong-password-123"))
        XCTAssertThrowsError(try ProtectedBackup.seal(original,password:"short"))
    }
    func testLabConditionsSeparateTemperatureRouteContentAndChannel() {
        let a = LabConditions(contentID:"DEMO-track",temperatureC:20,route:"A2DP",firmwareChannel:"stable",usage:"L+R")
        let b = LabConditions(contentID:"DEMO-track",temperatureC:22,route:"A2DP",firmwareChannel:"stable",usage:"L+R")
        XCTAssertTrue(a.valid); XCTAssertNotEqual(a,b)
        XCTAssertFalse(LabConditions(contentID:"",temperatureC:.nan,route:"",firmwareChannel:"x",usage:"").valid)
    }
}

import SwiftData
extension AutonomyLabTests {
    @MainActor func testSwiftDataPersistsEvidenceWithoutDemoInjection() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let configuration = ModelConfiguration("LabTest",url:folder.appendingPathComponent("lab.store"),cloudKitDatabase:.none)
        let id: UUID
        do {
            let container = try ModelContainer(for:LabRecord.self,configurations:configuration)
            let context = ModelContext(container)
            XCTAssertEqual(try context.fetchCount(FetchDescriptor<LabRecord>()),0)
            let record = LabRecord(pairID:AirPodsPair.initial[0].id,kind:"DEMO test only",text:"No actual AirPods data",source:"Unit test",evidence:.entered)
            id = record.id
            context.insert(record); try context.save()
        }
        let reopened = try ModelContainer(for:LabRecord.self,configurations:configuration)
        let records = try ModelContext(reopened).fetch(FetchDescriptor<LabRecord>())
        XCTAssertEqual(records.count,1); XCTAssertEqual(records[0].id,id)
        XCTAssertEqual(records[0].evidence,Evidence.entered.rawValue)
        XCTAssertEqual(records[0].source,"Unit test")
    }
}
