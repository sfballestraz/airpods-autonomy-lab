import XCTest
@testable import MonitorCore
final class CompleteTransferTests: XCTestCase {
    func testPortablePreferencesPreserveEQModelsAndRejectHardwareAndPaths() throws {
        let suite = "AirPodsTest-"+UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName:suite)); defer { defaults.removePersistentDomain(forName:suite) }
        defaults.set(try JSONEncoder().encode(BuiltInEQPreset.voice.settings),forKey:"parametricEQ")
        let presets = [EQPreset(name:"HomePod",settings:EQSettings(),homePod:.miniTwo)]
        defaults.set(try JSONEncoder().encode(presets),forKey:"customEQPresets")
        defaults.set("fr",forKey:"appLanguage"); defaults.set(0.3,forKey:"playerVolume")
        let values = PortablePreferences.capture(defaults)
        try PortablePreferences.validate(values)
        defaults.removePersistentDomain(forName:suite)
        try PortablePreferences.apply(values,to:defaults)
        XCTAssertEqual(PortablePreferences.capture(defaults),values)
        XCTAssertThrowsError(try PortablePreferences.apply(["outputVolume":"1"],to:defaults))
        XCTAssertThrowsError(try PortablePreferences.apply(["playerVolume":"nan"],to:defaults))
        XCTAssertThrowsError(try PortablePreferences.apply(["parametricEQ":"bad"],to:defaults))
    }
    func testTablesZIPAndXLSXRoundTripWithUnicodeAndAttachment() throws {
        var backup = CompleteBackup(archive:Archive(),preferences:["appLanguage":"ro"])
        backup.archive.pairs[0].name = "=Мария, Șț\n<&>"
        let end = Date().addingTimeInterval(-60)
        backup.archive.sessions = [.init(device:.four,pairID:backup.archive.pairs[0].id,start:end.addingTimeInterval(-3600),end:end,volume:25,mode:"Oprit",environment:"Acasă",firmware:"9A348",source:"manual",activity:"music",notes:"Échantillon Șț",interrupted:false,samples:[.init(component:.left,initial:100,final:80)])]
        backup.archive.observations = [.init(pairID:backup.archive.pairs[0].id,component:.left,level:80,observedAt:end)]
        backup.attachments = [.init(pairID:backup.archive.pairs[0].id,filename:"écran.png",contentType:"public.png",bytes:Data([0,1,2,255]))]
        let expected = try backup.encoded()
        for data in [try backup.xlsx(),try backup.csvTablesArchive()] {
            XCTAssertEqual(try CompleteBackup.fromArchive(data).encoded(),expected)
            let entries = try StoredArchive.decode(data)
            XCTAssertNotNil(entries["backup.json"])
        }
        let csvEntries = try StoredArchive.decode(backup.csvTablesArchive())
        XCTAssertTrue(String(decoding:try XCTUnwrap(csvEntries["Devices.csv"]),as:UTF8.self).contains("'=Мария"))
        let xlsx = try StoredArchive.decode(backup.xlsx())
        let sheet = String(decoding:try XCTUnwrap(xlsx["xl/worksheets/sheet1.xml"]),as:UTF8.self)
        XCTAssertTrue(sheet.contains("&lt;&amp;&gt;")); XCTAssertFalse(sheet.contains("<f>"))
        if let folder = ProcessInfo.processInfo.environment["AIRPODS_TRANSFER_FIXTURE"] {
            try backup.xlsx().write(to:URL(fileURLWithPath:folder).appendingPathComponent("roundtrip.xlsx"))
            try backup.csvTablesArchive().write(to:URL(fileURLWithPath:folder).appendingPathComponent("roundtrip.zip"))
        }
    }
    func testZIPRejectsCorruptionTruncationAndPathTraversal() throws {
        let bytes = try StoredArchive.encode([("backup.json",Data("hello".utf8))])
        var corrupt = bytes; corrupt[45] ^= 1
        XCTAssertThrowsError(try StoredArchive.decode(corrupt))
        for count in [0,1,10,22,bytes.count-1] { XCTAssertThrowsError(try StoredArchive.decode(Data(bytes.prefix(count)))) }
        XCTAssertThrowsError(try StoredArchive.encode([("../escape",Data())]))
        XCTAssertThrowsError(try StoredArchive.encode([("same",Data()),("same",Data())]))
        XCTAssertEqual(StoredArchive.crc32(Data("123456789".utf8)),0xcbf43926)
    }
    func testPerEntityConflictChoicesAndFullReplacement() throws {
        let id = UUID(), pair = AirPodsPair.initial[0].id
        let old = CompleteBackup.Record(id:id,pairID:pair,timestamp:Date(),kind:"Note",evidence:Evidence.entered.rawValue,source:"manual",text:"Local")
        var changed = old; changed.text = "Incoming"
        var local = CompleteBackup(archive:Archive(),records:[old],preferences:["appLanguage":"ro"])
        var incoming = CompleteBackup(archive:Archive(),records:[changed],preferences:["appLanguage":"fr"])
        incoming.archive.pairs[0].name = "New name"
        let differences = try incoming.differences(from:local)
        XCTAssertTrue(differences.contains { $0.id == "Lab"+id.uuidString })
        var result = try incoming.resolved(against:local,preferIncoming:false)
        XCTAssertEqual(result.records[0].text,"Local"); XCTAssertEqual(result.preferences["appLanguage"],"ro")
        result = try incoming.resolved(against:local,preferIncoming:false,choices:["Lab"+id.uuidString:true])
        XCTAssertEqual(result.records[0].text,"Incoming"); XCTAssertEqual(result.archive.pairs[0].name,local.archive.pairs[0].name)
        local.records.append(.init(id:UUID(),pairID:pair,timestamp:Date(),kind:"Note",evidence:Evidence.entered.rawValue,source:"manual",text:"Only local"))
        result = try incoming.resolved(against:local,preferIncoming:true,replaceAll:true,restorePreferences:false)
        XCTAssertEqual(result.records.count,1); XCTAssertEqual(result.preferences["appLanguage"],"ro")
    }
    func testAttachmentsValidateLinksNamesAndIdentity() throws {
        var backup = CompleteBackup(archive:Archive())
        let attachment = CompleteBackup.Attachment(pairID:backup.archive.pairs[0].id,filename:"capture.png",contentType:"public.png",bytes:Data([1,2]))
        backup.attachments = [attachment]
        XCTAssertEqual(try CompleteBackup.decode(backup.encoded()).attachments,[attachment])
        backup.attachments = [attachment,attachment]
        XCTAssertThrowsError(try CompleteBackup.decode(backup.encoded()))
        var bad = attachment; bad.filename = "../capture.png"; backup.attachments = [bad]
        XCTAssertThrowsError(try CompleteBackup.decode(backup.encoded()))
        bad = attachment; bad.pairID = UUID(); backup.attachments = [bad]
        XCTAssertThrowsError(try CompleteBackup.decode(backup.encoded()))
    }
    func testPreferenceRevisionMergeRetainsIndependentKeys() throws {
        var base = Archive(); base.settings = ["appLanguage":"ro","eqControlMode":"Basic"]
        var a = base; a.settings?["appLanguage"] = "fr"
        var b = base; b.settings?["eqControlMode"] = "Expert"
        let encoder = JSONEncoder(); let date = Date()
        let revisions: [CompleteBackup.Revision] = [
            .init(id:UUID(),timestamp:date,payload:try encoder.encode(base)),
            .init(id:UUID(),timestamp:date.addingTimeInterval(1),payload:try encoder.encode(a),basePayload:try encoder.encode(base)),
            .init(id:UUID(),timestamp:date.addingTimeInterval(2),payload:try encoder.encode(b),basePayload:try encoder.encode(base))]
        let result = try JournalHistory.materialize(revisions.reversed())
        XCTAssertEqual(result.settings?["appLanguage"],"fr"); XCTAssertEqual(result.settings?["eqControlMode"],"Expert")
    }
}

extension CompleteTransferTests {
    func testAdditionalLocalFolderBackupAndStopPreserveFiles() throws {
        let directory = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let suite = "FolderTest-"+UUID().uuidString
        let defaults = try XCTUnwrap(UserDefaults(suiteName:suite))
        defer { defaults.removePersistentDomain(forName:suite); try? FileManager.default.removeItem(at:directory) }
        do { try ExtraBackupDestination.select(directory,defaults:defaults) }
        catch let error as NSError where error.domain == NSCocoaErrorDomain && error.code == 256 && String(describing:error).contains("ScopedBookmarksAgent") {
            throw XCTSkip("The macOS ScopedBookmarksAgent is unavailable in this test environment; validate folder authorization in the signed app.")
        }
        XCTAssertTrue(ExtraBackupDestination.hasSelection(defaults))
        let backup = CompleteBackup(archive:Archive())
        try ExtraBackupDestination.write(backup,defaults:defaults)
        let files = try BackupVault.entries(in:directory)
        XCTAssertEqual(files.count,1)
        XCTAssertEqual(try BackupVault.verified(try XCTUnwrap(files.first).url).encoded(),try backup.encoded())
        ExtraBackupDestination.clear(defaults)
        XCTAssertFalse(ExtraBackupDestination.hasSelection(defaults))
        XCTAssertEqual(try BackupVault.entries(in:directory).count,1)
    }
    func testMalformedCentralDirectoryOffsetIsRejectedWithoutTrap() throws {
        var data = try StoredArchive.encode([("backup.json",Data([1,2,3]))])
        // Corrupt the central entry's local offset while retaining the actual payload.
        let bytes = [UInt8](data)
        let central = (0..<(bytes.count-4)).first { Array(bytes[$0..<$0+4]) == [0x50,0x4b,0x01,0x02] }!
        for i in 0..<4 { data[central+42+i] = 0xff }
        XCTAssertThrowsError(try StoredArchive.decode(data))
    }
}

extension CompleteTransferTests {
    func testFieldResolutionKeepsIdentityAndCombinesIndependentValues() throws {
        let id = UUID(), pair = AirPodsPair.initial[0].id
        let local = CompleteBackup.Record(id:id,pairID:pair,timestamp:Date(),kind:"Original kind",evidence:Evidence.entered.rawValue,source:"local source",text:"local note")
        var incoming = local; incoming.text = "incoming note"; incoming.source = "incoming source"
        let differences = try FieldReconciliation.differences(local,incoming)
        XCTAssertEqual(Set(differences.map(\.id)),Set(["text","source"]))
        let merged = try FieldReconciliation.merge(old:local,incoming:incoming,preferIncoming:false,choices:["text":true])
        XCTAssertEqual(merged.id,id); XCTAssertEqual(merged.text,"incoming note"); XCTAssertEqual(merged.source,"local source")
        let old = CompleteBackup(archive:Archive(),records:[local])
        let backup = CompleteBackup(archive:Archive(),records:[incoming])
        let result = try backup.resolved(against:old,preferIncoming:true,fieldChoices:["Lab"+id.uuidString+"/source":false])
        XCTAssertEqual(result.records[0].source,"local source"); XCTAssertEqual(result.records[0].text,"incoming note")
    }
}

extension CompleteTransferTests {
    func testBackupRejectsInvalidMeasurementsAndUnsafeAttachmentName() throws {
        var archive = Archive(); let end = Date().addingTimeInterval(-60)
        archive.sessions = [.init(device:.four,pairID:archive.pairs[0].id,start:end.addingTimeInterval(-3600),end:end,volume:101,mode:"Oprit",environment:"Acasă",firmware:"9A348",source:"manual",activity:"music",notes:"",interrupted:false,samples:[.init(component:.left,initial:100,final:80)])]
        XCTAssertThrowsError(try CompleteBackup.decode(CompleteBackup(archive:archive).encoded()))
        archive.sessions = []
        archive.observations = [.init(pairID:archive.pairs[0].id,component:.headphones,level:80,observedAt:end)]
        XCTAssertThrowsError(try CompleteBackup.decode(CompleteBackup(archive:archive).encoded()))
        archive.observations = []
        let attachment = CompleteBackup.Attachment(pairID:archive.pairs[0].id,filename:"bad\nname.png",contentType:"public.png",bytes:Data([1]))
        XCTAssertThrowsError(try CompleteBackup.decode(CompleteBackup(archive:archive,attachments:[attachment]).encoded()))
    }
}
