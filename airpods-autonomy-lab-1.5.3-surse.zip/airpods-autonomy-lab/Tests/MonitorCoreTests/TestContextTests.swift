import XCTest
@testable import MonitorCore
final class TestContextTests: XCTestCase {
    func sample(_ context: TestContext? = nil, environment: String = "Transport") -> Session {
        Session(device:.four,pairID:AirPodsPair.initial[0].id,start:Date(timeIntervalSince1970:1_700_000_000),end:Date(timeIntervalSince1970:1_700_003_600),volume:25,mode:"Oprit",environment:environment,firmware:"test",source:"manual",activity:"music",notes:"",interrupted:false,samples:[.init(component:.left,initial:100,final:80)],testContext:context)
    }
    func testOldJournalPreservesEnvironmentWithoutGuessingVehicle() throws {
        let data = try JSONEncoder().encode(sample())
        let restored = try JSONDecoder().decode(Session.self,from:data)
        XCTAssertNil(restored.testContext); XCTAssertEqual(restored.environment,"Transport")
        XCTAssertEqual(restored.recordedLocation,.transport)
    }
    func testContextAndDraftRoundtripJSONAndCSV() throws {
        var archive = Archive()
        let context = TestContext(location:.boat,noise:.moderate,details:"Pont extérieur · șț")
        archive.sessions = [sample(context,environment:TestLocation.boat.legacyValue)]; archive.draft = archive.sessions[0]
        let backup = CompleteBackup(archive:archive)
        for restored in [try CompleteBackup.decode(backup.encoded()),try CompleteBackup.fromCSV(backup.csv())] {
            XCTAssertEqual(restored.archive.sessions[0].testContext,context)
            XCTAssertEqual(restored.archive.draft?.testContext,context)
        }
    }
    func testMixedIsJournalledButNotComparableAndOtherRequiresDetails() {
        let mixed = sample(.init(location:.mixed,details:"Tren 30 min + autobuz 20 min"))
        XCTAssertNil(mixed.validation); XCTAssertFalse(mixed.comparable)
        XCTAssertNotNil(sample(.init(location:.other)).validation)
    }
    func testDifferentNoiseOrDetailsPreventAutomaticComparison() {
        let train = sample(.init(location:.train,noise:.quiet))
        let noisyTrain = sample(.init(location:.train,noise:.loud))
        XCTAssertFalse(train.sameProtocol(as:noisyTrain)); XCTAssertFalse(train.sameProtocol(as:sample()))
    }
    func testPivotGroupsAndFiltersByPlace() throws {
        var archive = Archive(); archive.sessions = [sample(.init(location:.train)),sample(.init(location:.bus))]
        let report = try PivotReport.build(archive:archive,dimension:.location,metric:.sessions,location:.train)
        XCTAssertEqual(report.includedSessions,1); XCTAssertEqual(report.cells.first?.groupID,"train")
    }
    func testLegacyBackupSchemaTwoMigratesToThreeAndRejectsMismatchedCSVHeader() throws {
        var backup = CompleteBackup(archive:Archive()); backup.schemaVersion = 2
        XCTAssertEqual(try CompleteBackup.decode(backup.encoded()).schemaVersion,4)
        XCTAssertEqual(try CompleteBackup.fromCSV(backup.csv()).schemaVersion,4)
        let mismatched = String(decoding:try backup.csv(),as:UTF8.self).replacingOccurrences(of:"AirPodsAutonomyLab,2,",with:"AirPodsAutonomyLab,3,")
        XCTAssertThrowsError(try CompleteBackup.fromCSV(Data(mismatched.utf8)))
    }
    func testPlaceLabelsHaveRomanianFrenchEnglishAndStableCodes() {
        XCTAssertEqual(TestLocation.boat.rawValue,"boat")
        XCTAssertEqual(TestLocation.bus.title(language:"fr"),"Bus")
        XCTAssertEqual(TestLocation.home.title(language:"ro"),"Acasă")
        for place in TestLocation.allCases { XCTAssertFalse(place.title(language:"en").isEmpty) }
    }
}
