import XCTest
import Foundation
@testable import MonitorCore

final class LiveAppleIntegrationTests: XCTestCase {
    func testLiveApplePageThroughURLSessionAndProductionParser() async throws {
        guard ProcessInfo.processInfo.environment["AIRPODS_LIVE_APPLE_TEST"] == "1" else { throw XCTSkip("Set AIRPODS_LIVE_APPLE_TEST=1 to check the real Apple page explicitly.") }
        var request = URLRequest(url: AppleFirmwarePage.url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        request.setValue("text/html", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        let http = try XCTUnwrap(response as? HTTPURLResponse)
        XCTAssertEqual(http.statusCode, 200)
        XCTAssertEqual(http.url?.host, "support.apple.com")
        XCTAssertEqual(http.url?.scheme, "https")
        let html = try XCTUnwrap(String(data: data, encoding: .utf8))
        for device in Device.allCases where device != .other {
            let version = try XCTUnwrap(AppleFirmwarePage.version(in: html, for: device), "Apple live HTML: missing exact model \(device)")
            print("LIVE APPLE CHECK: \(device.displayName) = \(version)")
            XCTAssertEqual(FirmwareComparison.compare(installed: version, official: version, verified: true), .upToDate)
            XCTAssertEqual(FirmwareComparison.compare(installed: version, official: version, verified: false), .unknown)
        }
        XCTAssertNil(AppleFirmwarePage.version(in: html, for: .other))
    }
}
