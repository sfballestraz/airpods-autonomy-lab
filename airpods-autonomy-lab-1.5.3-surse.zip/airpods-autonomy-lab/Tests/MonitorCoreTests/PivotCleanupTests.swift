import XCTest
@testable import MonitorCore
final class PivotCleanupTests: XCTestCase {
    func session(hours: Double = 1, drop: Int = 20, id: UUID = UUID(), pair: UUID = AirPodsPair.initial[0].id, firmware: String = "test-stable", volume: Int = 25, date: Date = Date(timeIntervalSince1970:1_700_000_000)) -> Session {
        Session(id:id,device:.four,pairID:pair,start:date,end:date.addingTimeInterval(hours*3600),volume:volume,mode:"Oprit",environment:"test",firmware:firmware,source:"manual",activity:"music",notes:"",interrupted:false,samples:[.init(component:.left,initial:100,final:100-drop)],conditions:.init(contentID:"same",temperatureC:20,route:"same",firmwareChannel:"stable",usage:"L+R"))
    }
    func testExactCopiesRemovedButConflictsAndDifferentUUIDsPreserved() throws {
        let a = session(); var conflict = a; conflict.notes = "Different evidence"
        let other = session()
        let result = try ExactDuplicates.rows([a,a,conflict,other])
        XCTAssertEqual(result.duplicateIndices,[1]); XCTAssertEqual(result.values.count,3); XCTAssertEqual(result.conflictingIDs,1)
    }
    func testArchiveAndBackupAutomaticallyNormalizeIdenticalImportRows() throws {
        var archive = Archive(); let a = session(); archive.sessions = [a,a]
        let data = try JSONEncoder().encode(archive)
        XCTAssertEqual(try JSONDecoder().decode(Archive.self,from:data).sessions.count,1)
        let r = CompleteBackup.Record(id:UUID(),pairID:archive.pairs[0].id,timestamp:Date(),kind:"test",evidence:Evidence.entered.rawValue,source:"test",text:"éȘ")
        XCTAssertEqual(try CompleteBackup.decode(CompleteBackup(archive:archive,records:[r,r]).encoded()).records.count,1)
    }
    func testPivotWeightsRateByDurationAndExcludesOtherProtocols() throws {
        var a = Archive(); let first = session(); a.sessions = [first, session(hours:2,drop:30),session(volume:50)]
        let result = try PivotReport.build(archive:a,dimension:.firmware,metric:.dischargeRate,referenceID:first.id)
        XCTAssertEqual(result.includedSessions,2); XCTAssertEqual(result.excludedSessions,1)
        XCTAssertEqual(try XCTUnwrap(result.cells.first).value,50.0/3.0,accuracy:0.000001)
        XCTAssertTrue(try PivotReport.build(archive:a,dimension:.firmware,metric:.dischargeRate).needsReference)
    }
    func testPivotDoesNotDoubleCountTransportDuplicatesOrGuessConflicts() throws {
        var a = Archive(); let first = session(); a.sessions = [first,first]
        XCTAssertEqual(try PivotReport.build(archive:a,dimension:.pair,metric:.sessions).cells.first?.value,1)
        var conflict = first; conflict.notes = "other"; a.sessions.append(conflict)
        XCTAssertTrue(try PivotReport.build(archive:a,dimension:.pair,metric:.sessions).cells.isEmpty)
    }
    func testPivotUsesZurichMonthAndKeepsIdenticallyNamedPairsSeparate() throws {
        var a = Archive(); a.pairs[0].name = "Same"; a.pairs.append(.init(name:"Same",device:.four))
        let date = try XCTUnwrap(ISO8601DateFormatter().date(from:"2023-11-30T23:30:00Z"))
        a.sessions = [session(pair:a.pairs[0].id,date:date),session(pair:a.pairs.last!.id,date:date)]
        XCTAssertEqual(try PivotReport.build(archive:a,dimension:.month,metric:.sessions).cells.first?.groupLabel,"2023-12")
        XCTAssertEqual(try PivotReport.build(archive:a,dimension:.pair,metric:.sessions).cells.count,2)
    }
    func testNavigationBackAndHomeDoNotCreateLoops() {
        var history = NavigationHistory(); history.back(); history.select(0)
        XCTAssertEqual(history.pages,[0]); history.select(2); history.select(4); history.back()
        XCTAssertEqual(history.current,2); history.select(99); XCTAssertEqual(history.current,2)
        history.home(); XCTAssertEqual(history.pages,[0]); XCTAssertFalse(history.canGoBack)
    }
}
