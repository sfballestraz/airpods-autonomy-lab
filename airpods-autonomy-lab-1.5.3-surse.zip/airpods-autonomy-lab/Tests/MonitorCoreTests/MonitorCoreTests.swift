import XCTest
@testable import MonitorCore
final class MonitorCoreTests: XCTestCase {
    func testExactControlInputUsesLocaleAndRejectsUnsafeValues() {
        let ro = Locale(identifier: "ro_RO"), en = Locale(identifier: "en_US")
        XCTAssertEqual(ExactControlInput.parse(" 55 ", locale: ro, range: 0...100, step: 1), 55)
        XCTAssertEqual(ExactControlInput.parse("0,7", locale: ro, range: 0.2...10, step: 0.1), 0.7)
        XCTAssertEqual(ExactControlInput.parse("-3.5", locale: en, range: -12...12, step: 0.5), -3.5)
        for value in ["101", "-1", "NaN", "inf", "25abc", "25%", "2,500", "25.5", ""] {
            XCTAssertNil(ExactControlInput.parse(value, locale: en, range: 0...100, step: 1), value)
        }
        XCTAssertEqual(ExactControlInput.parse("0.7", locale: ro, range: 0.2...10, step: 0.1), 0.7)
        XCTAssertEqual(ExactControlInput.parse("50.00", locale: ro, range: 0...100, step: 1), 50)
        XCTAssertEqual(ExactControlInput.parse("50,00", locale: ro, range: 0...100, step: 1), 50)
        XCTAssertEqual(ExactControlInput.parse("-3.25", locale: en, range: -12...12, step: 0.01), -3.25)
        XCTAssertNil(ExactControlInput.parse("50.25", locale: ro, range: 0...100, step: 1))
        XCTAssertNil(ExactControlInput.parse("0.001", locale: en, range: 0...100, step: 0.01))
        XCTAssertNil(ExactControlInput.parse("10", locale: en, range: 0...100, step: 0))
    }
    func testFirmwareComparisonDoesNotClaimUnknownOrBetaIsCurrent() {
        XCTAssertEqual(FirmwareComparison.compare(installed: " 9a348 ", official: "9A348", verified: true), .upToDate)
        XCTAssertEqual(FirmwareComparison.compare(installed: "9A347", official: "9A348", verified: true), .updateAvailable)
        XCTAssertEqual(FirmwareComparison.compare(installed: "8B41", official: "9A348", verified: true), .updateAvailable)
        XCTAssertEqual(FirmwareComparison.compare(installed: "9A350", official: "9A348", verified: true), .differentOrBeta)
        XCTAssertEqual(FirmwareComparison.compare(installed: "9A5314B", official: "9A348", verified: true), .differentOrBeta)
        XCTAssertEqual(FirmwareComparison.compare(installed: "n/a", official: "n/a", verified: true), .differentOrBeta)
        XCTAssertEqual(FirmwareComparison.compare(installed: "9A348", official: "9A348", verified: false), .unknown)
        XCTAssertEqual(FirmwareComparison.compare(installed: "", official: "9A348", verified: true), .unknown)
        XCTAssertEqual(FirmwareComparison.compare(installed: "6.8.8", official: "6.8.8", verified: true), .upToDate)
        XCTAssertEqual(FirmwareComparison.compare(installed: "6.8.8", official: "9A348", verified: true), .differentOrBeta)
    }
    func testAppleFirmwareHTMLRequiresExactModelAndUniqueVersion() {
        let html = "<ul><li><p>AirPods 4: 9A348</p></li><li>AirPods 4 with Active Noise Cancellation: 9A349</li><li>AirPods 5: 9A350</li><li>AirPods 5 with Wireless Charging Case: 9A351</li><li>AirPods 1: 6.8.8</li></ul>"
        XCTAssertEqual(AppleFirmwarePage.version(in: html, for: .four), "9A348")
        XCTAssertEqual(AppleFirmwarePage.version(in: html, for: .fourANC), "9A349")
        XCTAssertEqual(AppleFirmwarePage.version(in: html, for: .five), "9A350")
        XCTAssertEqual(AppleFirmwarePage.version(in: html, for: .maria), "9A351")
        XCTAssertEqual(AppleFirmwarePage.version(in: html, for: .one), "6.8.8")
        XCTAssertNil(AppleFirmwarePage.version(in: html, for: .other))
        XCTAssertNil(AppleFirmwarePage.version(in: html, for: .proThree))
        XCTAssertNil(AppleFirmwarePage.version(in: html + "<li>AirPods 4: 9A350</li>", for: .four))
        XCTAssertNil(AppleFirmwarePage.version(in: "<li>AirPods 4: 9A348 beta</li>", for: .four))
        XCTAssertNil(AppleFirmwarePage.version(in: "<p>AirPods 4: 9A348</p>", for: .four))
        XCTAssertEqual(Device.allCases.filter { AppleFirmwarePage.modelName($0) != nil }.count, Device.allCases.count - 1)
    }
    func testPairDetailsMigrationAndIndependentRoundTrip() throws {
        let legacy = Data(#"{"id":"00000000-0000-0000-0000-000000000001","name":"Old","device":"AirPods 4"}"#.utf8)
        let old = try JSONDecoder().decode(AirPodsPair.self, from: legacy)
        XCTAssertNil(old.details)
        var first = old
        var details = PairDetails(); details.primarySerial = " abc123 "; details.normalizeSerials()
        details.leftSerial = "LEFT1"; details.rightSerial = "RIGHT2"; details.caseSerial = "CASE3"
        details.coverage = .active; details.coverageCheckedAt = Date(timeIntervalSince1970: 100)
        details.location = HostLocationMemo(latitude: 46.2, longitude: 6.1, accuracy: 120, recordedAt: Date(timeIntervalSince1970: 99), hostPlatform: "iOS")
        first.details = details
        let second = AirPodsPair(name: "Other", device: .four)
        let copy = try JSONDecoder().decode([AirPodsPair].self, from: JSONEncoder().encode([first, second]))
        XCTAssertEqual(copy[0].details, details); XCTAssertNil(copy[1].details)
        XCTAssertEqual(copy[0].details?.primarySerial, "ABC123")
    }
    func testManualSerialValidationDoesNotClaimAuthenticity() {
        var details = PairDetails(); XCTAssertTrue(details.validSerials)
        for invalid in ["A B", "ABC-123", "É123", String(repeating: "A", count: 41), "<serial>"] {
            details.primarySerial = invalid; XCTAssertFalse(details.validSerials, invalid)
        }
        details.primarySerial = " abc123\n"; details.normalizeSerials(); XCTAssertTrue(details.validSerials)
        XCTAssertEqual(details.coverage, .unknown); XCTAssertNil(details.coverageCheckedAt)
    }
    func testHostLocationValidationAndRSSIUnavailableSentinel() {
        let now = Date(timeIntervalSince1970: 1000)
        var memo = HostLocationMemo(latitude: 46, longitude: 6, accuracy: 100, recordedAt: now, hostPlatform: "macOS")
        XCTAssertTrue(memo.valid(at: now))
        memo.latitude = 91; XCTAssertFalse(memo.valid(at: now)); memo.latitude = 46
        memo.longitude = .nan; XCTAssertFalse(memo.valid(at: now)); memo.longitude = 6
        memo.accuracy = -1; XCTAssertFalse(memo.valid(at: now)); memo.accuracy = .infinity
        XCTAssertFalse(memo.valid(at: now)); memo.accuracy = 100
        memo.recordedAt = now.addingTimeInterval(10); XCTAssertFalse(memo.valid(at: now))
        XCTAssertNil(ReceptionSample(rawRSSI: 127, at: now))
        XCTAssertNil(ReceptionSample(rawRSSI: -128, at: now))
        XCTAssertEqual(ReceptionSample(rawRSSI: 0, at: now)?.value, 0)
        XCTAssertEqual(ReceptionSample(rawRSSI: -60, at: now)?.value, -60)
    }
    func testDisconnectAlertsRequireObservedTransitionAndCooldown() {
        var guardPolicy = DisconnectGuard(); let now = Date(timeIntervalSince1970: 1000)
        XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now))
        XCTAssertFalse(guardPolicy.observe(.connected, eligibleLoss: false, at: now))
        XCTAssertTrue(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now))
        XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now.addingTimeInterval(1)))
        XCTAssertFalse(guardPolicy.observe(.connected, eligibleLoss: false, at: now.addingTimeInterval(2)))
        XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now.addingTimeInterval(3)))
        XCTAssertFalse(guardPolicy.observe(.connected, eligibleLoss: false, at: now.addingTimeInterval(300)))
        XCTAssertTrue(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now.addingTimeInterval(301)))
    }
    func testUnknownAndManualRoutesDisarmSeparationAlert() {
        for interruption in [ObservedLinkState.unknown, .otherRoute] {
            var guardPolicy = DisconnectGuard(); let now = Date()
            XCTAssertFalse(guardPolicy.observe(.connected, eligibleLoss: false, at: now))
            XCTAssertFalse(guardPolicy.observe(interruption, eligibleLoss: true, at: now))
            XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now))
        }
        var guardPolicy = DisconnectGuard(); let now = Date()
        XCTAssertFalse(guardPolicy.observe(.connected, eligibleLoss: false, at: now))
        XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: false, at: now))
        XCTAssertFalse(guardPolicy.observe(.disconnected, eligibleLoss: true, at: now))
    }
    func testFindMyCapabilitiesAreModelSpecific() {
        XCTAssertFalse(Device.four.findMySeparateComponents)
        XCTAssertFalse(Device.four.findMySeparationDocumented)
        XCTAssertTrue(Device.fourANC.findMySeparateComponents)
        XCTAssertTrue(Device.maria.findMySeparateComponents)
        XCTAssertTrue(Device.maria.findMySeparationDocumented)
        XCTAssertFalse(Device.maxUSB.findMySeparateComponents)
        XCTAssertTrue(Device.maxUSB.findMySeparationDocumented)
        XCTAssertFalse(Device.other.findMySeparationDocumented)
        XCTAssertFalse(Device.five.findMySeparateComponents)
    }
    func testFlatPreservesShapeAndPreampWhileResetRestoresDefaults() {
        var settings = EQSettings(); settings.bands[0] = EQBand(frequency: 95, gain: 3, q: 0.7)
        settings.preamp = -9; settings.bypass = true; settings.automaticHeadroom = false
        settings.flattenBands()
        XCTAssertTrue(settings.bands.allSatisfy { $0.gain == 0 })
        XCTAssertEqual(settings.bands[0].frequency, 95); XCTAssertEqual(settings.bands[0].q, 0.7)
        XCTAssertEqual(settings.preamp, -9); XCTAssertFalse(settings.bypass); XCTAssertFalse(settings.automaticHeadroom)
        let reset = EQSettings(); XCTAssertEqual(reset.bands.map(\.frequency), EQSettings.frequencies)
        XCTAssertEqual(reset.preamp, -6); XCTAssertTrue(reset.automaticHeadroom); XCTAssertFalse(reset.bypass)
    }
    func testBuiltInEQPresetsAreValidGentleAndHaveHeadroom() {
        for preset in BuiltInEQPreset.allCases {
            let settings = preset.settings
            XCTAssertTrue(settings.isValid, preset.rawValue)
            XCTAssertTrue(settings.automaticHeadroom); XCTAssertFalse(settings.bypass)
            XCTAssertLessThanOrEqual(settings.effectivePreamp, -6)
            XCTAssertTrue(settings.bands.allSatisfy { abs($0.gain) <= 3 })
            for language in ["ro", "fr", "en"] { XCTAssertNotNil(Localization.catalogue[preset.rawValue]?[language]) }
        }
        XCTAssertEqual(BuiltInEQPreset.voice.settings.bands[7].gain, 2)
        XCTAssertEqual(BuiltInEQPreset.soft.settings.bands[9].gain, -3)
    }
    func testCustomEQPresetLibraryValidationAndRoundTrip() throws {
        var settings = BuiltInEQPreset.bass.settings; settings.bands[0].q = 0.73; settings.bypass = true
        let preset = EQPreset(name: "  Preferința mea  ", settings: settings)
        XCTAssertEqual(preset.name, "Preferința mea"); XCTAssertTrue(preset.isValid)
        let copy = try JSONDecoder().decode([EQPreset].self, from: JSONEncoder().encode([preset]))
        XCTAssertEqual(copy, [preset]); XCTAssertEqual(copy[0].settings.bands[0].q, 0.73)
        XCTAssertTrue(EQPreset.validLibrary(copy)); XCTAssertFalse(EQPreset.validLibrary([preset,preset]))
        XCTAssertFalse(EQPreset.validLibrary([preset, EQPreset(name: "PREFERINTA MEA", settings: settings)]))
        for name in ["", "a\nb", String(repeating: "x", count: 61)] { XCTAssertFalse(EQPreset(name: name, settings: settings).isValid) }
        var invalid = settings; invalid.bands = []; XCTAssertFalse(EQPreset(name: "Invalid", settings: invalid).isValid)
        XCTAssertFalse(EQPreset.validLibrary((0..<51).map { EQPreset(name: "Preset \($0)", settings: settings) }))
    }
    func testUpdatingPersonalPresetPreservesIdentityAndOtherPresets() throws {
        let first = EQPreset(name: "My Jazz", settings: BuiltInEQPreset.jazz.settings)
        let second = EQPreset(name: "Other", settings: EQSettings())
        var settings = first.settings; settings.bands[0].gain = 1.25; settings.preamp = -8
        let updated = try XCTUnwrap(EQPreset.replacing(in: [first, second], id: first.id, name: "My Jazz edited", settings: settings))
        XCTAssertEqual(updated[0].id, first.id); XCTAssertEqual(updated[0].name, "My Jazz edited")
        XCTAssertEqual(updated[0].settings, settings); XCTAssertEqual(updated[1], second)
        XCTAssertEqual(first.settings, BuiltInEQPreset.jazz.settings)
        XCTAssertNil(EQPreset.replacing(in: [first, second], id: first.id, name: "OTHER", settings: settings))
        XCTAssertNil(EQPreset.replacing(in: [first], id: UUID(), name: "Missing", settings: settings))
        let decoded = try JSONDecoder().decode([EQPreset].self, from: JSONEncoder().encode(updated))
        XCTAssertEqual(decoded, updated)
    }
    func testBuiltInPresetsRemainUnchangedWhenCopiesAreEditedOrRemoved() throws {
        let original = BuiltInEQPreset.allCases.map(\.settings)
        var library = BuiltInEQPreset.allCases.map { EQPreset(name: $0.rawValue, settings: $0.settings) }
        var changed = library[0].settings; changed.bands[0].gain = 7
        library = try XCTUnwrap(EQPreset.replacing(in: library, id: library[0].id, name: "Personal edit", settings: changed))
        library.removeAll()
        XCTAssertTrue(library.isEmpty)
        XCTAssertEqual(BuiltInEQPreset.allCases.map(\.settings), original)
        XCTAssertEqual(BuiltInEQPreset.allCases.count, 18)
    }
    func testEQControlModeCapabilitiesAndTranslations() {
        XCTAssertFalse(EQControlMode.basic.showsFrequency); XCTAssertFalse(EQControlMode.basic.showsQ)
        XCTAssertTrue(EQControlMode.advanced.showsFrequency); XCTAssertFalse(EQControlMode.advanced.showsQ)
        XCTAssertTrue(EQControlMode.expert.showsFrequency); XCTAssertTrue(EQControlMode.expert.showsQ)
        for mode in EQControlMode.allCases {
            XCTAssertEqual(EQControlMode(rawValue: mode.rawValue), mode)
            for language in ["ro", "fr", "en"] {
                XCTAssertNotNil(Localization.catalogue[mode.rawValue]?[language])
                XCTAssertNotNil(Localization.catalogue[mode.help]?[language])
            }
        }
        XCTAssertTrue(BuiltInEQPreset.classical.settings.bands.allSatisfy { $0.gain == 0 })
    }
    func testWaveformEnvelopePreservesPeaksAndHandlesNonfiniteSamples() {
        let input: [Float] = [-2, 2, 0.5, -0.25, .nan, .infinity]
        let envelope = input.withUnsafeBufferPointer { AudioWaveformEnvelope.extract($0, maximumBuckets: 3) }
        XCTAssertEqual(envelope, [-2, 2, -0.25, 0.5, 0, 0])
        XCTAssertEqual([Float]().withUnsafeBufferPointer { AudioWaveformEnvelope.extract($0) }, [])
        XCTAssertEqual([Float(0.5)].withUnsafeBufferPointer { AudioWaveformEnvelope.extract($0) }, [0.5, 0.5])
    }
    func testWaveformEnvelopeIsBoundedAndRejectsInvalidBucketLimits() {
        let input = (0..<10000).map { Float($0 % 17) / 16 }
        let result = input.withUnsafeBufferPointer { AudioWaveformEnvelope.extract($0) }
        XCTAssertLessThanOrEqual(result.count, 256); XCTAssertEqual(result.count % 2, 0)
        for index in stride(from: 0, to: result.count, by: 2) { XCTAssertLessThanOrEqual(result[index], result[index+1]) }
        for limit in [0, -1, 1025] { XCTAssertTrue(input.withUnsafeBufferPointer { AudioWaveformEnvelope.extract($0, maximumBuckets: limit) }.isEmpty) }
    }
    func make() -> Session { Session(device: .four, start: Date(timeIntervalSince1970: 0), end: Date(timeIntervalSince1970: 5400), volume: 50, mode: "Oprit", environment: "Interior", firmware: "9A348", source: "iPhone", activity: "Muzică", notes: "", interrupted: false, samples: [.init(component: .left, initial: 100, final: 70)]) }
    func testSeparateCaseAndEarbudThresholds() {
        var prefs = BatteryAlertPreferences(); prefs.caseThreshold = 30
        XCTAssertTrue(prefs.isValid)
        XCTAssertEqual(prefs.severity(component: .caseBattery, level: 25), .low)
        XCTAssertNil(prefs.severity(component: .left, level: 25))
        XCTAssertEqual(prefs.severity(component: .left, level: 20), .low)
        XCTAssertEqual(prefs.severity(component: .headphones, level: 10), .critical)
        XCTAssertNil(prefs.severity(component: .right, level: 101))
        let pair = UUID(), now = Date()
        let snapshot = WidgetSnapshot(pairName: "Pair", readings: [.init(pairID: pair, component: .left, level: 50, observedAt: now), .init(pairID: pair, component: .caseBattery, level: 9, observedAt: now)], language: "ro")
        XCTAssertEqual(snapshot.primaryReading?.component, .caseBattery)
    }
    func testLowBatteryDeduplicationEscalationAndCooldown() {
        let prefs = BatteryAlertPreferences(), pair = UUID(), date = Date(timeIntervalSince1970: 50000)
        var latches: [String: BatteryAlertLatch] = [:]
        func reading(_ value: Int, _ seconds: Double) -> BatteryObservation { .init(pairID: pair, component: .left, level: value, observedAt: date.addingTimeInterval(seconds)) }
        func events(_ reading: BatteryObservation) -> [BatteryAlertEvent] { BatteryAlertPolicy.evaluate(readings: [reading], preferences: prefs, latches: &latches, now: reading.observedAt) }
        let initial = reading(20,0)
        XCTAssertEqual(events(initial).count, 1)
        XCTAssertTrue(events(initial).isEmpty)
        XCTAssertTrue(events(reading(19,30)).isEmpty)
        XCTAssertEqual(events(reading(10,60)).first?.severity, .critical)
        XCTAssertTrue(events(reading(8,90)).isEmpty)
        XCTAssertTrue(events(reading(26,120)).isEmpty)
        XCTAssertTrue(events(reading(19,180)).isEmpty)
        XCTAssertEqual(events(reading(18,720)).count, 1)
    }
    func testStaleFutureAndInvalidReadingsNeverAlert() {
        let now = Date(timeIntervalSince1970: 50000), pair = UUID()
        var latches: [String: BatteryAlertLatch] = [:]
        let readings: [BatteryObservation] = [
            .init(pairID: pair, component: .left, level: 1, observedAt: now.addingTimeInterval(-900)),
            .init(pairID: pair, component: .right, level: 1, observedAt: now.addingTimeInterval(1)),
            .init(pairID: pair, component: .caseBattery, level: -1, observedAt: now)
        ]
        XCTAssertTrue(BatteryAlertPolicy.evaluate(readings: readings, preferences: .init(), latches: &latches, now: now).isEmpty)
        XCTAssertTrue(latches.isEmpty)
    }
    func testAlertPrimingAndLatchPersistence() throws {
        let now = Date(timeIntervalSince1970: 50000)
        let low = BatteryObservation(pairID: UUID(), component: .caseBattery, level: 15, observedAt: now)
        var latches: [String: BatteryAlertLatch] = [:]
        BatteryAlertPolicy.prime(readings: [low], preferences: .init(), latches: &latches)
        latches = try JSONDecoder().decode([String: BatteryAlertLatch].self, from: JSONEncoder().encode(latches))
        XCTAssertTrue(BatteryAlertPolicy.evaluate(readings: [low], preferences: .init(), latches: &latches, now: now).isEmpty)
        var critical = low; critical.id = UUID(); critical.level = 5; critical.observedAt = now.addingTimeInterval(1)
        XCTAssertEqual(BatteryAlertPolicy.evaluate(readings: [critical], preferences: .init(), latches: &latches, now: critical.observedAt).count, 1)
        var partialRecovery = critical; partialRecovery.id = UUID(); partialRecovery.level = 15; partialRecovery.observedAt = now.addingTimeInterval(2)
        XCTAssertTrue(BatteryAlertPolicy.evaluate(readings: [partialRecovery], preferences: .init(), latches: &latches, now: partialRecovery.observedAt).isEmpty)
        BatteryAlertPolicy.prime(readings: [partialRecovery], preferences: .init(), latches: &latches)
        critical.id = UUID(); critical.observedAt = now.addingTimeInterval(3)
        XCTAssertTrue(BatteryAlertPolicy.evaluate(readings: [critical], preferences: .init(), latches: &latches, now: critical.observedAt).isEmpty)
    }
    func testLatestManualReadingWinsTimestampTiesAndPairsStaySeparate() {
        var archive = Archive(); let pair = archive.pairs[0], now = Date(timeIntervalSince1970: 50000)
        archive.observations = [.init(pairID: pair.id, component: .caseBattery, level: 50, observedAt: now), .init(pairID: pair.id, component: .caseBattery, level: 9, observedAt: now)]
        XCTAssertEqual(archive.latestBattery(pair: pair, now: now).first?.level, 9)
        var readings = archive.latestBattery(pair: pair, now: now)
        readings.append(.init(pairID: archive.pairs[1].id, component: .caseBattery, level: 9, observedAt: now))
        var latches: [String: BatteryAlertLatch] = [:]
        XCTAssertEqual(BatteryAlertPolicy.evaluate(readings: readings, preferences: .init(), latches: &latches, now: now).count, 2)
    }
    func testBatteryObservationsUseTimestampsAndPairIdentity() {
        var archive = Archive(); let pair = archive.pairs[0]
        let now = Date(timeIntervalSince1970: 20000)
        var old = make(); old.pairID = pair.id; old.end = now.addingTimeInterval(-3600)
        archive.sessions = [old]
        archive.observations = [
            .init(pairID: pair.id, component: .left, level: 22, observedAt: now.addingTimeInterval(-60)),
            .init(pairID: pair.id, component: .left, level: 99, observedAt: now.addingTimeInterval(60)),
            .init(pairID: archive.pairs[1].id, component: .left, level: 88, observedAt: now),
            .init(pairID: pair.id, component: .right, level: 101, observedAt: now)
        ]
        let readings = archive.latestBattery(pair: pair, now: now)
        XCTAssertEqual(readings.count, 1); XCTAssertEqual(readings[0].level, 22)
        XCTAssertFalse(readings[0].stale(at: now))
        XCTAssertTrue(readings[0].stale(at: now.addingTimeInterval(900)))
        archive.observations = []
        XCTAssertTrue(archive.latestBattery(pair: pair, now: now)[0].fromTest)
        XCTAssertEqual(archive.latestBattery(pair: pair, now: now)[0].level, 70)
    }
    func testSummaryFirstLastBestMeanAndProtocolFiltering() throws {
        let pairID = UUID()
        func test(_ time: Double, _ drop: Int) -> Session {
            var s = make(); s.pairID = pairID; s.start = Date(timeIntervalSince1970: time); s.end = s.start.addingTimeInterval(3600)
            s.samples[0].final = 100 - drop; return s
        }
        let first = test(0,30), best = test(4000,10), last = test(8000,20)
        var foreign = test(9000,99); foreign.pairID = UUID()
        var different = test(10000,99); different.volume = 100
        var future = test(100000,99)
        future.eqSignature = "different-processing"
        let result = try XCTUnwrap(AutonomySummary.calculate(sessions: [last,foreign,best,different,first,future], anchor: last, component: .left, now: Date(timeIntervalSince1970: 20000)))
        XCTAssertEqual(result.first.session.id, first.id); XCTAssertEqual(result.last.session.id, last.id)
        XCTAssertEqual(result.best.session.id, best.id); XCTAssertEqual(result.count, 3)
        XCTAssertEqual(result.mean, 20); XCTAssertEqual(result.differenceFromFirst, -10); XCTAssertEqual(result.differenceFromBest, 10)
        XCTAssertEqual(try XCTUnwrap(result.percentageChangeFromFirst), -100.0/3, accuracy: 0.00001)
        XCTAssertNil(AutonomySummary.calculate(sessions: [last], anchor: last, component: .caseBattery))
    }
    func testZeroBaselineAndChangedProcessing() throws {
        var first = make(); first.samples[0].final = 100
        let zero = try XCTUnwrap(AutonomySummary.calculate(sessions: [first], anchor: first, component: .left))
        XCTAssertNil(zero.percentageChangeFromFirst)
        var later = first; later.eqSignature = EQSettings().signature(playerGain: 0.25)
        XCTAssertFalse(first.sameProtocol(as: later))
    }
    func testEQValidationHeadroomAndSignatures() throws {
        var eq = EQSettings(); XCTAssertTrue(eq.isValid)
        let initial = eq.signature
        eq.bands[0].gain = 6; eq.bands[1].gain = 4
        XCTAssertEqual(eq.effectivePreamp, -10)
        XCTAssertNotEqual(eq.signature, initial)
        XCTAssertNotEqual(eq.signature(playerGain: 0.25), eq.signature(playerGain: 0.5))
        eq.automaticHeadroom = false; XCTAssertEqual(eq.effectivePreamp, -6)
        eq.bypass = true; XCTAssertEqual(eq.effectivePreamp, 0)
        eq.bands[0].q = 0; XCTAssertFalse(eq.isValid)
        XCTAssertTrue(EQBand(frequency: 1000, q: 10).bandwidth < EQBand(frequency: 1000, q: 1).bandwidth)
        let copied = try JSONDecoder().decode(EQSettings.self, from: JSONEncoder().encode(EQSettings()))
        XCTAssertEqual(copied.signature, EQSettings().signature)
    }
    func testWidgetSnapshotKeepsOriginalObservationAge() throws {
        let date = Date(timeIntervalSince1970: 10000)
        let observation = BatteryObservation(pairID: UUID(), component: .left, level: 50, observedAt: date)
        var snapshot = WidgetSnapshot(pairName: "Мария", readings: [observation], language: "fr", publishedAt: date.addingTimeInterval(5000), trackTitle: "Track")
        XCTAssertEqual(snapshot.staleDate, date.addingTimeInterval(900))
        snapshot.publishedAt = date.addingTimeInterval(10000)
        XCTAssertEqual(snapshot.staleDate, date.addingTimeInterval(900))
        let copy = try JSONDecoder().decode(WidgetSnapshot.self, from: JSONEncoder().encode(snapshot))
        XCTAssertEqual(copy, snapshot)
    }
    func testLegacyJournalHasNoInventedBatteryOrEQ() throws {
        var archive = Archive(); archive.sessions = [make()]
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(archive)) as? [String: Any])
        object.removeValue(forKey: "observations")
        let copy = try JSONDecoder().decode(Archive.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertTrue(copy.observations.isEmpty); XCTAssertNil(copy.sessions[0].eqSignature)
    }
    func testLanguageSelectionAndSafeFormatting() {
        XCTAssertEqual(Localization.resolve(preferences: ["de-CH", "fr-CH", "en"]), "fr")
        XCTAssertEqual(Localization.resolve(preferences: ["ro_RO"]), "ro")
        XCTAssertEqual(Localization.resolve(preferences: ["ja"]), "en")
        XCTAssertEqual(Localization.text("Salvează testul", language: "fr"), "Enregistrer le test")
        XCTAssertEqual(Localization.text("Salvează testul", language: "en"), "Save test")
        XCTAssertEqual(Localization.text("{0} · {1}", arguments: ["Мария {1}", "50%"], language: "fr"), "Мария {1} · 50%")
        let s = make(); XCTAssertEqual(s.mode, "Oprit")
        XCTAssertEqual(Localization.text(s.mode, language: "fr"), "Désactivé")
        XCTAssertEqual(s.mode, "Oprit") // presentation must not mutate serialized protocols
        var unknown = s; unknown.firmware = "Inconnu"; XCTAssertFalse(unknown.comparable)
    }
    func testCompleteTranslationPlaceholders() throws {
        let regex = try NSRegularExpression(pattern: "\\{[0-9]+\\}")
        func placeholders(_ text: String) -> [String] {
            regex.matches(in: text, range: NSRange(location: 0, length: (text as NSString).length)).map { (text as NSString).substring(with: $0.range) }.sorted()
        }
        for (key, translations) in Localization.catalogue {
            for language in ["ro", "fr", "en"] {
                let text = try XCTUnwrap(translations[language], "Missing translation: \(key) / \(language)")
                XCTAssertFalse(text.isEmpty)
                XCTAssertEqual(placeholders(key), placeholders(text), "Broken placeholders: \(key) / \(language)")
            }
        }
    }
    func testBluetoothAssociationPersistence() throws {
        var archive = Archive()
        let pair = AirPodsPair(name: "Мария", device: .maria, bluetoothID: "mac:test-device-1")
        archive.pairs.append(pair)
        let copy = try JSONDecoder().decode(Archive.self, from: JSONEncoder().encode(archive))
        XCTAssertEqual(copy.pairs.last?.bluetoothID, pair.bluetoothID)
        XCTAssertNil(copy.pairs.first?.bluetoothID)
    }
    func testDistinctPairsAndRename() throws {
        var archive = Archive()
        let home = AirPodsPair(name: "Acasă", device: .four)
        let work = AirPodsPair(name: "Serviciu", device: .four)
        archive.pairs += [home, work]
        var a = make(); a.pairID = home.id
        var b = a; b.pairID = work.id
        XCTAssertFalse(a.sameProtocol(as: b))
        archive.sessions = [a, b]; archive.draft = b
        archive.pairs[2].name = "Acasă nou"
        let copy = try JSONDecoder().decode(Archive.self, from: JSONEncoder().encode(archive))
        XCTAssertEqual(copy.sessions[0].pairID, home.id)
        XCTAssertEqual(copy.sessions[1].pairID, work.id)
        XCTAssertEqual(copy.pairs[2].name, "Acasă nou")
        XCTAssertEqual(copy.draft?.pairID, work.id)
        XCTAssertNotNil(copy.nameError("   "))
        XCTAssertNotNil(copy.nameError("serviciu"))
        XCTAssertNil(copy.nameError("Serviciu", excluding: work.id))
    }
    func testLegacyJournalMigration() throws {
        var archive = Archive(); archive.sessions = [make()]; archive.draft = make()
        let data = try JSONEncoder().encode(archive)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        object.removeValue(forKey: "pairs")
        let decoded = try JSONDecoder().decode(Archive.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(decoded.sessions[0].pairID, AirPodsPair.initial[0].id)
        XCTAssertEqual(decoded.draft?.pairID, AirPodsPair.initial[0].id)
        XCTAssertEqual(decoded.pairs.count, 2)
        let roundTrip = try JSONDecoder().decode(Archive.self, from: JSONEncoder().encode(decoded))
        XCTAssertEqual(roundTrip.sessions[0].pairID, decoded.sessions[0].pairID)
    }
    func testModelCapabilities() throws {
        XCTAssertEqual(Device.four.audioModes, ["Oprit"])
        XCTAssertTrue(Device.maria.supportsAdaptive)
        XCTAssertTrue(Device.fourANC.supportsANC)
        XCTAssertFalse(Device.proOne.supportsAdaptive)
        XCTAssertTrue(Device.proTwoUSB.supportsAdaptive)
        XCTAssertFalse(Device.maxUSB.supportsAdaptive)
        XCTAssertTrue(Device.maxTwo.supportsAdaptive)
        XCTAssertEqual(Device.maxTwo.components, [.headphones])
        XCTAssertNil(Device.one.referenceFirmware)
        XCTAssertEqual(try JSONDecoder().decode(Device.self, from: Data("\"AirPods 5 «Мария»\"".utf8)), .maria)
    }
    func testUnsupportedModesAndComponents() {
        var s = make(); s.mode = "ANC"; XCTAssertNotNil(s.validation)
        s.device = .fourANC; XCTAssertNil(s.validation)
        s.mode = "Adaptiv"; XCTAssertNil(s.validation)
        s.device = .proOne; XCTAssertNotNil(s.validation)
        s.device = .maxTwo; XCTAssertNotNil(s.validation)
        s.samples = [.init(component: .headphones, initial: 90, final: 70)]; XCTAssertNil(s.validation)
        s.device = .other; XCTAssertNil(s.validation); XCTAssertFalse(s.comparable)
    }
    func testRateAndCharging() {
        XCTAssertEqual(make().samples[0].rate(hours: 1.5), 20)
        XCTAssertNil(BatterySample(component: .right, initial: 20, final: 30).rate(hours: 1))
        XCTAssertNil(make().samples[0].rate(hours: 0))
    }
    func testValidation() {
        var s = make(); XCTAssertNil(s.validation)
        s.end = s.start; XCTAssertNotNil(s.validation)
        s = make(); s.end = Date().addingTimeInterval(3600); XCTAssertNotNil(s.validation)
        s = make(); s.samples[0].initial = 101; XCTAssertNotNil(s.validation)
        s = make(); s.samples = []; XCTAssertNotNil(s.validation)
        s = make(); s.firmware = " necunoscut "; XCTAssertFalse(s.comparable)
        s = make(); s.end = s.start; XCTAssertFalse(s.comparable)
    }
    func testComparison() {
        let a = make(); var b = a; b.firmware = "9A350"
        XCTAssertTrue(a.sameProtocol(as: b))
        b.volume = 60; XCTAssertFalse(a.sameProtocol(as: b))
        b.interrupted = true; XCTAssertFalse(b.comparable)
        b = a; b.samples[0].final = 101; XCTAssertFalse(b.comparable)
    }
    func testPersistence() throws {
        var archive = Archive(); archive.sessions = [make()]; archive.draft = make()
        let copy = try JSONDecoder().decode(Archive.self, from: JSONEncoder().encode(archive))
        XCTAssertEqual(copy.sessions[0].samples, archive.sessions[0].samples)
        XCTAssertEqual(copy.draft?.device, .four)
    }
    func testRoutine() throws {
        var cal = Calendar(identifier: .gregorian); cal.timeZone = try XCTUnwrap(TimeZone(identifier: "Europe/Zurich"))
        let weekday = try XCTUnwrap(cal.date(from: DateComponents(year: 2026, month: 10, day: 20)))
        let weekend = try XCTUnwrap(cal.date(from: DateComponents(year: 2026, month: 10, day: 24)))
        let slots = Routine.intervals(on: weekday, calendar: cal)
        XCTAssertEqual(slots.count, 2); XCTAssertEqual(slots[0].1.timeIntervalSince(slots[0].0), 6300)
        XCTAssertEqual(cal.component(.hour, from: slots[0].0), 7)
        XCTAssertEqual(Routine.intervals(on: weekend, calendar: cal).count, 1)
    }
}
