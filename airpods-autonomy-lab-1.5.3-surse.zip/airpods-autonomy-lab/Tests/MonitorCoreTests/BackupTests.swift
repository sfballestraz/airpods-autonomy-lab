import XCTest
@testable import MonitorCore
final class BackupTests: XCTestCase {
    func testJSONAndCSVPreserveBackup() throws {
        let b = CompleteBackup(archive:Archive(), preferences:["appLanguage":"fr", "unicode":"Мария,\nȘț\"é"])
        let raw = try b.encoded()
        XCTAssertEqual(try CompleteBackup.decode(raw).encoded(), raw)
        XCTAssertEqual(try CompleteBackup.fromCSV(b.csv()).encoded(), raw)
    }
    func testRejectsUnknownSchemaAndMalformedCSV() throws {
        let raw = try CompleteBackup(archive:Archive()).encoded()
        let altered = String(decoding:raw,as:UTF8.self).replacingOccurrences(of:"\"schemaVersion\":4",with:"\"schemaVersion\":99")
        XCTAssertThrowsError(try CompleteBackup.decode(Data(altered.utf8)))
        XCTAssertThrowsError(try CompleteBackup.fromCSV(Data("format,schemaVersion,payloadBase64\r\nAirPodsAutonomyLab,2,bad\r\n".utf8)))
    }
}
import SwiftData
extension BackupTests {
    @MainActor func testMigratesLegacyLabStore() throws {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder, withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let config = ModelConfiguration(url:folder.appending(path:"migration.store"), cloudKitDatabase:.none)
        let id: UUID
        do {
            let c = try ModelContainer(for:Schema(versionedSchema:LabSchemaV1.self), configurations:config)
            let r = LabRecord(pairID:AirPodsPair.initial[0].id, kind:"test", text:"éșМария")
            id = r.id; c.mainContext.insert(r); try c.mainContext.save()
        }
        let c = try ModelContainer(for:Schema(versionedSchema:LabSchemaV2.self), migrationPlan:LabMigration.self, configurations:config)
        XCTAssertEqual(try c.mainContext.fetch(FetchDescriptor<LabRecord>()).first?.id,id)
        let r = JournalRevision(payload:Data("test".utf8)); c.mainContext.insert(r); try c.mainContext.save()
        XCTAssertEqual(try c.mainContext.fetchCount(FetchDescriptor<JournalRevision>()),1)
    }
}
extension BackupTests {
    func revision(_ archive: Archive, base: Archive? = nil, time: Double, id: UUID = UUID()) throws -> CompleteBackup.Revision {
        .init(id:id, timestamp:Date(timeIntervalSince1970:time), payload:try JSONEncoder().encode(archive), basePayload:try base.map { try JSONEncoder().encode($0) } ?? Data())
    }
    func testConcurrentIndependentEditsConvergeInEitherArrivalOrder() throws {
        let base = Archive()
        var a = base; a.pairs[0].name = "A"
        var b = base; b.pairs[1].name = "B"
        let rows = try [revision(base,time:1),revision(a,base:base,time:2),revision(b,base:base,time:3)]
        let first = try JournalHistory.materialize(rows)
        let second = try JournalHistory.materialize(rows.reversed())
        XCTAssertEqual(first.pairs,second.pairs)
        XCTAssertEqual(first.pairs.map(\.name),["A","B"])
    }
    func testDeletionSurvivesReplayAndUnrelatedSnapshot() throws {
        var base = Archive(); let pair = AirPodsPair(name:"test",device:.four); base.pairs.append(pair)
        var deleted = base; deleted.pairs.removeAll { $0.id == pair.id }
        var other = base; other.pairs[0].name = "Modified elsewhere"
        let result = try JournalHistory.materialize([revision(base,time:1),revision(deleted,base:base,time:2),revision(other,base:base,time:3)])
        XCTAssertFalse(result.pairs.contains { $0.id == pair.id })
        XCTAssertEqual(result.pairs[0].name,"Modified elsewhere")
    }
    func testDuplicateTransportRowsAreIdempotentAndConflictingIDsRejected() throws {
        let row = try revision(Archive(),time:1)
        XCTAssertEqual(try JournalHistory.materialize([row,row]).pairs.count,2)
        var changed = row; changed.basePayload = Data("invalid".utf8)
        XCTAssertThrowsError(try JournalHistory.materialize([row,changed]))
    }
    func testBackupRejectsCorruptHistoryBeforeImport() throws {
        let b = CompleteBackup(archive:Archive(), revisions:[.init(id:UUID(),timestamp:Date(),payload:Data("invalid".utf8))])
        XCTAssertThrowsError(try CompleteBackup.decode(b.encoded()))
    }
    func testTimestampRoundtripPreservesSubsecondPrecision() throws {
        var b = CompleteBackup(archive:Archive()); b.exportedAt = Date(timeIntervalSinceReferenceDate:123456789.123456)
        XCTAssertEqual(try CompleteBackup.decode(b.encoded()).exportedAt,b.exportedAt)
    }
}
extension BackupTests {
    func testBoundedFileReaderSupportsJSONAndCSV() throws {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        defer { try? FileManager.default.removeItem(at:folder) }
        let b = CompleteBackup(archive:Archive())
        for ext in ["json","csv"] {
            let url = folder.appending(path:"backup." + ext)
            try (ext == "csv" ? b.csv() : b.encoded()).write(to:url)
            XCTAssertEqual(try CompleteBackup.readFile(url).encoded(),try b.encoded())
        }
    }
}
extension BackupTests {
    func testHistoryDoesNotInventDefaultPairsForCustomJournal() throws {
        var archive = Archive(); archive.pairs = [.init(name:"Only mine",device:.four)]
        XCTAssertEqual(try JournalHistory.materialize([revision(archive,time:1)]).pairs,archive.pairs)
    }
    func testVaultDetectsTamperingAndRoundtrips() throws {
        let folder = FileManager.default.temporaryDirectory.appending(path:UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:folder) }
        let b = CompleteBackup(archive:Archive())
        let url = try BackupVault.write(b,to:folder)
        XCTAssertEqual(try BackupVault.verified(url).encoded(),try b.encoded())
        XCTAssertEqual(try BackupVault.entries(in:folder).count,1)
        var changed = b; changed.archive.pairs[0].name = "Tampered"
        try changed.encoded().write(to:url)
        XCTAssertThrowsError(try BackupVault.verified(url))
    }
    func testQualityUsesLatestReadingPerComponent() {
        let now = Date()
        var archive = Archive()
        archive.observations = [.init(pairID:archive.pairs[0].id,component:.left,level:90,observedAt:now.addingTimeInterval(-3600)),.init(pairID:archive.pairs[0].id,component:.left,level:80,observedAt:now)]
        XCTAssertEqual(JournalQuality(archive:archive,now:now).staleReadings,0)
        archive.observations.append(.init(pairID:archive.pairs[0].id,component:.right,level:101,observedAt:now.addingTimeInterval(5)))
        XCTAssertEqual(JournalQuality(archive:archive,now:now).invalidReadings,1)
    }
}
