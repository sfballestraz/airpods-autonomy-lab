import XCTest
@testable import MonitorCore
final class EQTenBandTests: XCTestCase {
    func testLegacyFiltersRemainExactAndExtraBandsNeutral() throws {
        let legacy = #"{"bands":[{"frequency":95,"gain":3,"q":0.7},{"frequency":250,"gain":-2,"q":1},{"frequency":1000,"gain":1,"q":2},{"frequency":4000,"gain":0,"q":1},{"frequency":12000,"gain":-3,"q":1}],"preamp":-9,"bypass":true,"automaticHeadroom":false}"#.data(using:.utf8)!
        let settings = try JSONDecoder().decode(EQSettings.self, from:legacy)
        XCTAssertEqual(settings.bands.count,10)
        XCTAssertEqual(settings.bands[0],EQBand(frequency:95,gain:3,q:0.7))
        XCTAssertEqual(settings.bands[4],EQBand(frequency:12000,gain:-3,q:1))
        XCTAssertTrue(settings.bands.suffix(5).allSatisfy { $0.gain == 0 })
        XCTAssertEqual(settings.preamp,-9); XCTAssertTrue(settings.bypass); XCTAssertFalse(settings.automaticHeadroom)
        XCTAssertEqual(try JSONDecoder().decode(EQSettings.self,from:JSONEncoder().encode(settings)),settings)
    }
    func testEveryModelCanLabelPresetWithoutAlteringDSP() throws {
        for model in Device.allCases {
            let preset = EQPreset(name:model.rawValue,settings:BuiltInEQPreset.voice.settings,device:model)
            XCTAssertEqual(preset.settings.bands.count,10)
            XCTAssertEqual(try JSONDecoder().decode(EQPreset.self,from:JSONEncoder().encode(preset)),preset)
        }
    }
    func testRejectWrongBandCount() throws {
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with:JSONEncoder().encode(EQSettings())) as? [String:Any])
        object["bands"] = []
        XCTAssertThrowsError(try JSONDecoder().decode(EQSettings.self,from:JSONSerialization.data(withJSONObject:object)))
    }
}
