import XCTest
@testable import MonitorCore
final class HomePodPresetTests: XCTestCase {
    func testAllHomePodPresetsRoundTripAndKeepEQ() throws {
        for model in HomePodModel.allCases {
            let preset = EQPreset(name:model.rawValue,settings:BuiltInEQPreset.voice.settings,homePod:model)
            XCTAssertTrue(preset.isValid); XCTAssertNil(preset.device)
            XCTAssertEqual(try JSONDecoder().decode(EQPreset.self,from:JSONEncoder().encode(preset)),preset)
            let updated = try XCTUnwrap(EQPreset.replacing(in:[preset],id:preset.id,name:"Updated",settings:EQSettings()))
            XCTAssertEqual(updated.first?.homePod,model)
        }
    }
    func testAmbiguousTargetRejected() {
        XCTAssertFalse(EQPreset(name:"Ambiguous",settings:EQSettings(),device:.four,homePod:.mini).isValid)
    }
}
